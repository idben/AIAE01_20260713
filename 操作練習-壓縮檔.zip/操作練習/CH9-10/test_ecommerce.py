import subprocess
import sys

from pathlib import Path

from main_ecommerce import Customer, OrderItem, place_order

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_properties() -> bool:
    print("---------------------------------")
    customer = Customer("小明", 5000, 1000)
    item = OrderItem("鍵盤", 1200, 2)
    expected = (4000, 2400)
    actual = (customer.remaining_credit, item.subtotal)
    print("輸入：credit_limit=5000, spent_amount=1000；鍵盤 1200 x2")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_place_order_success() -> bool:
    print("---------------------------------")
    customer = Customer("小明", 5000, 1000)
    item = OrderItem("鍵盤", 1200, 2)
    message = place_order(customer, item)
    expected_message = "小明 訂購 鍵盤 x2，金額 2400 元"
    expected_spent = 3400
    actual_spent = customer.spent_amount
    print("輸入：剩餘額度 4000，訂單小計 2400")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期已消費：{expected_spent}")
    print(f"實際已消費：{actual_spent}")
    if message == expected_message and actual_spent == expected_spent:
        print("通過")
        return True
    print("失敗")
    return False


def test_place_order_over_limit() -> bool:
    print("---------------------------------")
    customer = Customer("小美", 3000, 2500)
    item = OrderItem("螢幕", 1200, 1)
    try:
        place_order(customer, item)
    except ValueError as error:
        actual_error = str(error)
    else:
        actual_error = "沒有丟出 ValueError"
    expected_error = "信用額度不足，無法成立訂單"
    expected_spent = 2500
    actual_spent = customer.spent_amount
    print("輸入：剩餘額度 500，訂單小計 1200")
    print(f"預期錯誤：{expected_error}")
    print(f"實際錯誤：{actual_error}")
    print(f"預期已消費：{expected_spent}")
    print(f"實際已消費：{actual_spent}")
    if actual_error == expected_error and actual_spent == expected_spent:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_properties(),
        test_place_order_success(),
        test_place_order_over_limit(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

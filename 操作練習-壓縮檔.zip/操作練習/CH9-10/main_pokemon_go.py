from functools import wraps


class Trainer:
    def __init__(self, name: str, item_count: int, bag_capacity: int) -> None:
        # 請記住訓練家名稱、目前道具數、背包容量，並建立 rewards 清單
        raise NotImplementedError("請完成 Trainer.__init__")

    @property
    def bag_is_full(self) -> bool:
        # 請根據 item_count 和 bag_capacity 判斷背包是否已滿
        raise NotImplementedError("請完成 Trainer.bag_is_full")


class PokeStopReward:
    def __init__(self, item_name: str, amount: int) -> None:
        # 請記住獎勵道具名稱與數量
        raise NotImplementedError("請完成 PokeStopReward.__init__")


def require_bag_space(original_function):
    @wraps(original_function)
    def wrapper(trainer: Trainer, reward: PokeStopReward):
        # 請先檢查背包空間，不足時丟出指定 ValueError，足夠時才呼叫原函式
        raise NotImplementedError("請完成 require_bag_space.wrapper")

    return wrapper


@require_bag_space
def receive_reward(trainer: Trainer, reward: PokeStopReward) -> str:
    # 請增加道具數、記錄獎勵名稱，並回傳領取訊息
    raise NotImplementedError("請完成 receive_reward")


def run_demo() -> str:
    trainer = Trainer("訓練家", 8, 12)
    reward = PokeStopReward("精靈球", 3)
    return receive_reward(trainer, reward)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

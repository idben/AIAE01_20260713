# CH9-10 練習

## 你要完成的事

完成第九章裝飾器綜合練習。

- 《勇者鬥惡龍》版：用裝飾器檢查 MP，再施放咒文。
- 《寶可夢 GO》版：用裝飾器檢查背包容量，再領取補給站獎勵。
- 電子商務版：用裝飾器檢查信用額度，再成立訂單。

建議完成順序：

- 《勇者鬥惡龍》：整合類別、`@property`、前置檢查與狀態更新。
- 《寶可夢 GO》：在前一題基礎上加入背包容量與獎勵清單。
- 電子商務：整合顧客額度、商品小計、`@property`、`ValueError` 與成功後累計消費金額。

這裡的 `cast_spell(caster, spell, target)` 是綜合練習專用版本，會真的更新 `caster.mp` 和 `target.hp`。其中 `Character`（角色）代表會參與戰鬥的隊伍成員或怪物，`Spell`（咒文）代表可施放的技能資料。它和前面章節只回傳文字或只觀察參數轉交的同名範例不同。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

也可以直接打開 `test_dragon_quest.py` 或 `test_pokemon_go.py`，用編輯器的播放按鈕執行。

## 操作步驟

《勇者鬥惡龍》版：

1. 先完成 `Character`（角色）和 `Spell`（咒文），讓物件記住戰鬥流程會用到的屬性名稱。
2. 用 `@property` 完成 `Character.is_fainted`，根據 `hp` 判斷是否倒下。
3. 觀察 `cast_spell(caster, spell, target)` 的三個參數：施法者是會消耗 MP 的自己，目標是會受到傷害的對象。
4. 完成 `require_enough_mp` 裝飾器，讓 MP 不足時先被擋下來。
5. 成功時才進入原函式，更新狀態並回傳戰鬥訊息。訊息需要包含施法者、咒文、目標與傷害數字。

成功訊息格式：「施法者名稱 施放 咒文名稱，目標名稱 受到 傷害數字 傷害」。

《寶可夢 GO》版：

1. 先完成 `Trainer`（訓練家）和 `PokeStopReward`（補給站獎勵），讓物件記住領取獎勵時會用到的屬性名稱。
2. 用 `@property` 完成 `Trainer.bag_is_full`，根據 `item_count` 和 `bag_capacity` 判斷是否已滿。
3. 觀察 `receive_reward(trainer, reward)` 的兩個參數：訓練家是會被更新的目標，獎勵是本次要加入的資料。
4. 完成 `require_bag_space` 裝飾器，讓背包空間不足時先被擋下來。
5. 成功時才進入原函式，更新道具數量與獎勵紀錄。訊息需要包含訓練家、道具名稱與數量。

成功訊息格式：「訓練家名稱 領取 道具名稱 x數量」。

電子商務版：

1. 先完成 `Customer`（顧客）和 `OrderItem`（訂單商品），讓物件記住下單流程會用到的屬性名稱。
2. 用 `@property` 完成 `Customer.remaining_credit` 與 `OrderItem.subtotal`。
3. 觀察 `place_order(customer, item)` 的兩個參數：顧客是會被更新的目標，商品小計是本次要新增的消費金額。
4. 完成 `require_credit_limit` 裝飾器，讓信用額度不足時先被擋下來。
5. 成功時才進入原函式，更新已消費金額並回傳下單訊息。訊息需要包含顧客、商品、數量與小計。

成功訊息格式：「顧客名稱 訂購 商品名稱 x數量，金額 小計 元」。

## 題目提示

### 《勇者鬥惡龍》版

先觀察 `caster.mp` 和 `spell.mp_cost`。這兩個值決定能不能施法；`target.hp` 只有在成功施法後才會改變。

檢查順序：

1. 先檢查 `caster.mp` 是否小於 `spell.mp_cost`。
2. 不足時丟出 `ValueError("MP 不足，無法施放咒文")`。
3. 不足時不能扣 `caster.mp`，也不能扣 `target.hp`。
4. 足夠時才呼叫原函式。

### 《寶可夢 GO》版

先觀察 `trainer.item_count`、`trainer.bag_capacity` 和 `reward.amount`。這三個值決定背包是否放得下新獎勵；`rewards` 只有在成功領取後才會新增資料。

檢查順序：

1. 先檢查 `trainer.item_count + reward.amount` 是否超過 `trainer.bag_capacity`。
2. 不足時丟出 `ValueError("背包空間不足，無法領取獎勵")`。
3. 不足時不能改 `item_count`，也不能改 `rewards`。
4. 足夠時才呼叫原函式。

`Character.is_fainted` 和 `Trainer.bag_is_full` 是這裡的獨立 `@property` 練習點。你要能直接讀取它們目前的狀態；前置檢查裝飾器可以另外依照咒文消耗或獎勵數量判斷是否允許行動。

### 電子商務版

先觀察 `item.subtotal` 和 `customer.remaining_credit`。商品小計決定本次要增加多少消費，剩餘額度決定訂單能不能成立。

檢查順序：

1. 先用 `item.subtotal` 算出本次訂單金額。
2. 再用 `customer.remaining_credit` 判斷額度是否足夠。
3. 不足時丟出 `ValueError("信用額度不足，無法成立訂單")`。
4. 不足時不能改 `customer.spent_amount`。
5. 足夠時才呼叫原函式，更新已消費金額並回傳成功訊息。

## 檢查順序

1. 先確認資料類別的屬性名稱和測試檔一致。
2. 再確認 `@property` 可以直接讀取，不需要括號。
3. 接著確認前置檢查失敗時會丟出指定 `ValueError`。
4. 失敗時確認所有狀態都保持原樣。
5. 成功時確認原函式才會更新狀態。
6. 最後用測試確認成功訊息的資料與標點是否符合題目規則。

## 常見卡住點

- 錯誤訊息少字、多字或標點不同。
- 例外發生前已經改到狀態。
- `@property` 呼叫時加了括號。
- 裝飾器忘記回傳 `wrapper`。
- `wrapper` 忘記回傳原函式結果。
- 電子商務版忘記用 `item.subtotal`，導致單價與數量沒有一起計算。

## 做完你會練到

- 自訂裝飾器。
- 前置檢查與狀態更新順序。
- `@property`。
- 函式參數與回傳值的保留。

from functools import wraps


class Customer:
    def __init__(self, name: str, credit_limit: int, spent_amount: int) -> None:
        # 請記住顧客名稱、信用額度與已消費金額
        raise NotImplementedError("請完成 Customer.__init__")

    @property
    def remaining_credit(self) -> int:
        # 請回傳剩餘可用額度
        raise NotImplementedError("請完成 Customer.remaining_credit")


class OrderItem:
    def __init__(self, product_name: str, unit_price: int, quantity: int) -> None:
        # 請記住商品名稱、單價與數量
        raise NotImplementedError("請完成 OrderItem.__init__")

    @property
    def subtotal(self) -> int:
        # 請回傳商品小計
        raise NotImplementedError("請完成 OrderItem.subtotal")


def require_credit_limit(original_function):
    @wraps(original_function)
    def wrapper(customer: Customer, item: OrderItem):
        # 請先檢查剩餘額度，不足時丟出指定 ValueError，足夠時才呼叫原函式
        raise NotImplementedError("請完成 require_credit_limit.wrapper")

    return wrapper


@require_credit_limit
def place_order(customer: Customer, item: OrderItem) -> str:
    # 請增加顧客已消費金額，並回傳下單訊息
    raise NotImplementedError("請完成 place_order")


def run_demo() -> str:
    customer = Customer("小明", 5000, 1000)
    item = OrderItem("鍵盤", 1200, 2)
    return place_order(customer, item)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

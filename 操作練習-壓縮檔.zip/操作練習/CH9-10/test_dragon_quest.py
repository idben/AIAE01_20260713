import subprocess
import sys

from pathlib import Path

from main_dragon_quest import Character, Spell, cast_spell

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_property_is_fainted() -> bool:
    print("---------------------------------")
    active = Character("勇者", 1, 0)
    fainted = Character("史萊姆", 0, 0)
    expected = (False, True)
    actual = (active.is_fainted, fainted.is_fainted)
    print("輸入：hp=1 與 hp=0")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_cast_spell_success() -> bool:
    print("---------------------------------")
    caster = Character("勇者", 35, 8)
    target = Character("史萊姆", 18, 0)
    spell = Spell("美拉", 3, 10)
    message = cast_spell(caster, spell, target)
    expected_message = "勇者 施放 美拉，史萊姆 受到 10 傷害"
    expected_state = (5, 8)
    actual_state = (caster.mp, target.hp)
    print("輸入：勇者 mp=8，美拉 mp_cost=3 damage=10，史萊姆 hp=18")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def test_cast_spell_not_enough_mp() -> bool:
    print("---------------------------------")
    caster = Character("見習法師", 20, 1)
    target = Character("龍", 50, 0)
    spell = Spell("美拉", 3, 10)
    try:
        cast_spell(caster, spell, target)
    except ValueError as error:
        actual_error = str(error)
    else:
        actual_error = "沒有丟出 ValueError"
    expected_error = "MP 不足，無法施放咒文"
    expected_state = (1, 50)
    actual_state = (caster.mp, target.hp)
    print("輸入：見習法師 mp=1，美拉 mp_cost=3，龍 hp=50")
    print(f"預期錯誤：{expected_error}")
    print(f"實際錯誤：{actual_error}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if actual_error == expected_error and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_property_is_fainted(),
        test_cast_spell_success(),
        test_cast_spell_not_enough_mp(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

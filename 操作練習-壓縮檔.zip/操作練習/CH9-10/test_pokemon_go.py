import subprocess
import sys

from pathlib import Path

from main_pokemon_go import PokeStopReward, Trainer, receive_reward

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_property_bag_is_full() -> bool:
    print("---------------------------------")
    available = Trainer("訓練家A", 9, 10)
    full = Trainer("訓練家B", 10, 10)
    expected = (False, True)
    actual = (available.bag_is_full, full.bag_is_full)
    print("輸入：item_count=9/10 與 item_count=10/10")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_receive_reward_success() -> bool:
    print("---------------------------------")
    trainer = Trainer("訓練家", 8, 12)
    reward = PokeStopReward("精靈球", 3)
    message = receive_reward(trainer, reward)
    expected_message = "訓練家 領取 精靈球 x3"
    expected_state = (11, ["精靈球"])
    actual_state = (trainer.item_count, trainer.rewards)
    print("輸入：item_count=8，bag_capacity=12，精靈球 x3")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def test_receive_reward_not_enough_space() -> bool:
    print("---------------------------------")
    trainer = Trainer("訓練家", 9, 10)
    reward = PokeStopReward("傷藥", 2)
    try:
        receive_reward(trainer, reward)
    except ValueError as error:
        actual_error = str(error)
    else:
        actual_error = "沒有丟出 ValueError"
    expected_error = "背包空間不足，無法領取獎勵"
    expected_state = (9, [])
    actual_state = (trainer.item_count, trainer.rewards)
    print("輸入：item_count=9，bag_capacity=10，傷藥 x2")
    print(f"預期錯誤：{expected_error}")
    print(f"實際錯誤：{actual_error}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if actual_error == expected_error and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_property_bag_is_full(),
        test_receive_reward_success(),
        test_receive_reward_not_enough_space(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

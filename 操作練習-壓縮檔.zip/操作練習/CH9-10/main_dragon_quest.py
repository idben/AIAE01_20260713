from functools import wraps


class Character:
    def __init__(self, name: str, hp: int, mp: int) -> None:
        # 請記住角色名稱、HP 與 MP
        raise NotImplementedError("請完成 Character.__init__")

    @property
    def is_fainted(self) -> bool:
        # 請根據 hp 判斷角色是否倒下
        raise NotImplementedError("請完成 Character.is_fainted")


class Spell:
    def __init__(self, name: str, mp_cost: int, damage: int) -> None:
        # 請記住咒文名稱、MP 消耗與傷害
        raise NotImplementedError("請完成 Spell.__init__")


def require_enough_mp(original_function):
    @wraps(original_function)
    def wrapper(caster: Character, spell: Spell, target: Character):
        # 請先檢查 MP，不足時丟出指定 ValueError，足夠時才呼叫原函式
        raise NotImplementedError("請完成 require_enough_mp.wrapper")

    return wrapper


@require_enough_mp
def cast_spell(caster: Character, spell: Spell, target: Character) -> str:
    # 請扣除施法者 MP、扣除目標 HP，並回傳戰鬥訊息
    raise NotImplementedError("請完成 cast_spell")


def run_demo() -> str:
    caster = Character("勇者", 35, 8)
    target = Character("史萊姆", 18, 0)
    spell = Spell("美拉", 3, 10)
    return cast_spell(caster, spell, target)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

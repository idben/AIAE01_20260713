# CH6-02 練習

## 題目

完成不同範圍物件的四個邊界 getter methods。

- 《勇者鬥惡龍》版：`SpellArea` 直接保存兩個角落
- 《寶可夢 GO》版：`MapZone` 用中心點和半徑換算邊界
- 電子商務版：`PriceStockRange` 用價格區間和庫存區間換算邊界

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 打開對應的 `main_*.py`。
2. 使用該版本的 private instance variables 算出 left、right、top、bottom。
3. 存檔後執行對應測試。

## 題目提示

所有版本都要提供：

- `get_left_x()`
- `get_right_x()`
- `get_top_y()`
- `get_bottom_y()`

最後回傳順序會被測成 `(left, right, top, bottom)`。

### 《勇者鬥惡龍》版

`SpellArea` 是咒文範圍，建構時收到 `x1`、`y1`、`x2`、`y2`。這版可以直接用規則：left 是最小 x，right 是最大 x，top 是最大 y，bottom 是最小 y。因為兩個角落的輸入順序不固定，所以要用 getter 把座標整理成穩定邊界。

### 《寶可夢 GO》版

`MapZone` 是地圖搜尋範圍，建構時收到 `center_x`、`center_y`、`radius`。

- 左右邊界都從中心點 x 座標開始想
- 左邊界要從中心點往較小的 x 方向延伸一個半徑
- 右邊界要從中心點往較大的 x 方向延伸一個半徑
- 上下邊界都從中心點 y 座標開始想
- 上邊界要往較大的 y 方向延伸一個半徑
- 下邊界要往較小的 y 方向延伸一個半徑

### 電子商務版

`PriceStockRange` 是價格庫存區間，建構時收到 `min_price`、`min_stock`、`price_span`、`stock_span`。

- 價格可以想成 x 軸，庫存量可以想成 y 軸
- `min_price` 和 `min_stock` 是範圍起點
- `price_span` 是價格往上延伸的距離
- `stock_span` 是庫存往上延伸的距離
- left 對應最低價格
- right 要看價格延伸後的位置
- bottom 對應最低庫存
- top 要看庫存延伸後的位置

## 這題常見錯誤

- 把 top 和 bottom 的 y 方向寫反
- 在寶可夢版忘記用半徑往左右上下展開
- 在電子商務版忘記把寬高加回去

## 這題在測什麼

- private instance variables 的讀取
- 不同資料來源是否能整理成相同的邊界介面

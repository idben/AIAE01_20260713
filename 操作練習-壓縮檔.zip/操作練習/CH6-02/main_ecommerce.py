class PriceStockRange:
    def __init__(
        self, min_price: int, min_stock: int, price_span: int, stock_span: int
    ) -> None:
        self.__min_price = min_price
        self.__min_stock = min_stock
        self.__price_span = price_span
        self.__stock_span = stock_span

    def get_left_x(self) -> int:
        pass

    def get_right_x(self) -> int:
        pass

    def get_top_y(self) -> int:
        pass

    def get_bottom_y(self) -> int:
        pass

    # 以下內容不要修改

    def __repr__(self) -> str:
        return f"PriceStockRange({self.__min_price}, {self.__min_stock}, {self.__price_span}, {self.__stock_span})"

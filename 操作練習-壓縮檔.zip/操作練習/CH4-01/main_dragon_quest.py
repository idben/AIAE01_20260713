class PartyMember:
    def __init__(self, pos_x: int, pos_y: int, speed: int) -> None:
        self.__pos_x = pos_x
        self.__pos_y = pos_y
        self.__speed = speed

    # 不要動上面

    def move_right(self) -> None:
        pass

    def move_left(self) -> None:
        pass

    def move_up(self) -> None:
        pass

    def move_down(self) -> None:
        pass

    def get_position(self) -> tuple[int, int]:
        pass


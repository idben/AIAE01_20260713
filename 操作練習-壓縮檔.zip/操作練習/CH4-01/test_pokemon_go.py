import subprocess
import sys
from pathlib import Path

from main_pokemon_go import EggIncubator

TestCase = tuple[float, list[float], float, bool]

run_cases: list[TestCase] = [
    (2.0, [0.5, 0.5], 1.0, False),
    (5.0, [2.0, 3.0], 0.0, True),
]

submit_cases: list[TestCase] = run_cases + [
    (10.0, [3.0, 4.5], 2.5, False),
    (7.0, [8.0], 0.0, True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(egg_km: float, walked_distances: list[float], expected_remaining: float, expected_ready: bool) -> bool:
    print("---------------------------------")
    incubator = EggIncubator(egg_km)
    print(f"蛋距離：{egg_km} km")
    for km in walked_distances:
        print(f"走路：{km} km")
        incubator.walk(km)
    actual = (incubator.get_remaining_distance(), incubator.is_ready_to_hatch())
    expected = (expected_remaining, expected_ready)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

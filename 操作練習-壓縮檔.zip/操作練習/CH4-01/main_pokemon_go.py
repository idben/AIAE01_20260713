class EggIncubator:
    def __init__(self, egg_km: float) -> None:
        self.__egg_km = egg_km
        self.__walked_km = 0.0

    # 不要動上面

    def walk(self, km: float) -> None:
        pass

    def get_remaining_distance(self) -> float:
        pass

    def is_ready_to_hatch(self) -> bool:
        pass

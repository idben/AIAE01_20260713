class ShoppingCart:
    def __init__(self) -> None:
        # 請建立公開的 total 小計
        pass

    def add_amount(self, amount: int) -> None:
        # 請把商品金額加入自己的 total；多次加入時要累計，不是覆蓋
        pass

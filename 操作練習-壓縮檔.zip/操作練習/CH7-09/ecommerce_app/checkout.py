from ecommerce_app.cart import ShoppingCart


def add_to_cart(cart: ShoppingCart, product_name: str, amount: int) -> str:
    # 請呼叫 cart 的方法更新小計，並使用 checkout_message 裡已寫好的函式回傳結果
    pass

def format_cart_message(product_name: str, total: int) -> str:
    return f"加入 {product_name}，小計 {total} 元"

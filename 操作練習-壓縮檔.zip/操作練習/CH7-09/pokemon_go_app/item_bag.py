class ItemBag:
    def __init__(self) -> None:
        # 請建立公開的 items 字典
        pass

    def add_item(self, item_name: str, amount: int) -> None:
        # 請把道具數量加入自己的 items；同一道具再次取得時要累計，不是覆蓋
        pass

from pokemon_go_app.item_bag import ItemBag


def collect_reward(bag: ItemBag, item_name: str, amount: int) -> str:
    # 請呼叫 bag 的方法更新道具數量，並回傳取得結果
    pass

import contextlib
import importlib
import io
import subprocess
import sys
from pathlib import Path

from ecommerce_app.cart import ShoppingCart
from ecommerce_app.checkout import add_to_cart

TestCase = tuple[str, int, int, str]

test_cases: list[TestCase] = [
    ("機械鍵盤", 1800, 1800, "加入 機械鍵盤，小計 1800 元"),
    ("無線滑鼠", 650, 650, "加入 無線滑鼠，小計 650 元"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_add_to_cart(
    product_name: str, amount: int, expected_total: int, expected_label: str
) -> bool:
    print("---------------------------------")
    cart = ShoppingCart()
    actual_label = add_to_cart(cart, product_name, amount)
    print(f"輸入：{product_name}, {amount}")
    print(f"預期：{expected_label}, 小計 {expected_total}")
    print(f"實際：{actual_label}, 小計 {cart.total}")
    if actual_label == expected_label and cart.total == expected_total:
        print("通過")
        return True
    print("失敗")
    return False


def test_add_twice() -> bool:
    print("---------------------------------")
    cart = ShoppingCart()
    add_to_cart(cart, "機械鍵盤", 1800)
    add_to_cart(cart, "滑鼠墊", 250)
    actual = cart.total
    print("輸入：同一個購物車加入 1800 元與 250 元商品")
    print("預期：2050")
    print(f"實際：{actual}")
    if actual == 2050:
        print("通過")
        return True
    print("失敗")
    return False


def test_main_import() -> bool:
    print("---------------------------------")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        module = importlib.import_module("main_ecommerce")
    actual_output = output.getvalue()
    actual_demo = module.run_demo()
    expected_demo = "加入 機械鍵盤，小計 1800 元"
    print("輸入：匯入 main_ecommerce 並呼叫 run_demo()")
    print(f"預期：匯入無輸出，run_demo() 回傳 {expected_demo}")
    print(f"實際：匯入輸出 {actual_output!r}，run_demo() 回傳 {actual_demo}")
    if actual_output == "" and actual_demo == expected_demo:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results: list[bool] = []
    for case in test_cases:
        results.append(test_add_to_cart(*case))
    results.append(test_add_twice())
    results.append(test_main_import())
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

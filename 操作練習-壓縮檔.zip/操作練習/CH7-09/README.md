# CH7-09 練習

## 題目

完成一個多檔案小專案，練習類別、規則函式、主流程與測試匯入。

- 《勇者鬥惡龍》：藥草回復隊伍成員
- 《寶可夢 GO》：補給站道具加入背包
- 電子商務：商品加入購物車並結帳

## 檔案

- `dragon_quest_game/__init__.py`
- `dragon_quest_game/characters.py`
- `dragon_quest_game/items.py`
- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `pokemon_go_app/__init__.py`
- `pokemon_go_app/item_bag.py`
- `pokemon_go_app/pokestops.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `ecommerce_app/__init__.py`
- `ecommerce_app/cart.py`
- `ecommerce_app/checkout_message.py`
- `ecommerce_app/checkout.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先完成資料類別，確認公開屬性名稱和測試檔一致。
2. 完成物件自己的更新方法。
3. 完成規則函式，讓它修改傳進來的目標物件。
4. 完成 `run_demo()`，讓它回傳示範文字。
5. 用 main block 控制直接執行時才呼叫 `main()`。

三題的難度安排如下：

- 《勇者鬥惡龍》：整合套件、物件方法、規則函式與 main block。
- 《寶可夢 GO》：除了整合前面概念，還要從測試資料看出同一道具要累計，不是覆蓋。
- 電子商務：整合購物車狀態、結帳函式、已寫好的訊息格式化模組、主流程與 main block，並從測試看出金額要累計。

## 題目提示

《勇者鬥惡龍》：

- 先看測試檔匯入哪些套件模組與主檔案函式。
- `PartyMember` 要記住公開的 `name` 與 `hp`。
- `heal(amount)` 改的是隊伍成員自己。
- `use_medicinal_herb(member, heal_amount)` 改的是傳進來的 `member`，不是新建立的角色。
- `run_demo()` 要能被測試檔匯入後直接呼叫。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔的 `test_cases`，確認 HP 回復後的數字。
2. 再完成資料類別與自己的回復方法。
3. 接著完成道具函式，讓它使用傳進來的隊伍成員。
4. 最後處理 `run_demo()`、`main()` 與 main block。

《寶可夢 GO》：

- 先看測試檔除了單次領取，還測了同一道具重複領取。
- `ItemBag` 要記住公開屬性 `items`，因為測試會讀取目前道具數量。
- `add_item(item_name, amount)` 改的是背包自己。
- `collect_reward(bag, item_name, amount)` 改的是傳進來的 `bag`。
- `run_demo()` 要能被測試檔匯入後直接呼叫，匯入時不能自動輸出。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔如何讀取 `bag.items`。
2. 再觀察同一道具領取兩次時，預期數量怎麼變。
3. 接著完成背包自己的累計方法。
4. 然後完成補給站函式與回傳文字。
5. 最後處理主檔案的 `run_demo()` 與 main block。

電子商務：

- 先看測試檔除了單次加入商品，還測了同一個購物車重複加入商品。
- `ShoppingCart` 要記住公開屬性 `total`，因為測試會讀取目前小計。
- `add_amount(amount)` 改的是購物車自己。
- `add_to_cart(cart, product_name, amount)` 改的是傳進來的 `cart`。
- 已寫好的 `checkout_message.py` 會負責整理加入購物車後的顯示文字。
- `run_demo()` 要能被測試檔匯入後直接呼叫，匯入時不能自動輸出。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔如何讀取 `cart.total`。
2. 再觀察同一個購物車加入兩次商品時，預期小計怎麼變。
3. 接著完成購物車自己的累計方法。
4. 然後完成結帳函式，讓它更新購物車並使用已寫好的訊息格式化函式。
5. 最後處理主檔案的 `run_demo()` 與 main block。

## 檢查順序

1. 套件資料夾是否有 `__init__.py`。
2. 匯入路徑是否從套件名稱開始。
3. 方法是否更新同一個目標物件。
4. `run_demo()` 是否回傳字串。
5. 匯入 `main_*.py` 時是否沒有自動輸出。

## 這題常見錯誤

- 每次使用道具或補給站時建立新物件，原本傳入的物件沒有被更新。
- 同一道具再次取得時直接覆蓋數量，沒有加上原本數量。
- 購物車再次加入商品時直接覆蓋小計，沒有加上原本金額。
- `items` 寫成私有屬性，測試無法讀取。
- 忘記 main block，測試匯入時自動印出示範。
- `run_demo()` 只 `print()` 沒有 `return`。

## 這題在測什麼

- 套件與模組拆分
- OOP 狀態更新
- 主流程與測試匯入
- main block

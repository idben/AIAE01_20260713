from dragon_quest_game.characters import PartyMember
from dragon_quest_game.items import use_medicinal_herb


def run_demo() -> str:
    # 請建立勇者，使用藥草回復 30 HP，並回傳結果文字
    pass


def main() -> None:
    # 請印出 run_demo() 的結果
    pass


# 請在這裡加入 main block

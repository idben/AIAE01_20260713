import contextlib
import importlib
import io
import subprocess
import sys
from pathlib import Path

from pokemon_go_app.item_bag import ItemBag
from pokemon_go_app.pokestops import collect_reward

TestCase = tuple[str, int, int, str]

test_cases: list[TestCase] = [
    ("精靈球", 5, 5, "取得 5 個 精靈球"),
    ("傷藥", 2, 2, "取得 2 個 傷藥"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_collect_reward(
    item_name: str, amount: int, expected_amount: int, expected_label: str
) -> bool:
    print("---------------------------------")
    bag = ItemBag()
    actual_label = collect_reward(bag, item_name, amount)
    actual_amount = bag.items.get(item_name)
    print(f"輸入：{item_name}, {amount}")
    print(f"預期：{expected_label}, 數量 {expected_amount}")
    print(f"實際：{actual_label}, 數量 {actual_amount}")
    if actual_label == expected_label and actual_amount == expected_amount:
        print("通過")
        return True
    print("失敗")
    return False


def test_add_same_item_twice() -> bool:
    print("---------------------------------")
    bag = ItemBag()
    collect_reward(bag, "精靈球", 5)
    collect_reward(bag, "精靈球", 3)
    actual = bag.items.get("精靈球")
    print("輸入：同一個背包領取 5 個與 3 個精靈球")
    print("預期：8")
    print(f"實際：{actual}")
    if actual == 8:
        print("通過")
        return True
    print("失敗")
    return False


def test_main_import() -> bool:
    print("---------------------------------")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        module = importlib.import_module("main_pokemon_go")
    actual_output = output.getvalue()
    actual_demo = module.run_demo()
    expected_demo = "取得 5 個 精靈球"
    print("輸入：匯入 main_pokemon_go 並呼叫 run_demo()")
    print(f"預期：匯入無輸出，run_demo() 回傳 {expected_demo}")
    print(f"實際：匯入輸出 {actual_output!r}，run_demo() 回傳 {actual_demo}")
    if actual_output == "" and actual_demo == expected_demo:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results: list[bool] = []
    for case in test_cases:
        results.append(test_collect_reward(*case))
    results.append(test_add_same_item_twice())
    results.append(test_main_import())
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

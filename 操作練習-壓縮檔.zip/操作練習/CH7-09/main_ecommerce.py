from ecommerce_app.cart import ShoppingCart
from ecommerce_app.checkout import add_to_cart


def run_demo() -> str:
    # 請建立購物車，加入 1800 元的機械鍵盤，並回傳結果文字
    pass


def main() -> None:
    # 請印出 run_demo() 的結果
    pass


# 請在這裡加入 main block

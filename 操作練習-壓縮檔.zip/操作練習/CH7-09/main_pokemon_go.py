from pokemon_go_app.item_bag import ItemBag
from pokemon_go_app.pokestops import collect_reward


def run_demo() -> str:
    # 請建立背包，取得 5 個精靈球，並回傳結果文字
    pass


def main() -> None:
    # 請印出 run_demo() 的結果
    pass


# 請在這裡加入 main block

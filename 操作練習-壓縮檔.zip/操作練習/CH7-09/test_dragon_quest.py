import contextlib
import importlib
import io
import subprocess
import sys
from pathlib import Path

from dragon_quest_game.characters import PartyMember
from dragon_quest_game.items import use_medicinal_herb

TestCase = tuple[str, int, int, int, str]

test_cases: list[TestCase] = [
    ("勇者", 42, 30, 72, "勇者 回復到 72 HP"),
    ("僧侶", 18, 25, 43, "僧侶 回復到 43 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_use_item(
    name: str, hp: int, heal_amount: int, expected_hp: int, expected_label: str
) -> bool:
    print("---------------------------------")
    member = PartyMember(name, hp)
    actual_label = use_medicinal_herb(member, heal_amount)
    print(f"輸入：{name}, {hp}, {heal_amount}")
    print(f"預期：{expected_label}, HP {expected_hp}")
    print(f"實際：{actual_label}, HP {member.hp}")
    if actual_label == expected_label and member.hp == expected_hp:
        print("通過")
        return True
    print("失敗")
    return False


def test_main_import() -> bool:
    print("---------------------------------")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        module = importlib.import_module("main_dragon_quest")
    actual_output = output.getvalue()
    actual_demo = module.run_demo()
    expected_demo = "勇者 回復到 72 HP"
    print("輸入：匯入 main_dragon_quest 並呼叫 run_demo()")
    print(f"預期：匯入無輸出，run_demo() 回傳 {expected_demo}")
    print(f"實際：匯入輸出 {actual_output!r}，run_demo() 回傳 {actual_demo}")
    if actual_output == "" and actual_demo == expected_demo:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results: list[bool] = []
    for case in test_cases:
        results.append(test_use_item(*case))
    results.append(test_main_import())
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

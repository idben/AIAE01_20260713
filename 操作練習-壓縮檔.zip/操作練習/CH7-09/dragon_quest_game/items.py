from dragon_quest_game.characters import PartyMember


def use_medicinal_herb(member: PartyMember, heal_amount: int) -> str:
    # 請呼叫 member 的方法更新 HP，並回傳道具使用結果
    pass

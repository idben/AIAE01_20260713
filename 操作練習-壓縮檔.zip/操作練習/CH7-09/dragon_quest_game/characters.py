class PartyMember:
    def __init__(self, name: str, hp: int) -> None:
        # 請讓隊伍成員記住 name 與 hp
        pass

    def heal(self, amount: int) -> None:
        # 請讓自己回復 HP
        pass

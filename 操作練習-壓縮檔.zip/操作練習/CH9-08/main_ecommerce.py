from functools import wraps


def require_stock(original_function):
    @wraps(original_function)
    def wrapper(cart: dict[str, object], product: dict[str, object], quantity: int):
        # 請先檢查庫存，不足時回傳錯誤訊息，足夠時才呼叫原函式
        raise NotImplementedError("請完成 require_stock.wrapper")

    return wrapper


@require_stock
def add_product_to_cart(
    cart: dict[str, object],
    product: dict[str, object],
    quantity: int,
) -> str:
    # 請更新購物車 total、items，並扣除 product["stock"]
    raise NotImplementedError("請完成 add_product_to_cart")

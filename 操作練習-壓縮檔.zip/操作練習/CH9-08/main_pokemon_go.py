from functools import wraps


def require_remote_raid_pass(original_function):
    @wraps(original_function)
    def wrapper(trainer: dict[str, object], raid_name: str):
        # 請先檢查遠距團體戰入場券，足夠時才扣券並呼叫原函式
        raise NotImplementedError("請完成 require_remote_raid_pass.wrapper")

    return wrapper


@require_remote_raid_pass
def join_remote_raid(trainer: dict[str, object], raid_name: str) -> str:
    # 請把 raid_name 加入 joined_raids，並回傳參加訊息
    raise NotImplementedError("請完成 join_remote_raid")

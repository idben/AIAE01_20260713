import subprocess
import sys

from pathlib import Path

from main_ecommerce import add_product_to_cart

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_add_product_success() -> bool:
    print("---------------------------------")
    cart = {"items": [], "total": 0}
    product = {"name": "鍵盤", "price": 1200, "stock": 5}
    message = add_product_to_cart(cart, product, 2)
    expected_message = "加入 鍵盤 x2，小計 2400 元"
    expected_state = (["鍵盤"], 2400, 3)
    actual_state = (cart["items"], cart["total"], product["stock"])
    print("輸入：鍵盤 price=1200 stock=5，quantity=2")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def test_add_product_not_enough_stock() -> bool:
    print("---------------------------------")
    cart = {"items": [], "total": 0}
    product = {"name": "滑鼠", "price": 800, "stock": 1}
    message = add_product_to_cart(cart, product, 3)
    expected_message = "滑鼠 庫存不足"
    expected_state = ([], 0, 1)
    actual_state = (cart["items"], cart["total"], product["stock"])
    print("輸入：滑鼠 price=800 stock=1，quantity=3")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_add_product_success(), test_add_product_not_enough_stock()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import basic_attack

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_basic_attack_success() -> bool:
    print("---------------------------------")
    hero = {"name": "勇者", "hp": 18, "attack": 6}
    monster = {"name": "史萊姆", "hp": 20}
    message = basic_attack(hero, monster)
    expected_message = "勇者 攻擊 史萊姆"
    expected_state = 14
    actual_state = monster["hp"]
    print("輸入：勇者 hp=18 attack=6，史萊姆 hp=20")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def test_basic_attack_attacker_fainted() -> bool:
    print("---------------------------------")
    hero = {"name": "勇者", "hp": 0, "attack": 6}
    monster = {"name": "史萊姆", "hp": 20}
    message = basic_attack(hero, monster)
    expected_message = "勇者 已經倒下，不能攻擊"
    expected_state = 20
    actual_state = monster["hp"]
    print("輸入：勇者 hp=0，史萊姆 hp=20")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_basic_attack_success(), test_basic_attack_attacker_fainted()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

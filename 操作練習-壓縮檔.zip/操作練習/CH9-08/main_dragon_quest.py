from functools import wraps


def require_attacker_alive(original_function):
    @wraps(original_function)
    def wrapper(attacker: dict[str, object], target: dict[str, object]):
        # 請先檢查攻擊者是否倒下，倒下時不要呼叫原函式
        raise NotImplementedError("請完成 require_attacker_alive.wrapper")

    return wrapper


@require_attacker_alive
def basic_attack(attacker: dict[str, object], target: dict[str, object]) -> str:
    # 請讓目標扣除 attacker["attack"]，並回傳攻擊訊息
    raise NotImplementedError("請完成 basic_attack")

import subprocess
import sys

from pathlib import Path

from main_pokemon_go import join_remote_raid

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_join_remote_raid_success() -> bool:
    print("---------------------------------")
    trainer = {"name": "訓練家", "remote_raid_passes": 2, "joined_raids": []}
    message = join_remote_raid(trainer, "噴火龍團體戰")
    expected_message = "訓練家 參加 噴火龍團體戰"
    expected_state = (1, ["噴火龍團體戰"])
    actual_state = (trainer["remote_raid_passes"], trainer["joined_raids"])
    print("輸入：remote_raid_passes=2，噴火龍團體戰")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def test_join_remote_raid_no_pass() -> bool:
    print("---------------------------------")
    trainer = {"name": "訓練家", "remote_raid_passes": 0, "joined_raids": []}
    message = join_remote_raid(trainer, "水箭龜團體戰")
    expected_message = "訓練家 沒有遠距團體戰入場券"
    expected_state = (0, [])
    actual_state = (trainer["remote_raid_passes"], trainer["joined_raids"])
    print("輸入：remote_raid_passes=0，水箭龜團體戰")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期狀態：{expected_state}")
    print(f"實際狀態：{actual_state}")
    if message == expected_message and actual_state == expected_state:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_join_remote_raid_success(), test_join_remote_raid_no_pass()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

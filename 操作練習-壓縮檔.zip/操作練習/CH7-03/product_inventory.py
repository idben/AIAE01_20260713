class ProductInventory:
    def __init__(self, product_name: str, stock: int) -> None:
        # 請讓商品庫存記住 product_name 與 stock
        pass

    def reserve(self, quantity: int) -> None:
        # 請讓自己保留庫存
        pass

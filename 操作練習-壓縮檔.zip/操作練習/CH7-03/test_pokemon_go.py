import subprocess
import sys
from pathlib import Path

from pokemon_go import RaidPokemon
from raid_pokemon_go import use_charged_move

TestCase = tuple[str, int, str, int, int, int, str]

test_cases: list[TestCase] = [
    ("路卡利歐", 100, "卡比獸", 180, 35, 145, "路卡利歐 使用蓄力招式，卡比獸 剩下 145 HP"),
    ("超夢", 120, "班基拉斯", 150, 42, 108, "超夢 使用蓄力招式，班基拉斯 剩下 108 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    attacker_name: str,
    attacker_hp: int,
    target_name: str,
    target_hp: int,
    damage: int,
    expected_hp: int,
    expected_label: str,
) -> bool:
    print("---------------------------------")
    attacker = RaidPokemon(attacker_name, attacker_hp)
    target = RaidPokemon(target_name, target_hp)
    actual_label = use_charged_move(attacker, target, damage)
    print(f"輸入：{attacker_name}, {target_name}, {damage}")
    print(f"預期：{expected_label}, 目標 HP {expected_hp}")
    print(f"實際：{actual_label}, 目標 HP {target.hp}")
    if actual_label == expected_label and target.hp == expected_hp:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from characters_dragon_quest import PartyMember


def cast_spell(caster: PartyMember, target: PartyMember, damage: int) -> str:
    # 請呼叫目標物件的方法，並回傳戰鬥文字
    pass

class RaidPokemon:
    def __init__(self, name: str, hp: int) -> None:
        # 請讓團體戰寶可夢記住 name 與 hp
        pass

    def take_damage(self, damage: int) -> None:
        # 請讓自己承受傷害
        pass

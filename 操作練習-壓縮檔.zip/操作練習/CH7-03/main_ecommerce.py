from order_service import place_order
from product_inventory import ProductInventory


def run_demo() -> str:
    keyboard = ProductInventory("機械鍵盤", 10)
    return place_order(keyboard, 3)


if __name__ == "__main__":
    print(run_demo())

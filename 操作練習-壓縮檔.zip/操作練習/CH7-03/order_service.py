from product_inventory import ProductInventory


def place_order(product: ProductInventory, quantity: int) -> str:
    # 請呼叫商品庫存物件的方法更新庫存，並回傳訂單文字
    pass

import subprocess
import sys
from pathlib import Path

from battle_dragon_quest import cast_spell
from characters_dragon_quest import PartyMember

TestCase = tuple[str, int, str, int, int, int, str]

test_cases: list[TestCase] = [
    ("勇者", 120, "史萊姆", 30, 18, 12, "勇者 施放咒文，史萊姆 剩下 12 HP"),
    ("僧侶", 90, "龍", 160, 45, 115, "僧侶 施放咒文，龍 剩下 115 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    caster_name: str,
    caster_hp: int,
    target_name: str,
    target_hp: int,
    damage: int,
    expected_hp: int,
    expected_label: str,
) -> bool:
    print("---------------------------------")
    caster = PartyMember(caster_name, caster_hp)
    target = PartyMember(target_name, target_hp)
    actual_label = cast_spell(caster, target, damage)
    print(f"輸入：{caster_name}, {target_name}, {damage}")
    print(f"預期：{expected_label}, 目標 HP {expected_hp}")
    print(f"實際：{actual_label}, 目標 HP {target.hp}")
    if actual_label == expected_label and target.hp == expected_hp:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys
from pathlib import Path

from order_service import place_order
from product_inventory import ProductInventory

TestCase = tuple[str, int, int, int, str]

test_cases: list[TestCase] = [
    ("機械鍵盤", 10, 3, 7, "訂單成立：機械鍵盤 剩下 7 件"),
    ("無線滑鼠", 25, 4, 21, "訂單成立：無線滑鼠 剩下 21 件"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    product_name: str,
    stock: int,
    quantity: int,
    expected_stock: int,
    expected_label: str,
) -> bool:
    print("---------------------------------")
    product = ProductInventory(product_name, stock)
    actual_label = place_order(product, quantity)
    print(f"輸入：{product_name}, 原本庫存 {stock}, 購買 {quantity}")
    print(f"預期：{expected_label}, 剩餘庫存 {expected_stock}")
    print(f"實際：{actual_label}, 剩餘庫存 {product.stock}")
    if actual_label == expected_label and product.stock == expected_stock:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from pokemon_go import RaidPokemon


def use_charged_move(
    attacker: RaidPokemon, target: RaidPokemon, damage: int
) -> str:
    # 請呼叫目標物件的方法，並回傳團體戰文字
    pass

from battle_dragon_quest import cast_spell
from characters_dragon_quest import PartyMember


def run_demo() -> str:
    hero = PartyMember("勇者", 120)
    slime = PartyMember("史萊姆", 30)
    return cast_spell(hero, slime, 18)


if __name__ == "__main__":
    print(run_demo())

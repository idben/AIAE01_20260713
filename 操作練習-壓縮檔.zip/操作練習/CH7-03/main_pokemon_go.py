from pokemon_go import RaidPokemon
from raid_pokemon_go import use_charged_move


def run_demo() -> str:
    lucario = RaidPokemon("路卡利歐", 100)
    snorlax = RaidPokemon("卡比獸", 180)
    return use_charged_move(lucario, snorlax, 35)


if __name__ == "__main__":
    print(run_demo())

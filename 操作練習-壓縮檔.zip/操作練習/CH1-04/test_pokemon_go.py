import subprocess
import sys
from pathlib import Path

from main_pokemon_go import Pokemon, fight_pokemon, get_pokemon_dps

TestCase = tuple[Pokemon, Pokemon, str]

run_cases: list[TestCase] = [
    (
        {"damage": 10, "attacks_per_second": 3},
        {"damage": 20, "attacks_per_second": 1},
        "pokemon 1 wins",
    ),
    (
        {"damage": 50, "attacks_per_second": 1},
        {"damage": 50, "attacks_per_second": 2},
        "pokemon 2 wins",
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        {"damage": 1, "attacks_per_second": 1},
        {"damage": 2, "attacks_per_second": 1},
        "pokemon 2 wins",
    ),
    (
        {"damage": 100, "attacks_per_second": 2},
        {"damage": 50, "attacks_per_second": 4},
        "both faint",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(pokemon_one: Pokemon, pokemon_two: Pokemon, expected: str) -> bool:
    print("---------------------------------")
    print("寶可夢一：")
    print(f"  damage: {pokemon_one['damage']}")
    print(f"  attacks_per_second: {pokemon_one['attacks_per_second']}")
    print("寶可夢二：")
    print(f"  damage: {pokemon_two['damage']}")
    print(f"  attacks_per_second: {pokemon_two['attacks_per_second']}")
    print(f"預期：    {expected}")
    try:
        result = fight_pokemon(pokemon_one, pokemon_two)
        print(f"實際：    {result}")
        if result != expected:
            print("失敗")
            return False
        actual_one = get_pokemon_dps(pokemon_one)
        actual_two = get_pokemon_dps(pokemon_two)
        expected_one = pokemon_one["damage"] * pokemon_one["attacks_per_second"]
        expected_two = pokemon_two["damage"] * pokemon_two["attacks_per_second"]
        if actual_one != expected_one:
            print(f"預期的寶可夢一 DPS：{expected_one}")
            print(f"實際的寶可夢一 DPS：{actual_one}")
            return False
        if actual_two != expected_two:
            print(f"預期的寶可夢二 DPS：{expected_two}")
            print(f"實際的寶可夢二 DPS：{actual_two}")
            return False
        print("通過")
        return True
    except Exception as e:
        print(f"錯誤：    {e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

Spell = dict[str, int]


def compare_spells(spell_one: Spell, spell_two: Spell) -> str:
    spell_one_mp_cost = spell_one["base_cost"] + spell_one["level_scale"]
    spell_two_mp_cost = spell_two["base_cost"] + spell_two["level_scale"]
    if spell_one_mp_cost < spell_two_mp_cost:
        return "spell 1 costs less"
    if spell_two_mp_cost < spell_one_mp_cost:
        return "spell 2 costs less"
    return "both spells cost the same"

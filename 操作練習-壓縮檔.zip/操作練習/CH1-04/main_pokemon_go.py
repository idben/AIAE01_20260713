Pokemon = dict[str, int]


def fight_pokemon(pokemon_one: Pokemon, pokemon_two: Pokemon) -> str:
    pokemon_one_dps = pokemon_one["damage"] * pokemon_one["attacks_per_second"]
    pokemon_two_dps = pokemon_two["damage"] * pokemon_two["attacks_per_second"]
    if pokemon_one_dps > pokemon_two_dps:
        return "pokemon 1 wins"
    if pokemon_two_dps > pokemon_one_dps:
        return "pokemon 2 wins"
    return "both faint"

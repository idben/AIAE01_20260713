from pathlib import Path


def load_egg_note(note_path: Path) -> str:
    # 請依課文規則處理成功讀取與缺檔例外
    raise NotImplementedError("請完成 load_egg_note")


def main() -> None:
    print(load_egg_note(Path("egg_note.txt")))


if __name__ == "__main__":
    main()

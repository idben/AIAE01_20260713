# CH10-04 練習

## 題目

練習處理檔案不存在時的錯誤訊息。

- 《勇者鬥惡龍》版：讀取任務紀錄檔。
- 《寶可夢 GO》版：讀取孵蛋紀錄檔，成功時清掉前後空白。
- 電子商務版：讀取訂單紀錄檔。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

名稱對照：

- `load_quest_note`：讀取任務紀錄文字
- `load_egg_note`：讀取孵蛋紀錄文字
- `load_order_note`：讀取訂單紀錄文字
- `note_path`：紀錄檔路徑
- `FileNotFoundError`：檔案不存在時的例外

成功時回傳檔案文字。檔案不存在時，要丟出指定的 `FileNotFoundError`，錯誤訊息必須包含路徑。《寶可夢 GO》版成功讀到文字後，還要清掉前後空白。

錯誤訊息格式：

- 《勇者鬥惡龍》：`找不到任務紀錄檔：{note_path}`
- 《寶可夢 GO》：`找不到孵蛋紀錄檔：{note_path}`
- 電子商務：`找不到訂單紀錄檔：{note_path}`

操作順序：

- 《勇者鬥惡龍》：處理任務紀錄檔不存在。
- 《寶可夢 GO》：處理孵蛋紀錄檔不存在，成功時還要清理讀到的文字。
- 電子商務：處理訂單紀錄檔不存在，錯誤訊息仍要包含實際路徑。

## 常見錯誤

- 檔案不存在時回傳空字串。
- 錯誤訊息和測試檔期待不一致。
- 成功時只 `print()`，沒有 `return`。

## 你會練到什麼

- `FileNotFoundError`
- 清楚的例外訊息
- 讀取失敗時不假裝成功

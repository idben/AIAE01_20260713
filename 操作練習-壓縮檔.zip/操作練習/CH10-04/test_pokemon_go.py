from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_pokemon_go import load_egg_note


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_egg_note_success() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        path = Path(folder) / "egg_note.txt"
        path.write_text("  2km 蛋已走 1.2km\n", encoding="utf-8")
        actual = load_egg_note(path)
    expected = "2km 蛋已走 1.2km"
    print("輸入：存在且前後有空白的孵蛋紀錄檔")
    print(f"預期：{expected!r}")
    print(f"實際：{actual!r}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_load_egg_note_missing() -> bool:
    print("---------------------------------")
    path = Path("missing_egg_note.txt")
    try:
        load_egg_note(path)
    except FileNotFoundError as error:
        actual = str(error)
    else:
        actual = "沒有丟出 FileNotFoundError"
    expected = f"找不到孵蛋紀錄檔：{path}"
    print("輸入：不存在的孵蛋紀錄檔")
    print(f"預期錯誤：{expected}")
    print(f"實際錯誤：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_load_egg_note_success(), test_load_egg_note_missing()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

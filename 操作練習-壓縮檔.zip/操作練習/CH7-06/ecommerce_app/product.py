class Product:
    def __init__(self, name: str, price: int) -> None:
        # 請讓商品資料記住 name 與 price
        pass

def add_sales_tax(price: int) -> int:
    return price + price // 20

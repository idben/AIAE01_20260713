
def get_price_label(product: Product) -> str:
    # 請 import 並使用已寫好的 add_sales_tax()
    pass

# CH7-06 練習

## 題目

用套件資料夾整理多個模組。

- 《勇者鬥惡龍》：`dragon_quest_game`
- 《寶可夢 GO》：`pokemon_go_app`
- 電子商務：`ecommerce_app`

## 檔案

- `dragon_quest_game/__init__.py`
- `dragon_quest_game/characters.py`
- `dragon_quest_game/status.py`
- `test_dragon_quest.py`
- `pokemon_go_app/__init__.py`
- `pokemon_go_app/egg.py`
- `pokemon_go_app/distance_rules.py`
- `pokemon_go_app/hatching.py`
- `test_pokemon_go.py`
- `ecommerce_app/__init__.py`
- `ecommerce_app/product.py`
- `ecommerce_app/tax_rules.py`
- `ecommerce_app/pricing.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先確認套件資料夾中有 `__init__.py`。
2. 完成資料類別。
3. 在規則模組中從套件名稱開始匯入資料類別。
4. 讓規則函式回傳文字，不要直接 `print()`。

三題的難度安排如下：

- 《勇者鬥惡龍》：提示會指出資料模組與狀態模組的分工。
- 《寶可夢 GO》：請從測試檔觀察套件匯入路徑，並使用已寫好的距離規則判斷孵化提示。
- 電子商務：請從套件資料夾與測試檔觀察商品資料、已寫好的稅金規則和定價顯示的分工。

## 題目提示

### 《勇者鬥惡龍》

- `get_status(member)` 放在 `status.py`。
- 它收到隊伍成員物件，不修改它，只回傳狀態文字。
- 匯入資料類別時，請從套件名稱 `dragon_quest_game` 開始寫。

作答時建議照這個順序觀察與判斷：

1. 先確認套件資料夾與檔案名稱。
2. 再看測試檔的 import 寫法。
3. 接著完成 `PartyMember` 公開屬性。
4. 最後回傳狀態文字，不要直接 `print()`。

### 《寶可夢 GO》

- 已寫好的模組是 `pokemon_go_app/distance_rules.py`。
- `get_hatch_label(egg, walked_km)` 收到孵蛋資料與已行走距離。
- 這個函式不修改物件，要使用已寫好的距離規則回傳孵化提示文字。
- 請從測試檔觀察 `Egg` 與 `get_hatch_label()` 各自在哪個模組。

作答時建議照這個順序觀察與判斷：

1. 先看 `pokemon_go_app` 裡有哪些檔案。
2. 再看測試檔的 import 路徑。
3. 接著從測試資料判斷孵蛋物件需要保存哪些資料。
4. 再打開 `distance_rules.py`，確認已提供的函式名稱與參數。
5. 最後讓孵化提示函式使用傳進來的孵蛋物件與已寫好的距離規則回傳文字。

### 電子商務

- 已寫好的模組是 `ecommerce_app/tax_rules.py`。
- `get_price_label(product)` 收到商品資料。
- 這個函式不修改物件，要使用已寫好的稅金規則回傳含稅價格文字。
- 請從測試檔觀察 `Product` 與 `get_price_label()` 各自在哪個模組。

作答時建議照這個順序觀察與判斷：

1. 先看 `ecommerce_app` 裡有哪些檔案。
2. 再看測試檔的 import 路徑。
3. 接著從測試資料判斷商品物件需要保存哪些資料。
4. 再打開 `tax_rules.py`，確認已提供的函式名稱與參數。
5. 最後讓定價函式使用傳進來的商品物件與已寫好的稅金函式回傳文字。

## 這題常見錯誤

- 少了 `__init__.py`。
- 在套件內使用錯誤匯入路徑。
- 函式只印出文字，沒有回傳。

## 這題在測什麼

- 套件基礎
- 從套件名稱開始匯入
- 模組化後的測試匯入

import subprocess
import sys
from pathlib import Path

from dragon_quest_game.characters import PartyMember
from dragon_quest_game.status import get_status

TestCase = tuple[str, int, str]

test_cases: list[TestCase] = [
    ("勇者", 120, "勇者: 120 HP"),
    ("僧侶", 80, "僧侶: 80 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(name: str, hp: int, expected: str) -> bool:
    print("---------------------------------")
    member = PartyMember(name, hp)
    actual = get_status(member)
    print(f"輸入：{name}, {hp}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

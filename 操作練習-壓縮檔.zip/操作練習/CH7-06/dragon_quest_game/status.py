
def get_status(member: PartyMember) -> str:
    # 請回傳隊伍成員狀態文字
    pass

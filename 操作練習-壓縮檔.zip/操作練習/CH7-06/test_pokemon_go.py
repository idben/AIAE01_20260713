import subprocess
import sys
from pathlib import Path

from pokemon_go_app.egg import Egg
from pokemon_go_app.hatching import get_hatch_label

TestCase = tuple[float, float, str]

test_cases: list[TestCase] = [
    (5.0, 3.5, "5.0 公里蛋還差 1.5 公里"),
    (2.0, 2.4, "2.0 公里蛋可以孵化"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(required_km: float, walked_km: float, expected: str) -> bool:
    print("---------------------------------")
    egg = Egg(required_km)
    actual = get_hatch_label(egg, walked_km)
    print(f"輸入：{required_km} 公里蛋，已走 {walked_km} 公里")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

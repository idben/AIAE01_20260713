import subprocess
import sys
from pathlib import Path

from ecommerce_app.pricing import get_price_label
from ecommerce_app.product import Product

TestCase = tuple[str, int, str]

test_cases: list[TestCase] = [
    ("機械鍵盤", 1800, "機械鍵盤: 含稅 1890 元"),
    ("無線滑鼠", 650, "無線滑鼠: 含稅 682 元"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(name: str, price: int, expected: str) -> bool:
    print("---------------------------------")
    product = Product(name, price)
    actual = get_price_label(product)
    print(f"輸入：{name}, {price}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

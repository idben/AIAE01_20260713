def get_remaining_km(required_km: float, walked_km: float) -> float:
    remaining = required_km - walked_km
    if remaining < 0:
        return 0.0
    return remaining

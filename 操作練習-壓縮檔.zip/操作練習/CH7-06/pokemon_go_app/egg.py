class Egg:
    def __init__(self, required_km: float) -> None:
        # 請讓孵蛋資料記住 required_km
        pass

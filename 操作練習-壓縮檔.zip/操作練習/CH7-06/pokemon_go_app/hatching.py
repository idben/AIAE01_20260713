

def get_hatch_label(egg: Egg, walked_km: float) -> str:
    # 請 import 並使用 已寫好的 get_remaining_km()
    pass

# CH5-01 練習

## 題目

這一課練習最基本的繼承。

- 《勇者鬥惡龍》版：完成 `Archer(Human)`
- 《寶可夢 GO》版：完成 `CatchEncounter(Encounter)`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先看父類別已經記住什麼資料
2. 再打開對應的 `main_*.py`
3. 讓子類別先用 `super().__init__(...)` 完成共通初始化
4. 最後補上子類別自己的資源欄位與 getter
5. 執行測試確認結果

## 常見錯誤

- 忘記把子類別寫成 `class Child(Parent):`
- 建構子沒有呼叫 `super()`
- 子類別專屬屬性沒有存到 `self`

## 這題在測什麼

- 繼承基本語法
- 父類別與子類別的責任分工
- 子類別初始化順序

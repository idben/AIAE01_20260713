import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Archer, Human

TestCase = tuple[str, str, int | None]

run_cases: list[TestCase] = [
    ("瑪尼亞", "Human", None),
    ("比安卡", "Archer", 8),
]

submit_cases: list[TestCase] = run_cases + [
    ("芙蘿拉", "Human", None),
    ("庫庫爾", "Archer", 15),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test_inheritance() -> bool:
    print("---------------------------------")
    print("檢查繼承關係")
    if not issubclass(Archer, Human):
        print("失敗：Archer 沒有繼承 Human")
        return False
    print("通過：Archer 有繼承 Human")
    return True


def test(name: str, unit_type: str, num_arrows: int | None) -> bool:
    print("---------------------------------")
    print(f"類型：{unit_type}")
    print(f"名稱：{name}")
    try:
        if unit_type == "Human":
            human = Human(name)
            actual = human.get_name()
            print(f"預期名稱：{name}")
            print(f"實際名稱：{actual}")
            return actual == name
        archer = Archer(name, num_arrows or 0)
        print(f"預期名稱：{name}")
        print(f"實際名稱：{archer.get_name()}")
        print(f"預期箭數：{num_arrows}")
        print(f"實際箭數：{archer.get_num_arrows()}")
        return archer.get_name() == name and archer.get_num_arrows() == num_arrows
    except Exception as error:
        print(f"失敗：{error}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    if test_inheritance():
        passed += 1
    else:
        failed += 1
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

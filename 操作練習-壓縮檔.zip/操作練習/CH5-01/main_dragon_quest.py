class Human:
    def __init__(self, name: str) -> None:
        self.__name = name

    def get_name(self) -> str:
        return self.__name


## 以上內容不要修改


class Archer:
    def __init__(self, name: str, num_arrows: int) -> None:
        pass

    def get_num_arrows(self) -> int:
        pass

class Encounter:
    def __init__(self, pokemon_name: str) -> None:
        self.__pokemon_name = pokemon_name

    def get_pokemon_name(self) -> str:
        return self.__pokemon_name


## 以上內容不要修改


class CatchEncounter:
    def __init__(self, pokemon_name: str, poke_balls: int) -> None:
        pass

    def get_poke_balls(self) -> int:
        pass

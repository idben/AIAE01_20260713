import subprocess
import sys
from pathlib import Path

from main_pokemon_go import CatchEncounter, Encounter

TestCase = tuple[str, str, int | None]

run_cases: list[TestCase] = [
    ("Pikachu", "Encounter", None),
    ("Eevee", "CatchEncounter", 6),
]

submit_cases: list[TestCase] = run_cases + [
    ("Snorlax", "Encounter", None),
    ("Bulbasaur", "CatchEncounter", 12),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test_inheritance() -> bool:
    print("---------------------------------")
    print("檢查繼承關係")
    if not issubclass(CatchEncounter, Encounter):
        print("失敗：CatchEncounter 沒有繼承 Encounter")
        return False
    print("通過：CatchEncounter 有繼承 Encounter")
    return True


def test(name: str, unit_type: str, poke_balls: int | None) -> bool:
    print("---------------------------------")
    print(f"類型：{unit_type}")
    print(f"寶可夢：{name}")
    try:
        if unit_type == "Encounter":
            encounter = Encounter(name)
            actual = encounter.get_pokemon_name()
            print(f"預期名稱：{name}")
            print(f"實際名稱：{actual}")
            return actual == name
        encounter = CatchEncounter(name, poke_balls or 0)
        print(f"預期名稱：{name}")
        print(f"實際名稱：{encounter.get_pokemon_name()}")
        print(f"預期球數：{poke_balls}")
        print(f"實際球數：{encounter.get_poke_balls()}")
        return encounter.get_pokemon_name() == name and encounter.get_poke_balls() == poke_balls
    except Exception as error:
        print(f"失敗：{error}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    if test_inheritance():
        passed += 1
    else:
        failed += 1
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

import json
from pathlib import Path


def save_order_config(config_path: Path, order_data: dict[str, object]) -> None:
    # 請建立父資料夾，並把 order_data 寫成 JSON
    raise NotImplementedError("請完成 save_order_config")


def load_order_config(config_path: Path) -> dict[str, object]:
    # 請讀取 JSON，並回傳 Python 字典
    raise NotImplementedError("請完成 load_order_config")


def main() -> None:
    path = Path("data") / "order_config.json"
    save_order_config(path, {"shop": "台北門市", "statuses": ["已付款"]})
    print(load_order_config(path))


if __name__ == "__main__":
    main()

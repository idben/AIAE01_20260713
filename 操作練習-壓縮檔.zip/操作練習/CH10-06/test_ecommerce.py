from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import load_order_config, save_order_config


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_save_and_load_order_config() -> bool:
    cases = [
        ({"shop": "台北門市", "statuses": ["已付款", "待處理"], "free_shipping_threshold": 1000}, ["台北門市", "已付款"]),
        ({"shop": "高雄分店", "statuses": ["已出貨", "取消"], "free_shipping_threshold": 1500}, ["高雄分店", "已出貨"]),
    ]
    all_passed = True
    for index, (expected, required_texts) in enumerate(cases, start=1):
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "data" / f"order_config_{index}.json"
            save_order_config(path, expected)
            raw_text = path.read_text(encoding="utf-8")
            actual = load_order_config(path)
        print("輸入：訂單設定字典")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        print("預期：JSON 原始文字保留中文")
        print(f"實際原始文字：{raw_text}")
        if actual == expected and all(text in raw_text for text in required_texts):
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_save_and_load_order_config()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

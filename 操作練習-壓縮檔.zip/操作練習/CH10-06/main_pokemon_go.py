import json
from pathlib import Path


def save_spawn_config(config_path: Path, spawn_data: dict[str, object]) -> None:
    # 請建立父資料夾，並把 spawn_data 寫成 JSON
    raise NotImplementedError("請完成 save_spawn_config")


def load_spawn_config(config_path: Path) -> dict[str, object]:
    # 請讀取 JSON，並回傳 Python 字典
    raise NotImplementedError("請完成 load_spawn_config")


def main() -> None:
    path = Path("data") / "spawn_config.json"
    save_spawn_config(path, {"area": "台北公園", "nearby": ["皮卡丘"]})
    print(load_spawn_config(path))


if __name__ == "__main__":
    main()

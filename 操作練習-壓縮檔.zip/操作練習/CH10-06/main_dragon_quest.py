import json
from pathlib import Path


def save_party_config(config_path: Path, party_data: dict[str, object]) -> None:
    # 請建立父資料夾，並把 party_data 寫成 JSON
    raise NotImplementedError("請完成 save_party_config")


def load_party_config(config_path: Path) -> dict[str, object]:
    # 請讀取 JSON，並回傳 Python 字典
    raise NotImplementedError("請完成 load_party_config")


def main() -> None:
    path = Path("data") / "party_config.json"
    save_party_config(path, {"leader": "勇者", "spells": ["荷伊米"]})
    print(load_party_config(path))


if __name__ == "__main__":
    main()

from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_dragon_quest import load_party_config, save_party_config


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_save_and_load_party_config() -> bool:
    cases = [
        ({"leader": "勇者", "spells": ["荷伊米", "基拉"], "gold": 120}, ["勇者", "荷伊米"]),
        ({"leader": "僧侶", "spells": ["貝霍伊米"], "gold": 45, "active": True}, ["僧侶", "貝霍伊米"]),
    ]
    all_passed = True
    for index, (expected, required_texts) in enumerate(cases, start=1):
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "data" / f"party_config_{index}.json"
            save_party_config(path, expected)
            raw_text = path.read_text(encoding="utf-8")
            actual = load_party_config(path)
        print("輸入：隊伍設定字典")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        print("預期：JSON 原始文字保留中文")
        print(f"實際原始文字：{raw_text}")
        if actual == expected and all(text in raw_text for text in required_texts):
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_save_and_load_party_config()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

# CH10-06 練習

## 題目

練習讀寫 JSON 檔案。

- 《勇者鬥惡龍》版：保存與讀取隊伍設定。
- 《寶可夢 GO》版：保存與讀取附近出現設定。
- 電子商務版：保存與讀取訂單設定。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

名稱對照：

- `save_party_config`：保存隊伍設定
- `load_party_config`：讀取隊伍設定
- `save_spawn_config`：保存附近出現設定
- `load_spawn_config`：讀取附近出現設定
- `save_order_config`：保存訂單設定
- `load_order_config`：讀取訂單設定
- `config_path`：設定檔路徑
- `party_data` / `spawn_data` / `order_data`：要保存的設定資料

寫入前要建立父資料夾。寫入 JSON 時使用 `ensure_ascii=False`，避免中文變成跳脫文字。讀取函式要回傳 Python 字典。三個版本使用的 JSON 方法相同，但檢查重點不同：基本保存、中文保留、設定資料讀回後能直接使用。

操作順序：

- 《勇者鬥惡龍》：保存隊伍設定。
- 《寶可夢 GO》：保存附近出現設定，仍需保留中文原始文字。
- 電子商務：保存訂單設定，資料包含狀態清單與免運門檻，讀回後要完全一致。

## 常見錯誤

- 忘記建立父資料夾。
- 寫入後沒有辦法用 `json.loads()` 讀回。
- 讀取函式只印出資料，沒有回傳。

## 你會練到什麼

- `json.dump()` 或 `json.dumps()`
- `json.load()` 或 `json.loads()`
- JSON 檔案讀寫

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import cast_priest_spell

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_vocation_allowed() -> bool:
    print("---------------------------------")
    hero = {"name": "勇者", "vocation": "僧侶"}
    actual = cast_priest_spell(hero, "荷伊米")
    expected = "勇者 以僧侶身分施放 荷伊米"
    print("輸入：勇者 vocation=僧侶")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_vocation_denied() -> bool:
    print("---------------------------------")
    warrior = {"name": "戰士", "vocation": "戰士"}
    actual = cast_priest_spell(warrior, "荷伊米")
    expected = "戰士 職業不符，不能施放這個咒文"
    print("輸入：戰士 vocation=戰士")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_vocation_allowed(), test_vocation_denied()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

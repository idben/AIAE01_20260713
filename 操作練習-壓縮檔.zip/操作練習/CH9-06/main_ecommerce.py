from functools import wraps


def require_role(required_role: str):
    # 請回傳 decorator，decorator 再回傳 wrapper
    raise NotImplementedError("請完成 require_role")


@require_role("店長")
def approve_refund(user: dict[str, object], order_id: str, amount: int) -> str:
    return f"{user['name']} 核准訂單 {order_id} 退款 {amount} 元"


if __name__ == "__main__":
    manager = {"name": "店長", "role": "店長"}
    print(approve_refund(manager, "A1001", 500))

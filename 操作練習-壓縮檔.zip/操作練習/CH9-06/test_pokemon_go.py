import subprocess
import sys

from pathlib import Path

from main_pokemon_go import catch_weather_boosted

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_weather_allowed() -> bool:
    print("---------------------------------")
    pokemon = {"name": "小火龍", "weather": "晴天"}
    actual = catch_weather_boosted(pokemon, "超級球")
    expected = "用 超級球 挑戰天氣加成的 小火龍"
    print("輸入：小火龍 weather=晴天")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_weather_denied() -> bool:
    print("---------------------------------")
    pokemon = {"name": "傑尼龜", "weather": "雨天"}
    actual = catch_weather_boosted(pokemon, "精靈球")
    expected = "傑尼龜 目前不是 晴天 天氣加成"
    print("輸入：傑尼龜 weather=雨天")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_weather_allowed(), test_weather_denied()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys

from pathlib import Path

from main_ecommerce import approve_refund

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_role_enough() -> bool:
    print("---------------------------------")
    manager = {"name": "店長", "role": "店長"}
    actual = approve_refund(manager, "A1001", 500)
    expected = "店長 核准訂單 A1001 退款 500 元"
    print("輸入：店長 role=店長")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_role_not_enough() -> bool:
    print("---------------------------------")
    staff = {"name": "客服", "role": "客服"}
    actual = approve_refund(staff, "A1001", 500)
    expected = "客服 權限不足，不能核准退款"
    print("輸入：客服 role=客服")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_role_enough(), test_role_not_enough()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

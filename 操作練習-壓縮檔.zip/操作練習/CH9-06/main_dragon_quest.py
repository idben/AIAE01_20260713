from functools import wraps


def require_vocation(required_vocation: str):
    # 請回傳 decorator，decorator 再回傳 wrapper
    raise NotImplementedError("請完成 require_vocation")


@require_vocation("僧侶")
def cast_priest_spell(caster: dict[str, object], spell_name: str) -> str:
    return f"{caster['name']} 以僧侶身分施放 {spell_name}"


if __name__ == "__main__":
    hero = {"name": "勇者", "vocation": "僧侶"}
    print(cast_priest_spell(hero, "荷伊米"))

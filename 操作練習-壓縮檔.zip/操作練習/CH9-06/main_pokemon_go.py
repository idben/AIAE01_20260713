from functools import wraps


def require_weather(required_weather: str):
    # 請回傳 decorator，decorator 再回傳 wrapper
    raise NotImplementedError("請完成 require_weather")


@require_weather("晴天")
def catch_weather_boosted(pokemon: dict[str, object], ball_name: str) -> str:
    return f"用 {ball_name} 挑戰天氣加成的 {pokemon['name']}"


if __name__ == "__main__":
    charmander = {"name": "小火龍", "weather": "晴天"}
    print(catch_weather_boosted(charmander, "超級球"))

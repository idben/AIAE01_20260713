from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import load_order_records


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_order_records() -> bool:
    cases = [
        (
            "order_id,total,paid,item_count,priority\n ORD-1001 ,1200,yes,3,一般\nORD-1002,850,no,1,急件\n",
            [
                {"order_id": "ORD-1001", "total": 1200, "paid": True, "item_count": 3, "priority": "一般"},
                {"order_id": "ORD-1002", "total": 850, "paid": False, "item_count": 1, "priority": "急件"},
            ],
            "含商品數與急件狀態的訂單 CSV",
        ),
        (
            "order_id,total,paid,item_count,priority\n EC-2001 ,3000, no ,5,急件\nEC-2002,450, YES ,2,一般\n",
            [
                {"order_id": "EC-2001", "total": 3000, "paid": False, "item_count": 5, "priority": "急件"},
                {"order_id": "EC-2002", "total": 450, "paid": True, "item_count": 2, "priority": "一般"},
            ],
            "含付款狀態空白與大寫文字的訂單 CSV",
        ),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "orders.csv"
            path.write_text(content, encoding="utf-8")
            actual = load_order_records(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_load_order_records()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_dragon_quest import load_item_prices


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_item_prices() -> bool:
    cases = [
        ("name,price\n 藥草 ,8\n銅劍,180\n", [{"name": "藥草", "price": 8}, {"name": "銅劍", "price": 180}], "道具價格 CSV"),
        ("name,price\n 魔法水 ,60\n鐵盾,250\n", [{"name": "魔法水", "price": 60}, {"name": "鐵盾", "price": 250}], "另一組道具價格 CSV"),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "item_prices.csv"
            path.write_text(content, encoding="utf-8")
            actual = load_item_prices(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_load_item_prices()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

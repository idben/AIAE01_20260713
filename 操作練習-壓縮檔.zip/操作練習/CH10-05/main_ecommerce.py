import csv
from pathlib import Path


def load_order_records(csv_path: Path) -> list[dict[str, object]]:
    # 請依課文規則讀取訂單紀錄 CSV
    raise NotImplementedError("請完成 load_order_records")


def main() -> None:
    print(load_order_records(Path("orders.csv")))


if __name__ == "__main__":
    main()

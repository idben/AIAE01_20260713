from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_pokemon_go import load_catch_records


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_catch_records() -> bool:
    cases = [
        (
            "pokemon,cp,caught,candy\n 皮卡丘 ,420, yes ,3\n伊布,250,no,1\n",
            [
                {"pokemon": "皮卡丘", "cp": 420, "caught": True, "candy": 3},
                {"pokemon": "伊布", "cp": 250, "caught": False, "candy": 1},
            ],
            "含糖果數與狀態空白的捕捉紀錄 CSV",
        ),
        (
            "pokemon,cp,caught,candy\n 卡比獸 ,1550,NO,0\n妙蛙種子,300,YES,4\n",
            [
                {"pokemon": "卡比獸", "cp": 1550, "caught": False, "candy": 0},
                {"pokemon": "妙蛙種子", "cp": 300, "caught": True, "candy": 4},
            ],
            "含大寫狀態文字的捕捉紀錄 CSV",
        ),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "catch_records.csv"
            path.write_text(content, encoding="utf-8")
            actual = load_catch_records(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_load_catch_records()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import csv
from pathlib import Path


def load_item_prices(csv_path: Path) -> list[dict[str, object]]:
    # 請依課文規則讀取道具價格 CSV
    raise NotImplementedError("請完成 load_item_prices")


def main() -> None:
    print(load_item_prices(Path("item_prices.csv")))


if __name__ == "__main__":
    main()

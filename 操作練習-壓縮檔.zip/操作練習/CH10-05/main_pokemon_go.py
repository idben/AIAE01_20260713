import csv
from pathlib import Path


def load_catch_records(csv_path: Path) -> list[dict[str, object]]:
    # 請依課文規則讀取捕捉紀錄 CSV
    raise NotImplementedError("請完成 load_catch_records")


def main() -> None:
    print(load_catch_records(Path("catch_records.csv")))


if __name__ == "__main__":
    main()

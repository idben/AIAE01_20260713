# CH10-05 練習

## 題目

練習使用 `csv.DictReader` 讀取 CSV。

- 《勇者鬥惡龍》版：讀取道具價格。
- 《寶可夢 GO》版：讀取捕捉紀錄。
- 電子商務版：讀取訂單紀錄。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `item_prices.csv`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `catch_records.csv`
- `main_ecommerce.py`
- `test_ecommerce.py`
- `orders.csv`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

先打開 CSV 檔觀察標題列和資料內容，再寫對應的讀取函式。`main_dragon_quest.py`、`main_pokemon_go.py` 和 `main_ecommerce.py` 會使用這些 CSV 檔，測試檔則會另外準備更多資料檢查你的函式。

名稱對照：

- `load_item_prices`：讀取道具價格資料
- `load_catch_records`：讀取捕捉紀錄資料
- `csv_path`：CSV 檔案路徑
- `price`：道具價格
- `cp`：寶可夢 CP
- `caught`：是否成功捕捉
- `candy`：取得糖果數
- `order_id`：訂單編號
- `total`：訂單金額
- `paid`：是否已付款
- `item_count`：商品數
- `priority`：訂單優先級

CSV 讀進來的欄位一開始都是字串。需要計算的欄位要轉成 `int`，成功與否欄位要先清理空白、統一大小寫，再轉成布林值。

操作順序：

- 《勇者鬥惡龍》：讀兩欄，轉一個數字。
- 《寶可夢 GO》：讀四欄，轉 CP、糖果數與捕捉狀態。
- 電子商務：讀五欄，保留訂單編號與急件分類，轉換金額、商品數與付款狀態；完成後，再接清理與統計。

## 常見錯誤

- 欄位名稱和測試檔不一致。
- 數字欄位仍然是字串。
- `caught` 沒有轉成布林值。
- 忘記處理 `YES`、`NO` 或前後有空白的狀態文字。
- 漏掉 `candy` 或 `item_count` 這類後續會用來統計的欄位。

## 你會練到什麼

- `csv.DictReader`
- 欄位名稱
- 型別轉換

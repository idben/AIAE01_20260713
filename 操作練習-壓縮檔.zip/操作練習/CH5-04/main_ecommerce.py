class Order:
    def __init__(self, order_id: str, total_amount: int) -> None:
        self.__order_id = order_id
        self.__total_amount = total_amount

    def get_order_id(self) -> str:
        return self.__order_id

    def get_total_amount(self) -> int:
        return self.__total_amount

    def reduce_total(self, amount: int) -> None:
        self.__total_amount -= amount


## 以上內容不要修改


class CouponOrder(Order):
    def __init__(self, order_id: str, total_amount: int, coupons: int) -> None:
        pass

    def apply_coupon(self) -> None:
        pass

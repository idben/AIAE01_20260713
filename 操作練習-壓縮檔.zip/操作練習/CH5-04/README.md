# CH5-04 練習

## 題目

這一課練習第一種子類別攻擊。

- 《勇者鬥惡龍》版：完成 `Archer(Hero)`（弓箭手繼承英雄）與 `shoot()`
- 《寶可夢 GO》版：完成 `FastAttacker(BattlePokemon)`（普通攻擊型寶可夢繼承戰鬥中的寶可夢）與 `attack()`
- 《電子商務》版：完成 `CouponOrder(Order)`（折扣券訂單繼承訂單）與 `apply_coupon()`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先看父類別已經記住哪些共通資料。
2. 《勇者鬥惡龍》要注意箭數怎麼影響目標生命值。
3. 《寶可夢 GO》要注意普通攻擊次數不夠時，例外該在哪一層處理。
4. 《電子商務》要注意折扣券版最後改到的不是目標角色，而是訂單自己的總金額。
5. 執行測試確認例外訊息和狀態更新結果。

## 常見錯誤

- 忘記 `super().__init__()`
- 資源不夠時沒有丟出正確訊息
- 遊戲版只扣自己的資源，忘了改目標 HP
- 電子商務版扣了折扣券，卻忘了更新訂單金額

## 這題在測什麼

- 父類別與子類別分工
- 方法更新的是自己、目標，或自己的總額
- 例外條件檢查

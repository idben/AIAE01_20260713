import subprocess
import sys
from pathlib import Path

from main_ecommerce import CouponOrder

ArgsOrder = tuple[str, int, int]
TestCase = tuple[ArgsOrder, int | None, str | None, bool]

run_cases: list[TestCase] = [
    (("A100", 80, 2), 70, None, False),
    (("B205", 60, 1), None, "not enough coupons", True),
]

submit_cases: list[TestCase] = run_cases + [
    (("C330", 120, 2), 100, None, True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(order_args: ArgsOrder, expected_total: int | None, expected_error: str | None, twice: bool) -> bool:
    print("---------------------------------")
    order = CouponOrder(*order_args)
    try:
        order.apply_coupon()
        if twice:
            order.apply_coupon()
        actual = order.get_total_amount()
        print(f"預期金額：{expected_total}")
        print(f"實際金額：{actual}")
        if expected_error:
            return False
        return actual == expected_total
    except Exception as error:
        print(f"預期例外：{expected_error}")
        print(f"實際例外：{error}")
        return str(error) == expected_error


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Archer, Hero

ArgsHero = tuple[str, int]
ArgsArcher = tuple[str, int, int]
TestCase = tuple[ArgsHero, ArgsArcher, int | None, str | None, bool]

run_cases: list[TestCase] = [
    (("勇者", 30), ("僧侶", 24, 2), 20, None, False),
    (("泰瑞", 50), ("庫庫爾", 28, 1), None, "not enough arrows", True),
]

submit_cases: list[TestCase] = run_cases + [
    (("楊格斯", 40), ("安潔羅", 26, 2), 20, None, True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(hero_args: ArgsHero, archer_args: ArgsArcher, expected_health: int | None, expected_error: str | None, twice: bool) -> bool:
    print("---------------------------------")
    hero = Hero(*hero_args)
    archer = Archer(*archer_args)
    try:
        archer.shoot(hero)
        if twice:
            archer.shoot(hero)
        actual = hero.get_health()
        print(f"預期生命值：{expected_health}")
        print(f"實際生命值：{actual}")
        if expected_error:
            return False
        return actual == expected_health
    except Exception as error:
        print(f"預期例外：{expected_error}")
        print(f"實際例外：{error}")
        return str(error) == expected_error


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

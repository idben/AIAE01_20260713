class RewardVoucher:
    def __init__(self, voucher_type: str) -> None:
        self.voucher_type = voucher_type

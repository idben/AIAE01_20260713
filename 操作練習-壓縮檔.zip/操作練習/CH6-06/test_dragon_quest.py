import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Sword

TestCase = tuple[Sword, Sword, str | None, str | None]

test_cases: list[TestCase] = [
    (Sword("bronze"), Sword("bronze"), "iron", None),
    (Sword("iron"), Sword("iron"), "steel", None),
    (Sword("bronze"), Sword("iron"), None, "無法合成"),
    (Sword("steel"), Sword("steel"), None, "無法合成"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(sword1: Sword, sword2: Sword, expected: str | None, expected_error: str | None) -> bool:
    print("---------------------------------")
    print(f"輸入：{sword1.sword_type} + {sword2.sword_type}")
    try:
        result = sword1 + sword2
        actual = result.sword_type
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        correct = expected_error is None and actual == expected
    except Exception as error:
        actual_error = str(error)
        print(f"預期錯誤：{expected_error}")
        print(f"實際錯誤：{actual_error}")
        correct = actual_error == expected_error
    if correct:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

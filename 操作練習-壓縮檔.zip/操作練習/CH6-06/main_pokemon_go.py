class CandyBundle:
    def __init__(self, bundle_type: str) -> None:
        self.bundle_type = bundle_type


def get_spell_label(spell_name: str, mp_cost: int) -> str:
    pass

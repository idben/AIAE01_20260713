import subprocess
import sys
from pathlib import Path

from main_pokemon_go import can_collect_reward

TestCase = tuple[int, int, int, bool]

test_cases: list[TestCase] = [
    (340, 350, 5, True),
    (348, 350, 2, True),
    (349, 350, 3, False),
    (350, 350, 1, False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    current_items: int, bag_capacity: int, reward_amount: int, expected: bool
) -> bool:
    print("---------------------------------")
    print(
        f"輸入：目前 {current_items} 個道具，容量 {bag_capacity}，補給站掉落 {reward_amount} 個"
    )
    actual = can_collect_reward(current_items, bag_capacity, reward_amount)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

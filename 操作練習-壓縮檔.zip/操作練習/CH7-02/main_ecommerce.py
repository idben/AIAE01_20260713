
def calculate_checkout_total(product_total: int) -> int:
    pass

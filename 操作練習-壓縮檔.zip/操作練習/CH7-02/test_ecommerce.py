import subprocess
import sys
from pathlib import Path

from main_ecommerce import calculate_checkout_total

TestCase = tuple[int, int]

test_cases: list[TestCase] = [
    (499, 579),
    (999, 1079),
    (1000, 1000),
    (1250, 1250),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(product_total: int, expected: int) -> bool:
    print("---------------------------------")
    print(f"輸入：商品小計 {product_total}")
    actual = calculate_checkout_total(product_total)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

def get_shipping_fee(product_total: int) -> int:
    if product_total >= 1000:
        return 0
    return 80

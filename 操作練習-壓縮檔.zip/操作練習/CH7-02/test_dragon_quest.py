import subprocess
import sys
from pathlib import Path

from main_dragon_quest import get_spell_label

TestCase = tuple[str, int, str]

test_cases: list[TestCase] = [
    ("荷依米", 3, "荷依米 需要 3 MP"),
    ("基拉", 4, "基拉 需要 4 MP"),
    ("魯拉", 8, "魯拉 需要 8 MP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(spell_name: str, mp_cost: int, expected: str) -> bool:
    print("---------------------------------")
    print(f"輸入：{spell_name}, {mp_cost}")
    actual = get_spell_label(spell_name, mp_cost)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys
from pathlib import Path

from main_ecommerce import PromotionRange

TestCase = tuple[PromotionRange, PromotionRange, bool]

test_cases: list[TestCase] = [
    (PromotionRange(100, 10, 50, 20), PromotionRange(140, 25, 80, 30), True),
    (PromotionRange(100, 10, 30, 10), PromotionRange(150, 40, 20, 20), False),
    (PromotionRange(200, 5, 40, 10), PromotionRange(240, 8, 30, 8), True),
    (PromotionRange(50, 0, 20, 5), PromotionRange(80, 10, 40, 10), False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(area1: PromotionRange, area2: PromotionRange, expected: bool) -> bool:
    print("---------------------------------")
    print(f"輸入：{area1} 與 {area2}")
    actual = area1.overlaps(area2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

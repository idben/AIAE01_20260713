import subprocess
import sys
from pathlib import Path

from main_pokemon_go import MapZone

TestCase = tuple[MapZone, MapZone, bool]

test_cases: list[TestCase] = [
    (MapZone(2, 2, 2), MapZone(5, 2, 1), True),
    (MapZone(0, 0, 1), MapZone(4, 4, 1), False),
    (MapZone(3, 3, 2), MapZone(3, 3, 2), True),
    (MapZone(0, 0, 2), MapZone(0, 5, 1), False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(zone1: MapZone, zone2: MapZone, expected: bool) -> bool:
    print("---------------------------------")
    print(f"輸入：{zone1} 與 {zone2}")
    actual = zone1.overlaps(zone2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

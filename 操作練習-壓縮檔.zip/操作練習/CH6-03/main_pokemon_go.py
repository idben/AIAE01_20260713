class MapZone:
    def overlaps(self, zone: "MapZone") -> bool:
        pass

    # 以下內容不要修改

    def __init__(self, center_x: int, center_y: int, radius: int) -> None:
        self.__center_x = center_x
        self.__center_y = center_y
        self.__radius = radius

    def get_left_x(self) -> int:
        return self.__center_x - self.__radius

    def get_right_x(self) -> int:
        return self.__center_x + self.__radius

    def get_top_y(self) -> int:
        return self.__center_y + self.__radius

    def get_bottom_y(self) -> int:
        return self.__center_y - self.__radius

    def __repr__(self) -> str:
        return f"MapZone({self.__center_x}, {self.__center_y}, {self.__radius})"

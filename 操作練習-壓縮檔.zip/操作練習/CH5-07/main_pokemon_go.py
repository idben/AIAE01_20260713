def main() -> None:
    beacons = [
        RadarBeacon("北門雷達", 0, 0, 1),
        RadarBeacon("車站雷達", 2, 2, 2),
        RadarBeacon("公園雷達", 4, 3, 3),
        RadarBeacon("河堤雷達", 5, -1, 4),
    ]

    # 以上內容不要修改

    for beacon in beacons:
        describe(beacon)

    for i in range(len(beacons)):
        beacon = beacons[i]
        # 在這裡補完排除自己後的其他掃描塔列表
        pass


# 以下內容不要修改


def describe(beacon: "RadarBeacon") -> None:
    print(f"{beacon.name} 位於 {beacon.pos_x}/{beacon.pos_y}")


class MapEntity:
    def __init__(self, name: str, pos_x: int, pos_y: int) -> None:
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y

    def in_area(self, x_1: int, y_1: int, x_2: int, y_2: int) -> bool:
        return (
            self.pos_x >= x_1
            and self.pos_x <= x_2
            and self.pos_y >= y_1
            and self.pos_y <= y_2
        )


class RadarBeacon(MapEntity):
    def __init__(self, name: str, pos_x: int, pos_y: int, scan_range: int) -> None:
        super().__init__(name, pos_x, pos_y)
        self.__scan_range = scan_range

    def scan_area(self, x: int, y: int, entities: list[MapEntity] | list["RadarBeacon"]) -> None:
        print("====================================")
        print(f"{self.name} 對 {x}/{y} 掃描，範圍 {self.__scan_range}")
        print("------------------------------------")
        for entity in entities:
            in_area = entity.in_area(
                x - self.__scan_range,
                y - self.__scan_range,
                x + self.__scan_range,
                y + self.__scan_range,
            )
            if in_area:
                print(f"{entity.name} 在掃描範圍內")


main()

# CH5-07 練習

## 題目

這一課練習用兩個迴圈操作多個物件。

- 《勇者鬥惡龍》版：完整寫出兩個迴圈，先列出所有龍，再讓每隻龍對 `(3, 3)` 噴火
- 《寶可夢 GO》版：第一個迴圈已給，補完第二個迴圈，讓每個掃描塔對 `(3, 3)` 掃描其他掃描塔
- 電子商務版：檢查並修正出貨站版本中「誤改原始清單」的錯誤

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 《勇者鬥惡龍》先從零完成兩個迴圈，分清楚第一段是列出全部、第二段才是逐一噴火。
2. 《寶可夢 GO》先看已經完成的第一個迴圈，再補出第二個迴圈裡的副本與排除自己。
3. 電子商務版先不要急著重寫，先看 `other_stations` 到底是不是新列表。
4. 三個版本都要注意：傳進方法的其他物件必須保留原順序。
5. 執行測試確認輸出是否完整。

## 常見錯誤

- 直接用 `others = dragons` 或 `others = beacons`
- 刪掉自己時改到原本主清單
- 傳進方法的其他物件順序不對
- 看到除錯題就整份重寫，反而沒先找到真正的 bug

## 這題在測什麼

- 兩段式迴圈操作
- 清單副本與刪除
- 多物件互動
- 同一個清單觀念在完整實作、補完題、除錯題中的不同用法

import io
import subprocess
import sys
from contextlib import redirect_stdout
from pathlib import Path

import main_dragon_quest


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test() -> bool:
    print("---------------------------------")
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        main_dragon_quest.main()
    output = buffer.getvalue()
    checks = [
        "綠龍 位於 0/0",
        "紅龍 位於 2/2",
        "藍龍 位於 4/3",
        "黑龍 位於 5/-1",
        "綠龍 對 3/3 噴火，範圍 1",
        "紅龍 被火焰擊中",
        "藍龍 被火焰擊中",
    ]
    failed = [item for item in checks if item not in output]
    if failed:
        print("缺少輸出：")
        for item in failed:
            print(item)
        return False
    return True


def main() -> None:
    if test():
        print("============= 全部通過 ==============")
        play_pass_sound()
        print("通過 1 筆，失敗 0 筆")
    else:
        print("============= 有測試失敗 ==============")
        print("通過 0 筆，失敗 1 筆")


main()

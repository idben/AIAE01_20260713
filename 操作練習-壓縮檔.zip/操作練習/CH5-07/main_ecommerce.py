def main() -> None:
    stations = [
        ShippingStation("北倉出貨站", 0, 0, 1),
        ShippingStation("中倉出貨站", 2, 2, 2),
        ShippingStation("南倉出貨站", 4, 3, 3),
        ShippingStation("港口出貨站", 5, -1, 4),
    ]

    # 以上內容不要修改

    for station in stations:
        describe(station)

    for station in stations:
        other_stations = stations
        other_stations.remove(station)
        station.scan_orders(3, 3, other_stations)


# 以下內容不要修改


def describe(station: "ShippingStation") -> None:
    print(f"{station.name} 位於 {station.pos_x}/{station.pos_y}")


class WarehouseNode:
    def __init__(self, name: str, pos_x: int, pos_y: int) -> None:
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y

    def in_area(self, x_1: int, y_1: int, x_2: int, y_2: int) -> bool:
        return (
            self.pos_x >= x_1
            and self.pos_x <= x_2
            and self.pos_y >= y_1
            and self.pos_y <= y_2
        )


class ShippingStation(WarehouseNode):
    def __init__(self, name: str, pos_x: int, pos_y: int, scan_range: int) -> None:
        super().__init__(name, pos_x, pos_y)
        self.__scan_range = scan_range

    def scan_orders(self, x: int, y: int, stations: list[WarehouseNode] | list["ShippingStation"]) -> None:
        print("====================================")
        print(f"{self.name} 對 {x}/{y} 掃描，範圍 {self.__scan_range}")
        print("------------------------------------")
        for station in stations:
            in_area = station.in_area(
                x - self.__scan_range,
                y - self.__scan_range,
                x + self.__scan_range,
                y + self.__scan_range,
            )
            if in_area:
                print(f"{station.name} 在掃描範圍內")


main()

import subprocess
import sys

from pathlib import Path

from main_ecommerce import calculate_total, run_checkout_step, validate_stock


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_validate_stock() -> bool:
    print("---------------------------------")
    enough_order = {"product_name": "鍵盤", "price": 1200, "quantity": 2, "stock": 5}
    short_order = {"product_name": "滑鼠", "price": 800, "quantity": 3, "stock": 1}
    actual = (validate_stock(enough_order), validate_stock(short_order))
    expected = ("鍵盤 庫存足夠", "滑鼠 庫存不足")
    print("輸入：鍵盤庫存足夠、滑鼠庫存不足")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_calculate_total() -> bool:
    print("---------------------------------")
    order = {"product_name": "滑鼠", "price": 800, "quantity": 3, "stock": 5}
    actual = calculate_total(order)
    expected = "滑鼠 x3 小計 2400 元"
    print("輸入：滑鼠 price=800 quantity=3")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_run_checkout_step() -> bool:
    print("---------------------------------")
    order = {"product_name": "耳機", "price": 1500, "quantity": 2, "stock": 4}
    actual = (
        run_checkout_step(validate_stock, order),
        run_checkout_step(calculate_total, order),
    )
    expected = ("耳機 庫存足夠", "耳機 x2 小計 3000 元")
    print("輸入：run_checkout_step(validate_stock, order) 與 run_checkout_step(calculate_total, order)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_validate_stock(), test_calculate_total(), test_run_checkout_step()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

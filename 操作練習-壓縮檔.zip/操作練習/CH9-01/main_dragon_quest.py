def basic_attack(hero_name: str) -> str:
    # 請回傳普通攻擊訊息
    raise NotImplementedError("請完成 basic_attack")


def defend(hero_name: str) -> str:
    # 請回傳防禦訊息
    raise NotImplementedError("請完成 defend")


def choose_battle_action(action_name: str):
    # 請依照行動名稱回傳對應的函式物件，不要在這裡呼叫函式
    raise NotImplementedError("請完成 choose_battle_action")


def main() -> None:
    action = choose_battle_action("攻擊")
    print(action("勇者"))


if __name__ == "__main__":
    main()

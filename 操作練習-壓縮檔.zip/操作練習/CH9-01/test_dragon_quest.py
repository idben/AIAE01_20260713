import subprocess
import sys

from pathlib import Path

from main_dragon_quest import basic_attack, choose_battle_action, defend


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_battle_actions() -> bool:
    print("---------------------------------")
    actual = (basic_attack("勇者"), defend("勇者"))
    expected = ("勇者 進行普通攻擊", "勇者 舉起盾牌防禦")
    print("輸入：勇者")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_choose_battle_action() -> bool:
    print("---------------------------------")
    attack_action = choose_battle_action("攻擊")
    defend_action = choose_battle_action("防禦")
    actual = (attack_action("戰士"), defend_action("戰士"))
    expected = ("戰士 進行普通攻擊", "戰士 舉起盾牌防禦")
    print("輸入：choose_battle_action('攻擊') 與 choose_battle_action('防禦')")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if attack_action is basic_attack and defend_action is defend and actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_battle_actions(), test_choose_battle_action()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

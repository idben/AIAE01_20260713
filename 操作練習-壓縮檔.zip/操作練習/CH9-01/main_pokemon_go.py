def spin_pokestop(trainer_name: str) -> str:
    # 請回傳轉補給站訊息
    raise NotImplementedError("請完成 spin_pokestop")


def check_nearby(trainer_name: str) -> str:
    # 請回傳查看附近寶可夢訊息
    raise NotImplementedError("請完成 check_nearby")


def build_exploration_plan(first_action, second_action):
    # 請把兩個探索函式物件放進清單回傳，不要在這裡呼叫它們
    raise NotImplementedError("請完成 build_exploration_plan")


def main() -> None:
    plan = build_exploration_plan(spin_pokestop, check_nearby)
    for action in plan:
        print(action("小智"))


if __name__ == "__main__":
    main()

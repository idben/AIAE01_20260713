def validate_stock(order: dict) -> str:
    # 請依照訂單庫存狀態回傳檢查訊息
    raise NotImplementedError("請完成 validate_stock")


def calculate_total(order: dict) -> str:
    # 請依照訂單單價與數量回傳小計訊息
    raise NotImplementedError("請完成 calculate_total")


def run_checkout_step(step_function, order: dict) -> str:
    # 請呼叫收到的結帳步驟函式，並把訂單資料交給它
    raise NotImplementedError("請完成 run_checkout_step")


def main() -> None:
    order = {"product_name": "鍵盤", "price": 1200, "quantity": 2, "stock": 5}
    print(run_checkout_step(validate_stock, order))
    print(run_checkout_step(calculate_total, order))


if __name__ == "__main__":
    main()

# CH9-01 練習

## 你要完成的事

練習把函式當作物件傳遞。

建議完成順序：

- 《勇者鬥惡龍》：依照行動名稱選出函式物件。
- 《寶可夢 GO》：把多個探索函式放進清單，之後再依序呼叫。
- 電子商務：把函式當作結帳步驟傳入，流程函式會真的呼叫指定步驟。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

這三題不是同一題換名字，而是難度逐步增加：

- 《勇者鬥惡龍》：先依照行動名稱回傳不同函式物件。
- 《寶可夢 GO》：把函式物件放進清單，練習保存多個尚未執行的行動。
- 電子商務：把函式物件當成流程步驟傳入，練習由流程函式呼叫指定步驟。

### 《勇者鬥惡龍》版

先觀察 `basic_attack(hero_name)` 和 `defend(hero_name)`：

- 它們都收到角色名稱。
- `basic_attack()` 回傳普通攻擊訊息。
- `defend()` 回傳防禦訊息。

再觀察 `choose_battle_action(action_name)`：

- `action_name` 是行動名稱，不是角色名稱。
- 行動名稱是 `"攻擊"` 時，回傳普通攻擊函式物件。
- 行動名稱是 `"防禦"` 時，回傳防禦函式物件。
- 這裡只選函式，不要先呼叫函式。

### 《寶可夢 GO》版

先觀察 `spin_pokestop(trainer_name)` 和 `check_nearby(trainer_name)`：

- 它們都收到訓練家名稱。
- `spin_pokestop()` 回傳轉補給站訊息。
- `check_nearby()` 回傳查看附近寶可夢訊息。

再觀察 `build_exploration_plan(first_action, second_action)`：

- `first_action` 和 `second_action` 都是函式物件。
- 它要把兩個函式物件放進清單回傳。
- 建立探索計畫時不要先呼叫函式。

### 電子商務版

先觀察 `validate_stock(order)` 和 `calculate_total(order)`：

- 兩個函式都收到同一份訂單字典。
- `validate_stock()` 判斷庫存是否足夠。
- `calculate_total()` 用單價與數量算小計。

再觀察 `run_checkout_step(step_function, order)`：

- `step_function` 是結帳步驟函式。
- `order` 是這次要處理的訂單資料。
- 這一題要真的呼叫 `step_function`，並把 `order` 傳進去。

## 提示

函式名稱後面沒有括號時，代表傳遞函式物件；有括號時，才是呼叫函式。

## 檢查順序

1. 勇者版是否回傳函式物件，而不是先呼叫函式。
2. 寶可夢版清單裡是否保存函式物件，而不是保存執行結果。
3. 電子商務版是否把收到的函式當成步驟呼叫，並把訂單資料傳入。
4. 三個版本是否各自負責不同型態的函式傳遞。

## 常見卡住點

- 勇者版在 `choose_battle_action()` 裡直接呼叫戰鬥函式。
- 寶可夢版把行動結果放進清單，而不是把函式物件放進清單。
- 電子商務版忘記把 `order` 傳給 `step_function`。

## 做完你會練到

- 函式也是物件。
- 函式可以指定給變數或當作參數傳遞。

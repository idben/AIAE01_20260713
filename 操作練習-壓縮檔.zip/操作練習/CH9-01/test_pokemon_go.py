import subprocess
import sys

from pathlib import Path

from main_pokemon_go import build_exploration_plan, check_nearby, spin_pokestop


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_spin_pokestop() -> bool:
    print("---------------------------------")
    actual = spin_pokestop("小智")
    expected = "小智 轉動補給站"
    print("輸入：小智")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_check_nearby() -> bool:
    print("---------------------------------")
    actual = check_nearby("小霞")
    expected = "小霞 查看附近寶可夢"
    print("輸入：小霞")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_exploration_plan() -> bool:
    print("---------------------------------")
    plan = build_exploration_plan(spin_pokestop, check_nearby)
    actual = [action("小剛") for action in plan]
    expected = ["小剛 轉動補給站", "小剛 查看附近寶可夢"]
    print("輸入：build_exploration_plan(spin_pokestop, check_nearby)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if plan == [spin_pokestop, check_nearby] and actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_spin_pokestop(), test_check_nearby(), test_build_exploration_plan()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

class Rectangle:
    def overlaps(self, rect: "Rectangle") -> bool:
        return (
            self.get_left_x() <= rect.get_right_x()
            and self.get_right_x() >= rect.get_left_x()
            and self.get_top_y() >= rect.get_bottom_y()
            and self.get_bottom_y() <= rect.get_top_y()
        )

    def __init__(self, x1: float, y1: float, x2: float, y2: float) -> None:
        self.__x1 = x1
        self.__y1 = y1
        self.__x2 = x2
        self.__y2 = y2

    def get_left_x(self) -> float:
        return min(self.__x1, self.__x2)

    def get_right_x(self) -> float:
        return max(self.__x1, self.__x2)

    def get_top_y(self) -> float:
        return max(self.__y1, self.__y2)

    def get_bottom_y(self) -> float:
        return min(self.__y1, self.__y2)


# 以上內容不要修改


class CatalogItem:
    def __init__(self, name: str, price: int, stock: int) -> None:
        self.name = name
        self.price = price
        self.stock = stock

    def in_area(self, x1: float, y1: float, x2: float, y2: float) -> bool:
        return (
            self.price >= x1
            and self.price <= x2
            and self.stock >= y1
            and self.stock <= y2
        )


# 以上內容不要修改


class ProductSegment(CatalogItem):
    def __init__(
        self,
        name: str,
        price: int,
        stock: int,
        stock_span: int,
        price_span: int,
        promotion_priority: int,
    ) -> None:
        pass

    def in_area(self, x1: float, y1: float, x2: float, y2: float) -> bool:
        pass

import subprocess
import sys
from pathlib import Path

from main_pokemon_go import EventObject

TestCase = tuple[EventObject, int, int, int, int, bool]

test_cases: list[TestCase] = [
    (EventObject("團體戰蛋", 2, 2, 2, 2, 1), 0, 1, 1, 0, True),
    (EventObject("社群日區域", 0, 0, 6, 6, 2), 4, 4, 8, 8, True),
    (EventObject("補給站活動", 5, -1, 3, 2, 2), -10, -10, 10, 10, True),
    (EventObject("遠方道館", 4, -3, 2, 1, 1), 0, 0, 10, 10, False),
    (EventObject("遠方活動", 0, 0, 2, 2, 1), 3, 3, 6, 6, False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(obj: EventObject, x1: int, y1: int, x2: int, y2: int, expected: bool) -> bool:
    print("---------------------------------")
    print(f"輸入：{obj.name} at ({obj.pos_x}, {obj.pos_y})")
    print(f"範圍：({x1}, {y1}) 到 ({x2}, {y2})")
    actual = obj.in_area(x1, y1, x2, y2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

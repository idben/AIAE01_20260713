import subprocess
import sys
from pathlib import Path

from main_pokemon_go import PokemonSpawn

TestCase = tuple[tuple[str, str], str]

test_cases: list[TestCase] = [
    (("皮卡丘", "公園"), "皮卡丘出現在公園附近"),
    (("伊布", "車站"), "伊布出現在車站附近"),
    (("卡比獸", "道館"), "卡比獸出現在道館附近"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(args: tuple[str, str], expected: str) -> bool:
    spawn = PokemonSpawn(*args)
    actual = str(spawn)
    print("---------------------------------")
    print(f"輸入：{args}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

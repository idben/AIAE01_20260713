class ProductListing:
    def __init__(self, name: str, category: str) -> None:
        self.name = name
        self.category = category

    def __str__(self) -> str:
        return f"{self.category}分類上架了{self.name}"

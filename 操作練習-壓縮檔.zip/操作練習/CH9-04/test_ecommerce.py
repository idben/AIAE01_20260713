import subprocess
import sys

from pathlib import Path

from main_ecommerce import create_order_message

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_create_order_message_args_kwargs() -> bool:
    print("---------------------------------")
    actual = create_order_message("小明", "A1001", 2400, paid=True)
    expected = {
        "message": "小明 的訂單 A1001 金額 2400 元，已付款",
        "paid": True,
    }
    print("輸入：位置參數加 paid=True")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_create_order_message_all_kwargs_unpaid() -> bool:
    print("---------------------------------")
    actual = create_order_message(customer_name="小華", order_id="A1002", amount=800, paid=False)
    expected = {
        "message": "小華 的訂單 A1002 金額 800 元，未付款",
        "paid": False,
    }
    print("輸入：全部使用關鍵字參數，paid=False")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_create_order_message_args_kwargs(), test_create_order_message_all_kwargs_unpaid()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

def summarize_raid_detail(original_function):
    # 請建立能接收 *args 和 **kwargs 的 wrapper，並回傳招式摘要字典
    raise NotImplementedError("請完成 summarize_raid_detail")


@summarize_raid_detail
def analyze_raid_move(pokemon_name: str, move_name: str, damage: int, super_effective: bool) -> str:
    effect_text = "效果絕佳" if super_effective else "效果普通"
    return f"{pokemon_name} 使用 {move_name}，造成 {damage} 傷害，{effect_text}"


if __name__ == "__main__":
    print(analyze_raid_move("噴火龍", "火焰旋渦", 24, super_effective=True))

def log_item_detail(original_function):
    # 請建立能接收 *args 和 **kwargs 的 wrapper
    raise NotImplementedError("請完成 log_item_detail")


@log_item_detail
def use_battle_item(actor_name: str, item_name: str, quantity: int, target_name: str) -> str:
    return f"{actor_name} 對 {target_name} 使用 {quantity} 個 {item_name}"


if __name__ == "__main__":
    print(use_battle_item("勇者", "藥草", 2, target_name="戰士"))

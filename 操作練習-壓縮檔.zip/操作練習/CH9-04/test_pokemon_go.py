import subprocess
import sys

from pathlib import Path

from main_pokemon_go import analyze_raid_move

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_analyze_raid_move_args_kwargs() -> bool:
    print("---------------------------------")
    actual = analyze_raid_move("噴火龍", "火焰旋渦", 24, super_effective=True)
    expected = {
        "message": "噴火龍 使用 火焰旋渦，造成 24 傷害，效果絕佳",
        "argument_count": 4,
    }
    print("輸入：位置參數加 super_effective=True")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_analyze_raid_move_all_kwargs_false_branch() -> bool:
    print("---------------------------------")
    actual = analyze_raid_move(pokemon_name="水箭龜", move_name="水槍", damage=12, super_effective=False)
    expected = {
        "message": "水箭龜 使用 水槍，造成 12 傷害，效果普通",
        "argument_count": 4,
    }
    print("輸入：全部使用關鍵字參數，super_effective=False")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_analyze_raid_move_args_kwargs(), test_analyze_raid_move_all_kwargs_false_branch()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

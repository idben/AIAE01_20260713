# CH9-04 練習

## 你要完成的事

完成能處理參數與回傳值的裝飾器。

建議完成順序：

- 《勇者鬥惡龍》：轉交道具使用者、道具名稱、數量與目標，並保留原本字串。
- 《寶可夢 GO》：轉交團體戰寶可夢、招式、傷害與效果判斷，再整理成招式摘要字典。
- 電子商務：轉交顧客、訂單編號、金額與付款狀態，再整理成訂單稽核字典。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

1. 先觀察每個原函式有哪些參數。
2. 再觀察呼叫時哪些資料用位置參數傳入，哪些資料用關鍵字參數傳入。
3. `wrapper` 要接住 `*args` 和 `**kwargs`，再完整轉交給原函式。
4. 最後確認這一題要原樣回傳，還是要整理成新的字典。

在 `def wrapper(*args, **kwargs)` 裡，`*` 和 `**` 是把傳進來的參數收起來；在 `original_function(*args, **kwargs)` 裡，`*` 和 `**` 是把收起來的參數攤開再傳出去。

## 題目提示

### 《勇者鬥惡龍》版

先觀察 `use_battle_item()`。使用者、道具名稱與數量描述行動本身，`target_name` 描述道具用在誰身上。

這一題是入門題。`log_item_detail()` 只要呼叫原函式，並把原函式回傳的字串傳回去。

### 《寶可夢 GO》版

先觀察 `analyze_raid_move()`。寶可夢名稱、招式與傷害是戰鬥資料，`super_effective` 是效果判斷。

`summarize_raid_detail()` 要呼叫原函式取得招式文字，再回傳字典。字典要包含：

- `message`：原函式回傳的招式文字。
- `argument_count`：這次呼叫收到的參數總數。

這一題不能只 `return result`。

### 電子商務版

先觀察 `create_order_message()`。付款狀態可能用 `paid=True` 傳入，如果漏掉 `**kwargs`，原函式就不知道訂單是否已付款。

`audit_order_detail()` 要呼叫原函式取得訂單文字，再回傳字典。字典要包含：

- `message`：原函式回傳的訂單文字。
- `paid`：這次訂單的付款狀態。

這一題不能只 `return result`。你要觀察 `paid` 是從哪裡傳進來，再放進稽核資料。

## 檢查順序

1. `wrapper` 是否接住 `*args`。
2. `wrapper` 是否接住 `**kwargs`。
3. 呼叫原函式時是否把兩種參數都轉交出去。
4. 《勇者鬥惡龍》版是否保留原本字串。
5. 《寶可夢 GO》版是否回傳招式摘要字典。
6. 電子商務版是否回傳訂單稽核字典。

## 常見卡住點

- `wrapper` 沒有接 `*args, **kwargs`。
- 呼叫原函式時沒有把參數轉交出去。
- 《寶可夢 GO》版只回傳原本字串，沒有整理 `argument_count`。
- 電子商務版只回傳原本字串，沒有把 `paid` 放進稽核資料。

## 做完你會練到

- `*args`。
- `**kwargs`。
- 回傳值保留與整理。

def audit_order_detail(original_function):
    # 請建立能接收 *args 和 **kwargs 的 wrapper，並回傳訂單稽核字典
    raise NotImplementedError("請完成 audit_order_detail")


@audit_order_detail
def create_order_message(customer_name: str, order_id: str, amount: int, paid: bool) -> str:
    status = "已付款" if paid else "未付款"
    return f"{customer_name} 的訂單 {order_id} 金額 {amount} 元，{status}"


if __name__ == "__main__":
    print(create_order_message("小明", "A1001", 2400, paid=True))

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import use_battle_item

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_use_battle_item_args_kwargs() -> bool:
    print("---------------------------------")
    actual = use_battle_item("勇者", "藥草", 2, target_name="戰士")
    expected = "勇者 對 戰士 使用 2 個 藥草"
    print("輸入：位置參數加 target_name")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_use_battle_item_all_kwargs() -> bool:
    print("---------------------------------")
    actual = use_battle_item(actor_name="僧侶", item_name="魔法水", quantity=1, target_name="勇者")
    expected = "僧侶 對 勇者 使用 1 個 魔法水"
    print("輸入：全部使用關鍵字參數")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_use_battle_item_args_kwargs(), test_use_battle_item_all_kwargs()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

class ItemBag:
    poke_balls: int = 10

    def use_poke_ball(self) -> None:
        pass

class PartyMember:
    hp: int = 20

    def take_damage(self, damage: int) -> None:
        pass

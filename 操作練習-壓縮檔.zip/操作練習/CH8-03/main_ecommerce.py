from datetime import datetime


def get_return_window_status(
    purchase_time: datetime,
    now: datetime,
    return_days: int,
) -> str:
    # 請判斷退貨期限狀態，回傳 可退貨 或 已過期
    pass

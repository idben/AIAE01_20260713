import subprocess
import sys

from datetime import datetime
from pathlib import Path

from main_ecommerce import get_return_window_status

TestCase = tuple[datetime, datetime, int, str]

test_cases: list[TestCase] = [
    (datetime(2026, 6, 1, 9, 0), datetime(2026, 6, 7, 8, 59), 7, "可退貨"),
    (datetime(2026, 6, 1, 9, 0), datetime(2026, 6, 8, 9, 1), 7, "已過期"),
]

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_return_status(
    purchase_time: datetime,
    now: datetime,
    return_days: int,
    expected: str,
) -> bool:
    print("---------------------------------")
    actual = get_return_window_status(purchase_time, now, return_days)
    print(f"輸入：購買 {purchase_time}, 現在 {now}, {return_days} 天退貨期")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_return_status(*case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

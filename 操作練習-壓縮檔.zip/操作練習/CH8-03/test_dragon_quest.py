import subprocess
import sys

from datetime import datetime
from pathlib import Path

from main_dragon_quest import get_quest_remaining_hours

TestCase = tuple[datetime, datetime, int]

test_cases: list[TestCase] = [
    (datetime(2026, 6, 9, 9, 0), datetime(2026, 6, 10, 18, 0), 33),
    (datetime(2026, 6, 9, 10, 30), datetime(2026, 6, 9, 13, 45), 3),
]

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_remaining_hours(now: datetime, deadline: datetime, expected: int) -> bool:
    print("---------------------------------")
    actual = get_quest_remaining_hours(now, deadline)
    print(f"輸入：{now}, {deadline}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_remaining_hours(*case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

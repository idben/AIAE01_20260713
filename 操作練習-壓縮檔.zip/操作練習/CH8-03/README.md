# CH8-03 練習

## 題目

練習使用 `datetime` 計算剩餘時間。

- 《勇者鬥惡龍》版：計算任務剩餘小時
- 《寶可夢 GO》版：計算孵蛋剩餘小時
- 電子商務版：判斷訂單是否仍在退貨期限內

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：計算剩餘完整小時。
- 《寶可夢 GO》：計算孵蛋時間，除了跨日，也要處理已經可以孵化時回傳 `0`。
- 電子商務：不只計算時間差，還要把購買時間、目前時間與退貨天數組合成狀態判斷。

## 操作步驟

1. 先觀察函式收到的是兩個 `datetime` 物件。
2. 判斷哪一個是目前時間，哪一個是目標時間。
3. 用時間差計算剩餘的完整小時。
4. 回傳整數，不要回傳文字。

## 題目提示

《勇者鬥惡龍》版：

- `get_quest_remaining_hours(now, deadline)` 的 `now` 是目前時間。
- `deadline` 是任務截止時間。
- 回傳值可以用來判斷任務是否快要逾期。

《寶可夢 GO》版：

- `get_egg_remaining_hours(now, hatch_time)` 的 `now` 是目前時間。
- `hatch_time` 是孵蛋完成時間。
- 回傳值可以用來排序孵蛋清單或顯示倒數。
- 如果 `hatch_time` 已經早於或等於 `now`，代表蛋已經可以孵化，請回傳 `0`。

電子商務版：

- `get_return_window_status(purchase_time, now, return_days)` 會收到購買時間、目前時間與退貨天數。
- 這裡的情境是客服後台要判斷訂單是否還能退貨。
- 還在期限內回傳 `可退貨`，超過期限回傳 `已過期`。

## 檢查順序

1. 是否用目標時間減目前時間。
2. 是否把秒數換成小時。
3. 是否回傳整數。
4. 寶可夢版是否把已經孵化的蛋回傳為 `0`。
5. 電子商務版是否用期限時間和目前時間比較，而不是只看日期文字。

## 常見錯誤

- 把兩個時間相減的方向寫反。
- 寶可夢版回傳負數，沒有把已經孵化的情況歸零。
- 回傳 `timedelta` 物件而不是整數小時。
- 回傳顯示文字，導致測試無法比較數字。
- 電子商務版把剛好仍在期限內的訂單判斷成過期。
- 以為有 `total_minutes()` 或 `total_hours()`；實際上通常先用 `total_seconds()`，再除以 `60` 或 `3600`。

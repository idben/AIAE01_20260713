from datetime import datetime


def get_egg_remaining_hours(now: datetime, hatch_time: datetime) -> int:
    # 請計算孵蛋還剩下幾個完整小時；如果已經可以孵化，回傳 0
    pass

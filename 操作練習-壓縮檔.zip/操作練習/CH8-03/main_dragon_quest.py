from datetime import datetime


def get_quest_remaining_hours(now: datetime, deadline: datetime) -> int:
    # 請計算任務還剩下幾個完整小時
    pass

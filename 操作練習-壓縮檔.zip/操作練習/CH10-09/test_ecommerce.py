import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import (
    build_order_report,
    build_report_from_csv,
    clean_order_rows,
    load_order_rows,
    save_report,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_order_rows() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        csv_path = Path(folder) / "orders.csv"
        csv_path.write_text(
            "order_id,total,paid,item_count,priority\nORD-1001,1200,yes,3,一般\nORD-1002,850,no,1,急件\n",
            encoding="utf-8",
        )
        rows = load_order_rows(csv_path)
    expected = [
        {"order_id": "ORD-1001", "total": "1200", "paid": "yes", "item_count": "3", "priority": "一般"},
        {"order_id": "ORD-1002", "total": "850", "paid": "no", "item_count": "1", "priority": "急件"},
    ]
    print("輸入：兩筆訂單 CSV 資料")
    print(f"預期：{expected}")
    print(f"實際：{rows}")
    if rows == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_clean_order_rows() -> bool:
    print("---------------------------------")
    rows = [
        {"order_id": " ORD-1001 ", "total": "1200", "paid": "yes", "item_count": "3", "priority": "一般"},
        {"order_id": "", "total": "850", "paid": "no", "item_count": "1", "priority": "急件"},
        {"order_id": "ORD-1002", "total": "bad", "paid": "no", "item_count": "2", "priority": "一般"},
        {"order_id": "ORD-1003", "total": "2000", "paid": "no", "item_count": "5", "priority": "急件"},
    ]
    records = clean_order_rows(rows)
    expected = [
        {"order_id": "ORD-1001", "total": 1200, "paid": True, "item_count": 3, "priority": "一般"},
        {"order_id": "ORD-1003", "total": 2000, "paid": False, "item_count": 5, "priority": "急件"},
    ]
    print("輸入：含無效列的訂單原始資料")
    print(f"預期：{expected}")
    print(f"實際：{records}")
    if records == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_order_report() -> bool:
    print("---------------------------------")
    records = [
        {"order_id": "ORD-1001", "total": 1200, "paid": True, "item_count": 3, "priority": "一般"},
        {"order_id": "ORD-1003", "total": 2000, "paid": False, "item_count": 5, "priority": "急件"},
    ]
    report = build_order_report(records)
    expected = {
        "record_count": 2,
        "paid_count": 1,
        "unpaid_total": 2000,
        "average_item_count": 4,
        "high_value_order_ids": ["ORD-1003"],
        "rush_order_ids": ["ORD-1003"],
        "records": records,
    }
    print("輸入：兩筆清理後訂單資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_report() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        report_path = Path(folder) / "reports" / "order_report.json"
        report = {
            "record_count": 1,
            "paid_count": 1,
            "unpaid_total": 0,
            "average_item_count": 2,
            "high_value_order_ids": [],
            "rush_order_ids": [],
            "records": [{"order_id": "台北-1001", "total": 1200, "paid": True, "item_count": 2, "priority": "一般"}],
        }
        save_report(report_path, report)
        raw_text = report_path.read_text(encoding="utf-8")
        loaded = json.loads(raw_text)
    print("輸入：訂單報表路徑與報表字典")
    print(f"預期：{report}")
    print(f"實際：{loaded}")
    print("預期：JSON 原始文字保留中文")
    print(f"實際原始文字：{raw_text}")
    if loaded == report and "台北-1001" in raw_text:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_report_from_csv() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        base_path = Path(folder)
        csv_path = base_path / "orders.csv"
        report_path = base_path / "nested" / "order_report.json"
        csv_path.write_text(
            "order_id,total,paid,item_count,priority\nORD-1001,1200,yes,3,一般\n,850,no,1,急件\nORD-1003,2000,no,5,急件\n",
            encoding="utf-8",
        )
        report = build_report_from_csv(csv_path, report_path)
        loaded = json.loads(report_path.read_text(encoding="utf-8"))
    expected_count = 2
    print("輸入：含一筆無效列的訂單 CSV")
    print(f"預期有效筆數：{expected_count}")
    print(f"實際有效筆數：{report.get('record_count')}")
    if report == loaded and report.get("record_count") == expected_count:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_order_report_empty_records() -> bool:
    print("---------------------------------")
    report = build_order_report([])
    expected = {
        "record_count": 0,
        "paid_count": 0,
        "unpaid_total": 0,
        "average_item_count": 0,
        "high_value_order_ids": [],
        "rush_order_ids": [],
        "records": [],
    }
    print("輸入：沒有任何有效訂單資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_load_order_rows(),
        test_clean_order_rows(),
        test_build_order_report(),
        test_save_report(),
        test_build_report_from_csv(),
        test_build_order_report_empty_records(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

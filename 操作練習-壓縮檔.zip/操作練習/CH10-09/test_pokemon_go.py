import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_pokemon_go import (
    build_catch_report,
    build_report_from_csv,
    clean_catch_rows,
    load_catch_rows,
    save_report,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_catch_rows() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        csv_path = Path(folder) / "catch_records.csv"
        csv_path.write_text(
            "pokemon,cp,caught,candy\n皮卡丘,420,yes,3\n伊布,250,no,1\n",
            encoding="utf-8",
        )
        rows = load_catch_rows(csv_path)
    expected = [
        {"pokemon": "皮卡丘", "cp": "420", "caught": "yes", "candy": "3"},
        {"pokemon": "伊布", "cp": "250", "caught": "no", "candy": "1"},
    ]
    print("輸入：兩筆捕捉 CSV 資料")
    print(f"預期：{expected}")
    print(f"實際：{rows}")
    if rows == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_clean_catch_rows() -> bool:
    print("---------------------------------")
    rows = [
        {"pokemon": " 皮卡丘 ", "cp": "420", "caught": "yes", "candy": "3"},
        {"pokemon": "", "cp": "120", "caught": "yes", "candy": "1"},
        {"pokemon": "伊布", "cp": "bad", "caught": "no", "candy": "1"},
        {"pokemon": "卡比獸", "cp": "1550", "caught": "no", "candy": "5"},
    ]
    records = clean_catch_rows(rows)
    expected = [
        {"pokemon": "皮卡丘", "cp": 420, "caught": True, "candy": 3},
        {"pokemon": "卡比獸", "cp": 1550, "caught": False, "candy": 5},
    ]
    print("輸入：含空名稱與不合法 CP 的原始列")
    print(f"預期：{expected}")
    print(f"實際：{records}")
    if records == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_catch_report() -> bool:
    print("---------------------------------")
    records = [
        {"pokemon": "皮卡丘", "cp": 420, "caught": True, "candy": 3},
        {"pokemon": "卡比獸", "cp": 1550, "caught": False, "candy": 5},
    ]
    report = build_catch_report(records)
    expected = {
        "record_count": 2,
        "caught_count": 1,
        "catch_rate": 0.5,
        "highest_cp": 1550,
        "total_candy": 8,
        "records": records,
    }
    print("輸入：兩筆清理後捕捉資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_report() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        report_path = Path(folder) / "reports" / "catch_report.json"
        report = {
            "record_count": 1,
            "caught_count": 1,
            "catch_rate": 1,
            "highest_cp": 420,
            "total_candy": 3,
            "records": [{"pokemon": "皮卡丘", "cp": 420, "caught": True, "candy": 3}],
        }
        save_report(report_path, report)
        raw_text = report_path.read_text(encoding="utf-8")
        loaded = json.loads(raw_text)
    print("輸入：報表路徑與報表字典")
    print(f"預期：{report}")
    print(f"實際：{loaded}")
    print("預期：JSON 原始文字保留中文")
    print(f"實際原始文字：{raw_text}")
    if loaded == report and "皮卡丘" in raw_text:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_report_from_csv() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        base_path = Path(folder)
        csv_path = base_path / "catch_records.csv"
        report_path = base_path / "nested" / "catch_report.json"
        csv_path.write_text(
            "pokemon,cp,caught,candy\n皮卡丘,420,yes,3\n,120,yes,1\n卡比獸,1550,no,5\n",
            encoding="utf-8",
        )
        report = build_report_from_csv(csv_path, report_path)
        loaded = json.loads(report_path.read_text(encoding="utf-8"))
    expected_count = 2
    print("輸入：含一筆無效列的捕捉 CSV")
    print(f"預期有效筆數：{expected_count}")
    print(f"實際有效筆數：{report.get('record_count')}")
    if report == loaded and report.get("record_count") == expected_count:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_catch_report_empty_records() -> bool:
    print("---------------------------------")
    report = build_catch_report([])
    expected = {
        "record_count": 0,
        "caught_count": 0,
        "catch_rate": 0,
        "highest_cp": 0,
        "total_candy": 0,
        "records": [],
    }
    print("輸入：沒有任何有效捕捉資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_load_catch_rows(),
        test_clean_catch_rows(),
        test_build_catch_report(),
        test_save_report(),
        test_build_report_from_csv(),
        test_build_catch_report_empty_records(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

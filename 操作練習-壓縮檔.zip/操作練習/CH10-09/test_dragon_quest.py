import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_dragon_quest import (
    build_party_report,
    build_report_from_csv,
    clean_party_rows,
    load_party_rows,
    save_report,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_load_party_rows() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        csv_path = Path(folder) / "party.csv"
        csv_path.write_text(
            "name,level,gold,active\n勇者,12,340,yes\n僧侶,10,120,no\n",
            encoding="utf-8",
        )
        rows = load_party_rows(csv_path)
    expected = [
        {"name": "勇者", "level": "12", "gold": "340", "active": "yes"},
        {"name": "僧侶", "level": "10", "gold": "120", "active": "no"},
    ]
    print("輸入：兩筆隊伍 CSV 資料")
    print(f"預期：{expected}")
    print(f"實際：{rows}")
    if rows == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_clean_party_rows() -> bool:
    print("---------------------------------")
    rows = [
        {"name": " 勇者 ", "level": "12", "gold": "340", "active": "yes"},
        {"name": "", "level": "9", "gold": "80", "active": "yes"},
        {"name": "僧侶", "level": "bad", "gold": "120", "active": "no"},
        {"name": "魔法使", "level": "8", "gold": "75", "active": "no"},
    ]
    records = clean_party_rows(rows)
    expected = [
        {"name": "勇者", "level": 12, "gold": 340, "active": True},
        {"name": "魔法使", "level": 8, "gold": 75, "active": False},
    ]
    print("輸入：含空名稱與不合法等級的原始列")
    print(f"預期：{expected}")
    print(f"實際：{records}")
    if records == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_party_report() -> bool:
    print("---------------------------------")
    records = [
        {"name": "勇者", "level": 12, "gold": 340, "active": True},
        {"name": "魔法使", "level": 8, "gold": 75, "active": False},
    ]
    report = build_party_report(records)
    expected = {
        "record_count": 2,
        "active_count": 1,
        "average_level": 10,
        "total_gold": 415,
        "records": records,
    }
    print("輸入：兩筆清理後角色資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_report() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        report_path = Path(folder) / "reports" / "party_report.json"
        report = {
            "record_count": 1,
            "active_count": 1,
            "average_level": 12,
            "total_gold": 340,
            "records": [{"name": "勇者", "level": 12, "gold": 340, "active": True}],
        }
        save_report(report_path, report)
        raw_text = report_path.read_text(encoding="utf-8")
        loaded = json.loads(raw_text)
    print("輸入：報表路徑與報表字典")
    print(f"預期：{report}")
    print(f"實際：{loaded}")
    print("預期：JSON 原始文字保留中文")
    print(f"實際原始文字：{raw_text}")
    if loaded == report and "勇者" in raw_text:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_report_from_csv() -> bool:
    print("---------------------------------")
    with TemporaryDirectory() as folder:
        base_path = Path(folder)
        csv_path = base_path / "party.csv"
        report_path = base_path / "nested" / "party_report.json"
        csv_path.write_text(
            "name,level,gold,active\n勇者,12,340,yes\n,9,80,yes\n魔法使,8,75,no\n",
            encoding="utf-8",
        )
        report = build_report_from_csv(csv_path, report_path)
        loaded = json.loads(report_path.read_text(encoding="utf-8"))
    expected_count = 2
    print("輸入：含一筆無效列的隊伍 CSV")
    print(f"預期有效筆數：{expected_count}")
    print(f"實際有效筆數：{report.get('record_count')}")
    if report == loaded and report.get("record_count") == expected_count:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_party_report_empty_records() -> bool:
    print("---------------------------------")
    report = build_party_report([])
    expected = {
        "record_count": 0,
        "active_count": 0,
        "average_level": 0,
        "total_gold": 0,
        "records": [],
    }
    print("輸入：沒有任何有效角色資料")
    print(f"預期：{expected}")
    print(f"實際：{report}")
    if report == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_load_party_rows(),
        test_clean_party_rows(),
        test_build_party_report(),
        test_save_report(),
        test_build_report_from_csv(),
        test_build_party_report_empty_records(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import csv
import json
from pathlib import Path


def load_catch_rows(csv_path: Path) -> list[dict[str, str]]:
    # 請只讀取 CSV 原始資料，不要在這裡清理或統計
    raise NotImplementedError("請完成 load_catch_rows")


def clean_catch_rows(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    # 請回傳新的清理結果，不要直接修改 rows
    raise NotImplementedError("請完成 clean_catch_rows")


def build_catch_report(records: list[dict[str, object]]) -> dict[str, object]:
    # 請根據清理後的捕捉資料建立統計報表
    raise NotImplementedError("請完成 build_catch_report")


def save_report(report_path: Path, report: dict[str, object]) -> None:
    # 請建立父資料夾，並把 report 寫成 JSON
    raise NotImplementedError("請完成 save_report")


def build_report_from_csv(csv_path: Path, report_path: Path) -> dict[str, object]:
    rows = load_catch_rows(csv_path)
    records = clean_catch_rows(rows)
    report = build_catch_report(records)
    save_report(report_path, report)
    return report


def main() -> None:
    base_path = Path(__file__).resolve().parent
    sample_csv = base_path / "catch_records.csv"
    sample_report = base_path / "reports" / "catch_report.json"
    print(build_report_from_csv(sample_csv, sample_report))


if __name__ == "__main__":
    main()
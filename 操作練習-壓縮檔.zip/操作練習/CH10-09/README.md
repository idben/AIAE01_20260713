# CH10-09 練習

## 題目

完成第十章檔案與資料處理綜合練習。

- 《勇者鬥惡龍》版：讀取隊伍 CSV，清理角色資料，輸出 JSON 報表。
- 《寶可夢 GO》版：讀取捕捉 CSV，清理捕捉資料，輸出 JSON 報表。
- 電子商務版：讀取訂單 CSV，清理訂單資料，統計營運報表並輸出 JSON。

## 檔案

- `main_dragon_quest.py`
- `party.csv`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `catch_records.csv`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `orders.csv`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

也可以直接打開 `test_dragon_quest.py`、`test_pokemon_go.py` 或 `test_ecommerce.py`，用編輯器的播放按鈕執行。

## 操作步驟

《勇者鬥惡龍》版：

先用 `party.csv` 觀察隊伍資料。這份檔案和測試檔內建的資料不同，裡面有有效角色，也有空名稱、等級錯誤、金幣錯誤的列。

1. 完成 `load_party_rows(csv_path)`，只把 CSV 原始列讀成 `list[dict[str, str]]`。
2. 完成 `clean_party_rows(rows)`，清理名稱並把 `level`、`gold` 轉成整數。
3. `active` 只有文字 `yes` 代表 `True`，其他文字代表 `False`。
4. 名稱空白、`level` 不是整數文字、或 `gold` 不是整數文字時，整列不要保留。
5. 完成 `build_party_report(records)`，統計有效角色數、仍在隊伍中的角色數、平均等級、總金幣。
6. 完成 `save_report(report_path, report)`，建立父資料夾並輸出 JSON。

《寶可夢 GO》版：

先用 `catch_records.csv` 觀察捕捉資料。這份檔案和測試檔內建的資料不同，裡面有有效捕捉紀錄，也有空名稱、CP 錯誤、糖果數錯誤的列。

1. 完成 `load_catch_rows(csv_path)`，只把 CSV 原始列讀成 `list[dict[str, str]]`。
2. 完成 `clean_catch_rows(rows)`，清理名稱並把 `cp`、`candy` 轉成整數。
3. `caught` 只有文字 `yes` 代表 `True`，其他文字代表 `False`。
4. 寶可夢名稱空白、`cp` 不是整數文字、或 `candy` 不是整數文字時，整列不要保留。
5. 完成 `build_catch_report(records)`，統計有效紀錄數、成功捕捉數、捕捉率、最高 CP、總糖果。
6. 完成 `save_report(report_path, report)`，建立父資料夾並輸出 JSON。

電子商務版：

先用 `orders.csv` 觀察訂單資料。這份檔案和測試檔內建的資料不同，裡面有一般訂單、急件訂單，也有訂單編號空白、金額錯誤、商品數錯誤的列。

1. 完成 `load_order_rows(csv_path)`，只把 CSV 原始列讀成 `list[dict[str, str]]`。
2. 完成 `clean_order_rows(rows)`，清理訂單編號並把 `total`、`item_count` 轉成整數。
3. `paid` 只有文字 `yes` 代表 `True`，其他文字代表 `False`。
4. `priority` 等於 `急件` 時，這筆訂單要放進急件訂單編號清單。
5. `total` 達到 2000 以上時，這筆訂單要放進高價訂單編號清單。
6. 訂單編號空白、`total` 不是整數文字、或 `item_count` 不是整數文字時，整列不要保留。
7. 完成 `build_order_report(records)`，統計有效訂單數、已付款訂單數、未付款金額總和、平均商品數、高價訂單編號與急件訂單編號。
8. 完成 `save_report(report_path, report)`，建立父資料夾並輸出 JSON，原始 JSON 文字要保留中文。

## 題目提示

名稱對照：

- `load_party_rows`：讀取隊伍原始列
- `clean_party_rows`：清理隊伍資料列
- `build_party_report`：建立隊伍報表
- `load_catch_rows`：讀取捕捉原始列
- `clean_catch_rows`：清理捕捉資料列
- `build_catch_report`：建立捕捉報表
- `load_order_rows`：讀取訂單原始列
- `clean_order_rows`：清理訂單資料列
- `build_order_report`：建立訂單報表
- `save_report`：保存 JSON 報表
- `records`：清理後資料清單

操作順序：

- 《勇者鬥惡龍》：讀取、清理、統計基本角色資料。
- 《寶可夢 GO》：多處理捕捉率、最高 CP 與糖果總數。
- 電子商務：整合訂單金額、付款狀態、商品數、急件與高價訂單，並保留 JSON 中文原始文字。

《勇者鬥惡龍》版報表 key 必須是：

- `record_count`
- `active_count`
- `average_level`
- `total_gold`
- `records`

《寶可夢 GO》版報表 key 必須是：

- `record_count`
- `caught_count`
- `catch_rate`
- `highest_cp`
- `total_candy`
- `records`

電子商務版報表 key 必須是：

- `record_count`
- `paid_count`
- `unpaid_total`
- `average_item_count`
- `high_value_order_ids`
- `rush_order_ids`
- `records`

`save_report(report_path, report)` 改的是目標檔案，不是 `report` 字典。寫檔前要先建立 `report_path.parent`。

## 檢查順序

1. 先檢查函式名稱和測試檔一致。
2. 再檢查清理後的欄位名稱和測試檔一致。
3. 確認數字欄位是 `int`，不是字串。
4. 確認布林欄位是 `True` 或 `False`。
5. 確認空資料時平均值或比率回傳 `0`；平均值可以是 `0` 或 `0.0`，但不能除以零。
6. 確認 JSON 檔案可以用 `json.loads()` 讀回同一份資料。

## 常見錯誤

- `load_*_rows()` 順便做了清理或統計，導致責任混在一起。
- 忘記 `strip()`，讓名稱前後空白被保留下來。
- 用 `int()` 直接轉不合法文字，導致測試中斷。
- 平均等級或捕捉率在空資料時除以零。
- 寫 JSON 時忘記 `ensure_ascii=False`，中文變成跳脫文字。
- 只印出報表，沒有 `return`。

## 你會練到什麼

- `csv.DictReader`
- 資料清理與型別轉換
- 統計報表
- `json.dumps()`
- `pathlib.Path` 與父資料夾建立

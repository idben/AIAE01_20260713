import random


def choose_monster_drop(drops: list[str]) -> str:
    # 請從 drops 中抽出一個掉落道具，並回傳道具名稱
    pass

import random


def choose_pokestop_rewards(rewards: list[str], reward_count: int) -> list[str]:
    # 請從 rewards 中抽出 reward_count 個不重複的補給站獎勵，並回傳新的清單
    pass

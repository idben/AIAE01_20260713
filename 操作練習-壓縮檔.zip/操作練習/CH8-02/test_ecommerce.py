import contextlib
import importlib
import io
import subprocess
import sys

from pathlib import Path

MODULE_NAME = "main_ecommerce"


def load_module():
    return importlib.import_module(MODULE_NAME)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_import_has_no_output() -> bool:
    print("---------------------------------")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        load_module()
    actual = output.getvalue()
    print("輸入：匯入 main_ecommerce")
    print("預期：匯入時沒有輸出")
    print(f"實際：{actual!r}")
    if actual == "":
        print("通過")
        return True
    print("失敗")
    return False


def test_has_main_block() -> bool:
    print("---------------------------------")
    source = Path(__file__).resolve().parent.joinpath("main_ecommerce.py").read_text(
        encoding="utf-8"
    )
    expected = 'if __name__ == "__main__":'
    print("輸入：檢查 main_ecommerce.py")
    print(f"預期：檔案中有 {expected}")
    print(f"實際：{'有' if expected in source else '沒有'}")
    if expected in source:
        print("通過")
        return True
    print("失敗")
    return False


def test_choose_checkout_coupon() -> bool:
    print("---------------------------------")
    module = load_module()
    coupons: list[dict[str, int | str]] = [
        {"code": "新客折扣", "min_total": 500, "discount": 50},
        {"code": "貴賓折扣", "min_total": 1000, "discount": 120},
        {"code": "大單折扣", "min_total": 2000, "discount": 300},
    ]
    original_coupons = [coupon.copy() for coupon in coupons]
    actual = module.choose_checkout_coupon(coupons, 1200)
    valid_codes = {"新客折扣", "貴賓折扣"}
    print("輸入：購物車 1200 元，三張優惠券")
    print("預期：只會抽到達到門檻的 新客折扣 或 貴賓折扣，且原清單不變")
    print(f"實際：{actual}，清單 {coupons}")
    if (
        isinstance(actual, dict)
        and actual["code"] in valid_codes
        and coupons == original_coupons
    ):
        print("通過")
        return True
    print("失敗")
    return False


def test_no_coupon() -> bool:
    print("---------------------------------")
    module = load_module()
    coupons: list[dict[str, int | str]] = [
        {"code": "貴賓折扣", "min_total": 1000, "discount": 120},
    ]
    actual = module.choose_checkout_coupon(coupons, 300)
    print("輸入：購物車 300 元，優惠券門檻 1000 元")
    print("預期：None")
    print(f"實際：{actual}")
    if actual is None:
        print("通過")
        return True
    print("失敗")
    return False


def test_coupon_at_threshold() -> bool:
    print("---------------------------------")
    module = load_module()
    coupons: list[dict[str, int | str]] = [
        {"code": "滿千折扣", "min_total": 1000, "discount": 100},
        {"code": "大單折扣", "min_total": 2000, "discount": 300},
    ]
    actual = module.choose_checkout_coupon(coupons, 1000)
    print("輸入：購物車 1000 元，一張門檻剛好 1000 元的優惠券")
    print("預期：可抽到 滿千折扣，不能抽到 大單折扣")
    print(f"實際：{actual}")
    if isinstance(actual, dict) and actual["code"] == "滿千折扣":
        print("通過")
        return True
    print("失敗")
    return False


def test_only_later_coupon_available() -> bool:
    print("---------------------------------")
    module = load_module()
    coupons: list[dict[str, int | str]] = [
        {"code": "高門檻折扣", "min_total": 3000, "discount": 500},
        {"code": "小額折扣", "min_total": 300, "discount": 30},
    ]
    actual = module.choose_checkout_coupon(coupons, 500)
    print("輸入：購物車 500 元，第一張未達門檻，第二張可用")
    print("預期：可抽到 小額折扣，不能抽到 高門檻折扣")
    print(f"實際：{actual}")
    if isinstance(actual, dict) and actual["code"] == "小額折扣":
        print("通過")
        return True
    print("失敗")
    return False


def test_all_coupons_available() -> bool:
    print("---------------------------------")
    module = load_module()
    coupons: list[dict[str, int | str]] = [
        {"code": "新客折扣", "min_total": 500, "discount": 50},
        {"code": "貴賓折扣", "min_total": 1000, "discount": 120},
        {"code": "大單折扣", "min_total": 2000, "discount": 300},
    ]
    original_coupons = [coupon.copy() for coupon in coupons]
    actual = module.choose_checkout_coupon(coupons, 2500)
    valid_codes = {"新客折扣", "貴賓折扣", "大單折扣"}
    print("輸入：購物車 2500 元，三張優惠券都達到門檻")
    print("預期：可抽到任一張優惠券，且原清單不變")
    print(f"實際：{actual}，清單 {coupons}")
    if (
        isinstance(actual, dict)
        and actual["code"] in valid_codes
        and coupons == original_coupons
    ):
        print("通過")
        return True
    print("失敗")
    return False


def test_run_demo() -> bool:
    print("---------------------------------")
    module = load_module()
    actual = module.run_demo()
    valid_codes = {"新客折扣", "貴賓折扣"}
    print("輸入：run_demo()")
    print("預期：回傳 1200 元購物車可用的 新客折扣 或 貴賓折扣")
    print(f"實際：{actual}")
    if isinstance(actual, dict) and actual["code"] in valid_codes:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_import_has_no_output(),
        test_has_main_block(),
        test_choose_checkout_coupon(),
        test_no_coupon(),
        test_coupon_at_threshold(),
        test_only_later_coupon_available(),
        test_all_coupons_available(),
        test_run_demo(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys

from pathlib import Path

from main_pokemon_go import choose_pokestop_rewards

TestCase = tuple[str, list[str], int]

test_cases: list[TestCase] = [
    ("一般補給站", ["精靈球", "傷藥", "蔓莓果", "復活石"], 3),
    ("少量獎勵", ["超級球", "好傷藥"], 1),
    ("活動補給站", ["高級球", "凰梨果", "星星沙子", "神奇糖果"], 4),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_choose_pokestop_rewards(
    label: str, rewards: list[str], reward_count: int
) -> bool:
    print("---------------------------------")
    original_rewards = rewards.copy()
    actual = choose_pokestop_rewards(rewards, reward_count)
    print(f"輸入：{label} {rewards}，抽出 {reward_count} 種")
    print("預期：回傳指定數量的不重複獎勵，全部來自原清單，且原清單不變")
    print(f"實際：回傳 {actual}，清單 {rewards}")
    if (
        isinstance(actual, list)
        and len(actual) == reward_count
        and len(set(actual)) == reward_count
        and all(reward in original_rewards for reward in actual)
        and rewards == original_rewards
    ):
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = []
    for case in test_cases:
        results.append(test_choose_pokestop_rewards(*case))
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import random


def choose_checkout_coupon(
    coupons: list[dict[str, int | str]],
    cart_total: int,
) -> dict[str, int | str] | None:
    # 請先找出達到門檻的優惠券，再從可用優惠券中抽出一張
    pass


def run_demo() -> dict[str, int | str] | None:
    # 請建立示範優惠券清單，並呼叫 choose_checkout_coupon()
    pass


def main() -> None:
    # 請印出 run_demo() 的結果
    pass


# 請在這裡加入 main block

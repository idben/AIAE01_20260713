import subprocess
import sys

from pathlib import Path

from main_dragon_quest import choose_monster_drop

TestCase = tuple[str, list[str]]

test_cases: list[TestCase] = [
    ("一般怪物掉落表", ["藥草", "金幣", "鐵劍"]),
    ("寶箱怪掉落表", ["小徽章"]),
    ("稀有怪物掉落表", ["魔法水", "世界樹之葉", "金屬史萊姆劍", "幸運種子"]),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_choose_monster_drop(label: str, drops: list[str]) -> bool:
    print("---------------------------------")
    original_drops = drops.copy()
    actual = choose_monster_drop(drops)
    print(f"輸入：{label} {drops}")
    print("預期：回傳清單中的其中一個道具，且原清單不變")
    print(f"實際：回傳 {actual}，清單 {drops}")
    if actual in original_drops and drops == original_drops:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = []
    for case in test_cases:
        results.append(test_choose_monster_drop(*case))
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

class Order:
    def __init__(self, order_id: str, subtotal: int, tax_rate: float) -> None:
        # 請記住 order_id、subtotal、tax_rate
        raise NotImplementedError("請完成 Order.__init__")

    @property
    def total(self) -> int:
        # 請回傳含稅總額，取整數
        raise NotImplementedError("請完成 total")

    @staticmethod
    def format_currency(amount: int) -> str:
        # 請把金額格式化成「NT$2100」這類字串
        raise NotImplementedError("請完成 format_currency")

    @classmethod
    def create_guest_order(cls, order_id: str, subtotal: int) -> "Order":
        # 請回傳 tax_rate=0.05 的訪客訂單
        raise NotImplementedError("請完成 create_guest_order")

import subprocess
import sys

from pathlib import Path

from main_ecommerce import Order

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_order_decorators() -> bool:
    print("---------------------------------")
    order = Order.create_guest_order("A1001", 2000)
    actual = (
        order.order_id,
        order.subtotal,
        order.tax_rate,
        order.total,
        Order.format_currency(order.total),
    )
    expected = ("A1001", 2000, 0.05, 2100, "NT$2100")
    print("輸入：create_guest_order('A1001', 2000)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_order_manual_instance() -> bool:
    print("---------------------------------")
    custom_order = Order("A1002", 800, 0.1)
    actual = (
        custom_order.order_id,
        custom_order.subtotal,
        custom_order.tax_rate,
        custom_order.total,
        Order.format_currency(custom_order.total),
    )
    expected = ("A1002", 800, 0.1, 880, "NT$880")
    print("輸入：Order('A1002', 800, 0.1)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_order_decorators(), test_order_manual_instance()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

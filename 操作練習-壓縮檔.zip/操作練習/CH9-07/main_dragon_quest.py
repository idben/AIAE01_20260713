class Equipment:
    def __init__(self, name: str, attack_bonus: int, defense_bonus: int) -> None:
        # 請記住 name、attack_bonus、defense_bonus
        raise NotImplementedError("請完成 Equipment.__init__")

    @property
    def total_bonus(self) -> int:
        # 請回傳攻擊加成與防禦加成的總和
        raise NotImplementedError("請完成 total_bonus")

    @staticmethod
    def format_bonus(value: int) -> str:
        # 請把加成數字格式化成 +數字
        raise NotImplementedError("請完成 format_bonus")

    @classmethod
    def create_copper_sword(cls) -> "Equipment":
        # 請回傳 name=銅劍、attack_bonus=5、defense_bonus=0 的裝備
        raise NotImplementedError("請完成 create_copper_sword")

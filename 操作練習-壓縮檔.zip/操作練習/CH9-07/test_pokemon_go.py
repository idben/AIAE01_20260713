import subprocess
import sys

from pathlib import Path

from main_pokemon_go import BuddyProgress

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_buddy_progress_decorators() -> bool:
    print("---------------------------------")
    buddy = BuddyProgress.create_new_buddy("伊布")
    buddy.hearts = 4
    actual = (
        buddy.pokemon_name,
        buddy.hearts,
        buddy.max_hearts,
        buddy.friendship_progress,
        BuddyProgress.hearts_to_points(buddy.hearts),
    )
    expected = ("伊布", 4, 10, 0.4, 40)
    print("輸入：create_new_buddy('伊布') 後 hearts=4")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_buddy_progress_caps_at_one() -> bool:
    print("---------------------------------")
    maxed = BuddyProgress("卡比獸", 15, 10)
    actual = (
        maxed.pokemon_name,
        maxed.hearts,
        maxed.max_hearts,
        maxed.friendship_progress,
        BuddyProgress.hearts_to_points(maxed.hearts),
    )
    expected = ("卡比獸", 15, 10, 1.0, 150)
    print("輸入：BuddyProgress('卡比獸', 15, 10)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_buddy_progress_decorators(), test_buddy_progress_caps_at_one()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

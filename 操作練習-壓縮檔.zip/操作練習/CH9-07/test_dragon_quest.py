import subprocess
import sys

from pathlib import Path

from main_dragon_quest import Equipment

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_equipment_decorators() -> bool:
    print("---------------------------------")
    sword = Equipment.create_copper_sword()
    actual = (
        sword.name,
        sword.attack_bonus,
        sword.defense_bonus,
        sword.total_bonus,
        Equipment.format_bonus(sword.total_bonus),
    )
    expected = ("銅劍", 5, 0, 5, "+5")
    print("輸入：create_copper_sword()")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_equipment_manual_instance() -> bool:
    print("---------------------------------")
    shield = Equipment("鐵盾", 0, 8)
    actual = (
        shield.name,
        shield.attack_bonus,
        shield.defense_bonus,
        shield.total_bonus,
        Equipment.format_bonus(shield.total_bonus),
    )
    expected = ("鐵盾", 0, 8, 8, "+8")
    print("輸入：Equipment('鐵盾', 0, 8)")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_equipment_decorators(), test_equipment_manual_instance()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

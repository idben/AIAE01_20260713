class BuddyProgress:
    def __init__(self, pokemon_name: str, hearts: int, max_hearts: int) -> None:
        # 請記住 pokemon_name、hearts、max_hearts
        raise NotImplementedError("請完成 BuddyProgress.__init__")

    @property
    def friendship_progress(self) -> float:
        # 請回傳友情進度，最高為 1.0
        raise NotImplementedError("請完成 friendship_progress")

    @staticmethod
    def hearts_to_points(hearts: int) -> int:
        # 請把愛心數換算成點數，每顆 10 點
        raise NotImplementedError("請完成 hearts_to_points")

    @classmethod
    def create_new_buddy(cls, pokemon_name: str) -> "BuddyProgress":
        # 請回傳 hearts=0、max_hearts=10 的夥伴進度
        raise NotImplementedError("請完成 create_new_buddy")

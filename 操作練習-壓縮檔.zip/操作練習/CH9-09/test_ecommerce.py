import subprocess
import sys

from pathlib import Path

from main_ecommerce import ship_order

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_ship_paid_order() -> bool:
    print("---------------------------------")
    order = {"order_id": "A1001", "paid": True, "shipped": False}
    message = ship_order(order)
    expected_message = "訂單 A1001 已出貨"
    expected_shipped = True
    actual_shipped = order["shipped"]
    print("輸入：paid=True 的訂單")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期 shipped：{expected_shipped}")
    print(f"實際 shipped：{actual_shipped}")
    if message == expected_message and actual_shipped == expected_shipped:
        print("通過")
        return True
    print("失敗")
    return False


def test_ship_unpaid_order() -> bool:
    print("---------------------------------")
    order = {"order_id": "A1002", "paid": False, "shipped": False}
    message = ship_order(order)
    expected_message = "訂單 A1002 尚未付款，不能出貨"
    expected_shipped = False
    actual_shipped = order["shipped"]
    print("輸入：paid=False 的訂單")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期 shipped：{expected_shipped}")
    print(f"實際 shipped：{actual_shipped}")
    if message == expected_message and actual_shipped == expected_shipped:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_ship_paid_order(), test_ship_unpaid_order()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from functools import wraps


def log_action(original_function):
    # 請回傳 wrapper，wrapper 不需要顯示固定文字，只要保留原函式回傳值
    raise NotImplementedError("請完成 log_action")


def require_paid_order(original_function):
    # 請回傳 wrapper，paid 為 False 時回傳「訂單 訂單編號 尚未付款，不能出貨」，不要呼叫原函式
    raise NotImplementedError("請完成 require_paid_order")


@log_action
@require_paid_order
def ship_order(order: dict[str, object]) -> str:
    order["shipped"] = True
    return f"訂單 {order['order_id']} 已出貨"

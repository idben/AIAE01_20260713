import subprocess
import sys

from pathlib import Path

from main_dragon_quest import cast_spell

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_cast_spell_with_mp() -> bool:
    print("---------------------------------")
    hero = {"name": "勇者", "silenced": False}
    actual = cast_spell(hero, "荷伊米")
    expected = "勇者 施放 荷伊米"
    print("輸入：勇者 silenced=False")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_cast_spell_without_mp() -> bool:
    print("---------------------------------")
    hero = {"name": "勇者", "silenced": True}
    actual = cast_spell(hero, "荷伊米")
    expected = "勇者 被沉默，不能施法"
    print("輸入：勇者 silenced=True")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_cast_spell_with_mp(), test_cast_spell_without_mp()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

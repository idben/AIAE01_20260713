from functools import wraps


def log_action(original_function):
    # 請回傳 wrapper，wrapper 不需要顯示固定文字，只要保留原函式回傳值
    raise NotImplementedError("請完成 log_action")


def require_incense_active(original_function):
    # 請回傳 wrapper，薰香時間小於等於 0 時回傳「訓練家名稱 的薰香已結束」，不要呼叫原函式
    raise NotImplementedError("請完成 require_incense_active")


@log_action
@require_incense_active
def encounter_incense_pokemon(trainer: dict[str, object], pokemon_name: str) -> str:
    trainer["incense_minutes"] -= 1
    return f"{trainer['name']} 因薰香遇見 {pokemon_name}"

import subprocess
import sys

from pathlib import Path

from main_pokemon_go import encounter_incense_pokemon

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_incense_active() -> bool:
    print("---------------------------------")
    trainer = {"name": "訓練家", "incense_minutes": 2}
    message = encounter_incense_pokemon(trainer, "皮卡丘")
    expected_message = "訓練家 因薰香遇見 皮卡丘"
    expected_minutes = 1
    actual_minutes = trainer["incense_minutes"]
    print("輸入：incense_minutes=2，皮卡丘")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期薰香分鐘：{expected_minutes}")
    print(f"實際薰香分鐘：{actual_minutes}")
    if message == expected_message and actual_minutes == expected_minutes:
        print("通過")
        return True
    print("失敗")
    return False


def test_incense_inactive() -> bool:
    print("---------------------------------")
    trainer = {"name": "訓練家", "incense_minutes": 0}
    message = encounter_incense_pokemon(trainer, "皮卡丘")
    expected_message = "訓練家 的薰香已結束"
    expected_minutes = 0
    actual_minutes = trainer["incense_minutes"]
    print("輸入：incense_minutes=0，皮卡丘")
    print(f"預期訊息：{expected_message}")
    print(f"實際訊息：{message}")
    print(f"預期薰香分鐘：{expected_minutes}")
    print(f"實際薰香分鐘：{actual_minutes}")
    if message == expected_message and actual_minutes == expected_minutes:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_incense_active(), test_incense_inactive()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from functools import wraps


def log_action(original_function):
    # 請回傳 wrapper，wrapper 要保留原函式回傳值
    raise NotImplementedError("請完成 log_action")


def require_not_silenced(original_function):
    # 請回傳 wrapper，被沉默時不要呼叫原函式
    raise NotImplementedError("請完成 require_not_silenced")


@log_action
@require_not_silenced
def cast_spell(caster: dict[str, object], spell_name: str) -> str:
    return f"{caster['name']} 施放 {spell_name}"

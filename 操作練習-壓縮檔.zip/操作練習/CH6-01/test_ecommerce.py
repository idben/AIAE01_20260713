import subprocess
import sys
from pathlib import Path

from main_ecommerce import PriceStockRange

TestCase = tuple[tuple[int, int, int, int], tuple[int, int, int, int]]

test_cases: list[TestCase] = [
    ((100, 10, 50, 20), (100, 10, 150, 30)),
    ((250, 0, 100, 15), (250, 0, 350, 15)),
    ((999, 5, 1, 45), (999, 5, 1000, 50)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(args: tuple[int, int, int, int], expected: tuple[int, int, int, int]) -> bool:
    print("---------------------------------")
    print(f"輸入：{args}")
    range_filter = PriceStockRange(*args)
    actual = range_filter.get_bounds()
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

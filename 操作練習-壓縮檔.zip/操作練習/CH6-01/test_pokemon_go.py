import subprocess
import sys
from pathlib import Path

from main_pokemon_go import MapZone

TestCase = tuple[tuple[int, int, int], tuple[int, int, int, int]]

test_cases: list[TestCase] = [
    ((2, 2, 1), (1, 1, 3, 3)),
    ((4, -1, 3), (1, -4, 7, 2)),
    ((-5, 0, 2), (-7, -2, -3, 2)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(args: tuple[int, int, int], expected: tuple[int, int, int, int]) -> bool:
    print("---------------------------------")
    print(f"輸入：{args}")
    zone = MapZone(*args)
    actual = zone.get_bounds()
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

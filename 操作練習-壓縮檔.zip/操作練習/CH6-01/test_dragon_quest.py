import subprocess
import sys
from pathlib import Path

from main_dragon_quest import BattleArea

TestCase = tuple[tuple[int, int, int, int], tuple[int, int, int, int]]

test_cases: list[TestCase] = [
    ((0, 1, 4, 2), (0, 1, 4, 2)),
    ((5, 5, 0, 0), (5, 5, 0, 0)),
    ((-10, -10, -5, -5), (-10, -10, -5, -5)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(args: tuple[int, int, int, int], expected: tuple[int, int, int, int]) -> bool:
    print("---------------------------------")
    print(f"輸入：{args}")
    area = BattleArea(*args)
    actual = area.get_bounds()
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

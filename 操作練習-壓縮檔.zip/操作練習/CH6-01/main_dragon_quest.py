class BattleArea:
    def __init__(self, x1: int, y1: int, x2: int, y2: int) -> None:
        pass

    def get_bounds(self) -> tuple[int, int, int, int]:
        pass

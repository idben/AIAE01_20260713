# CH6-01 練習

## 題目

建立不同型態的範圍物件，並提供共同方法 `get_bounds()` 回傳矩形邊界。

- 《勇者鬥惡龍》版：`BattleArea` 直接保存兩個角落
- 《寶可夢 GO》版：`MapZone` 用中心點和半徑換算邊界
- 電子商務版：`PriceStockRange` 用最低價格、最低庫存、價格跨度和庫存跨度換算邊界

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先選一個版本練習。
2. 打開對應的 `main_*.py`。
3. 在 constructor 裡保存該版本需要記住的資料。
4. 完成 `get_bounds()`，回傳四個整理後的邊界值。
5. 存檔後執行對應測試。

## 題目提示

### 《勇者鬥惡龍》版

`BattleArea` 表示戰鬥或咒文範圍，建構時會收到兩個角落座標 `x1`、`y1`、`x2`、`y2`。

`get_bounds()` 要回傳：

```python
(x1, y1, x2, y2)
```

### 《寶可夢 GO》版

`MapZone` 表示地圖上的寶可夢出現範圍，建構時會收到 `center_x`、`center_y`、`radius`。

`get_bounds()` 要回傳：

```python
(center_x - radius, center_y - radius, center_x + radius, center_y + radius)
```

### 電子商務版

`PriceStockRange` 是價格庫存區間，建構時會收到 `min_price`、`min_stock`、`price_span`、`stock_span`。這一版可以把價格想成 x 軸，把庫存量想成 y 軸。

`get_bounds()` 要回傳：

```python
(min_price, min_stock, max_price, max_stock)
```

## 這題常見錯誤

- 忘記加上 `self.`
- 座標存錯順序
- `get_bounds()` 沒有回傳 tuple
- 把三個版本都寫成同一種座標規則，沒有依照各版本的資料來源換算

## 這題在測什麼

- constructor 是否正確保存實例變數
- 不同類別是否能提供同樣的 `get_bounds()` 呼叫方式

# CH10-07 練習

## 題目

練習清理資料與轉換型別。

- 《勇者鬥惡龍》版：清理道具價格列。
- 《寶可夢 GO》版：清理捕捉紀錄列。
- 電子商務版：清理訂單資料列。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

名稱對照：

- `clean_item_price_rows`：清理道具價格列
- `clean_catch_rows`：清理捕捉紀錄列
- `clean_order_rows`：清理訂單資料列
- `rows`：原始資料列
- `cleaned_items` / `cleaned_records`：清理後的新資料

清理函式要回傳新清單，不要直接修改原始 `rows`。名稱空白或數字欄位不合法的列不要保留。狀態欄位要先清理空白、統一大小寫，再轉成布林值。

《寶可夢 GO》版除了 `pokemon`、`cp` 和 `caught`，還要處理 `candy`。CP 或糖果數不是整數文字時，整列都不要保留。

電子商務版要同時檢查 `order_id`、`total`、`item_count` 和 `priority`。訂單編號空白、金額不是整數、商品數不是整數時，整列都不要保留；急件分類要保留清理後的文字。

操作順序：

- 《勇者鬥惡龍》：清理名稱與單一數字欄位。
- 《寶可夢 GO》：清理名稱、CP、捕捉狀態與糖果數。
- 電子商務：清理訂單編號、金額、付款狀態、商品數與急件分類，無效欄位更多。

## 範例資料

下面的資料不是測試檔內容，只是用來幫你確認每題要處理哪些欄位、哪些列要略過。

### 《勇者鬥惡龍》版

原始資料：

```python
rows = [
    {"name": " 解毒草 ", "price": "12"},
    {"name": " ", "price": "50"},
    {"name": "旅人服", "price": "abc"},
    {"name": "聖水", "price": "30"},
]
```

清理後：

```python
[
    {"name": "解毒草", "price": 12},
    {"name": "聖水", "price": 30},
]
```

### 《寶可夢 GO》版

原始資料：

```python
rows = [
    {"pokemon": " 波波 ", "cp": "88", "caught": " yes ", "candy": "1"},
    {"pokemon": " ", "cp": "45", "caught": "yes", "candy": "2"},
    {"pokemon": "可達鴨", "cp": "oops", "caught": "no", "candy": "3"},
    {"pokemon": "胖丁", "cp": "510", "caught": "NO", "candy": "5"},
]
```

清理後：

```python
[
    {"pokemon": "波波", "cp": 88, "caught": True, "candy": 1},
    {"pokemon": "胖丁", "cp": 510, "caught": False, "candy": 5},
]
```

### 電子商務版

原始資料：

```python
rows = [
    {"order_id": " WEB-3001 ", "total": "990", "paid": " YES ", "item_count": "2", "priority": " 一般 "},
    {"order_id": " ", "total": "700", "paid": "no", "item_count": "1", "priority": "急件"},
    {"order_id": "WEB-3002", "total": "oops", "paid": "yes", "item_count": "4", "priority": "一般"},
    {"order_id": "WEB-3003", "total": "360", "paid": "no", "item_count": "", "priority": "一般"},
    {"order_id": "WEB-3004", "total": "1500", "paid": "no", "item_count": "6", "priority": "急件"},
]
```

清理後：

```python
[
    {"order_id": "WEB-3001", "total": 990, "paid": True, "item_count": 2, "priority": "一般"},
    {"order_id": "WEB-3004", "total": 1500, "paid": False, "item_count": 6, "priority": "急件"},
]
```

## 常見錯誤

- 沒有 `strip()`。
- 對不合法文字直接 `int()`。
- 把無效列也放進結果。
- 忘記處理 `YES`、`NO` 或前後有空白的狀態文字。
- 漏掉 `candy` 或 `priority` 欄位。

## 你會練到什麼

- 字串清理
- `isdigit()`
- 型別轉換與過濾

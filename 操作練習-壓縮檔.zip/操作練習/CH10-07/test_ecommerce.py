from pathlib import Path
from main_ecommerce import clean_order_rows
import subprocess
import sys


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_clean_order_rows() -> bool:
    cases = [
        (
            [
                {"order_id": " ORD-1001 ", "total": "1200", "paid": "yes", "item_count": "3", "priority": " 一般 "},
                {"order_id": "", "total": "850", "paid": "no", "item_count": "1", "priority": "急件"},
                {"order_id": "ORD-1002", "total": "bad", "paid": "no", "item_count": "2", "priority": "一般"},
                {"order_id": "ORD-1003", "total": "450", "paid": "no", "item_count": "bad", "priority": "一般"},
                {"order_id": "ORD-1004", "total": "2000", "paid": "NO", "item_count": "5", "priority": " 急件 "},
            ],
            [
                {"order_id": "ORD-1001", "total": 1200, "paid": True, "item_count": 3, "priority": "一般"},
                {"order_id": "ORD-1004", "total": 2000, "paid": False, "item_count": 5, "priority": "急件"},
            ],
            "含無效列的訂單資料",
        ),
        (
            [
                {"order_id": " EC-2001 ", "total": "3000", "paid": " no ", "item_count": "4", "priority": "急件"},
                {"order_id": "EC-2002", "total": "500", "paid": "YES", "item_count": "1", "priority": " 一般 "},
                {"order_id": "EC-2003", "total": "", "paid": "yes", "item_count": "2", "priority": "一般"},
            ],
            [
                {"order_id": "EC-2001", "total": 3000, "paid": False, "item_count": 4, "priority": "急件"},
                {"order_id": "EC-2002", "total": 500, "paid": True, "item_count": 1, "priority": "一般"},
            ],
            "含空金額的訂單資料",
        ),
    ]
    all_passed = True
    for rows, expected, description in cases:
        print("---------------------------------")
        actual = clean_order_rows(rows)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_clean_order_rows()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

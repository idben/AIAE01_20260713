from pathlib import Path
from main_dragon_quest import clean_item_price_rows
import subprocess
import sys


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_clean_item_price_rows() -> bool:
    cases = [
        (
            [
                {"name": " 藥草 ", "price": "8"},
                {"name": "", "price": "20"},
                {"name": "鐵盾", "price": "bad"},
                {"name": "銅劍", "price": "180"},
            ],
            [{"name": "藥草", "price": 8}, {"name": "銅劍", "price": 180}],
            "含無效列的道具價格資料",
        ),
        (
            [
                {"name": " 魔法水 ", "price": "60"},
                {"name": "布衣", "price": ""},
                {"name": "鋼劍", "price": "350"},
            ],
            [{"name": "魔法水", "price": 60}, {"name": "鋼劍", "price": 350}],
            "含空價格的道具價格資料",
        ),
    ]
    all_passed = True
    for rows, expected, description in cases:
        print("---------------------------------")
        actual = clean_item_price_rows(rows)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_clean_item_price_rows()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

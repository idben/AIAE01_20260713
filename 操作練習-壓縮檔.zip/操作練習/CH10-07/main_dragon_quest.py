def clean_item_price_rows(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    # 請依課文規則清理道具價格資料
    raise NotImplementedError("請完成 clean_item_price_rows")


def main() -> None:
    print(clean_item_price_rows([{"name": " 藥草 ", "price": "8"}]))


if __name__ == "__main__":
    main()

from pathlib import Path
from main_pokemon_go import clean_catch_rows
import subprocess
import sys


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_clean_catch_rows() -> bool:
    cases = [
        (
            [
                {"pokemon": " 皮卡丘 ", "cp": "420", "caught": "yes", "candy": "3"},
                {"pokemon": "", "cp": "120", "caught": "yes", "candy": "3"},
                {"pokemon": "伊布", "cp": "bad", "caught": "no", "candy": "1"},
                {"pokemon": "卡比獸", "cp": "1550", "caught": "NO", "candy": "0"},
            ],
            [
                {"pokemon": "皮卡丘", "cp": 420, "caught": True, "candy": 3},
                {"pokemon": "卡比獸", "cp": 1550, "caught": False, "candy": 0},
            ],
            "含無效列的捕捉資料",
        ),
        (
            [
                {"pokemon": " 妙蛙種子 ", "cp": "300", "caught": " yes ", "candy": "4"},
                {"pokemon": "小火龍", "cp": "", "caught": "yes", "candy": "3"},
                {"pokemon": "傑尼龜", "cp": "280", "caught": "no", "candy": "bad"},
                {"pokemon": "伊布", "cp": "250", "caught": "YES", "candy": "2"},
            ],
            [
                {"pokemon": "妙蛙種子", "cp": 300, "caught": True, "candy": 4},
                {"pokemon": "伊布", "cp": 250, "caught": True, "candy": 2},
            ],
            "含空 CP 與不合法糖果數的捕捉資料",
        ),
    ]
    all_passed = True
    for rows, expected, description in cases:
        print("---------------------------------")
        actual = clean_catch_rows(rows)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_clean_catch_rows()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

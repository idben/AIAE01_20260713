def clean_catch_rows(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    # 請依課文規則清理捕捉資料
    raise NotImplementedError("請完成 clean_catch_rows")


def main() -> None:
    print(clean_catch_rows([{"pokemon": " 皮卡丘 ", "cp": "420", "caught": "yes", "candy": "3"}]))


if __name__ == "__main__":
    main()

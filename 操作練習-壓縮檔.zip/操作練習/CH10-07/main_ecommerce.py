def clean_order_rows(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    # 請依課文規則清理訂單資料
    raise NotImplementedError("請完成 clean_order_rows")


def main() -> None:
    print(clean_order_rows([
        {"order_id": " ORD-1001 ", "total": "1200", "paid": "yes", "item_count": "3", "priority": "一般"},
    ]))


if __name__ == "__main__":
    main()

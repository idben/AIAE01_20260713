def filter_active_nearby_spawn(nearby_spawn: list[int]) -> list[int]:
    s: list[int] = []
    for t in nearby_spawn:
        if t > 0:
            s.append(t)
    return s

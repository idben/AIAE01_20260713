def remove_fainted_party_member(party_hp: list[int]) -> list[int]:
    h: list[int] = []
    for p in party_hp:
        if p > 0:
            h.append(p)
    return h

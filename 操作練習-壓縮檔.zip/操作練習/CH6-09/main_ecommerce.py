class ProductDeal:
    def __init__(self, name: str, original_price: int, sale_price: int) -> None:
        self.name = name
        self.original_price = original_price
        self.sale_price = sale_price
        self.discount_value = original_price - sale_price

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProductDeal):
            return False
        return self.sale_price == other.sale_price

    def __lt__(self, other: "ProductDeal") -> bool:
        return self.sale_price < other.sale_price

    def __gt__(self, other: "ProductDeal") -> bool:
        return self.sale_price > other.sale_price

    # 以下內容不要修改

    def __str__(self) -> str:
        return f"{self.name} 原價 {self.original_price} 特價 {self.sale_price}"

# CH6-09 練習

## 題目

完成比較運算子多載。

- 《勇者鬥惡龍》版：`Card` 先比 rank，再比 suit
- 《寶可夢 GO》版：`RaidPokemon` 先計算戰力分數，再比較分數
- 電子商務版：除錯 `ProductDeal` 的折扣方案比較規則

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 打開對應的 `main_*.py`。
2. 完成 constructor。
3. 完成 `__eq__()`、`__lt__()`、`__gt__()`。
4. 存檔後執行對應測試。

## 題目提示

三個版本都會用到 `__eq__()`、`__lt__()`、`__gt__()`，但比較規則不同。勇者版用清單 index，寶可夢版用計算分數，電子商務版是除錯題。

### 《勇者鬥惡龍》版

這版可以直接照撲克牌規則做：先比較 rank，rank 相同時才比較 suit。`RANKS` 和 `SUITS` 清單中的 index 越大，代表值越大。原因是牌面大小是主要條件，花色只在牌面相同時用來打破平手。

`__eq__()` 的檢查層級是整張牌是否相同，所以 rank 和 suit 都要相同才回傳 `True`。如果拿 `Card` 跟不是 `Card` 的物件比較，應該回傳 `False`。

### 《寶可夢 GO》版

`RaidPokemon` 要保存 `name`、`cp`、`attack_iv`，再用下面公式算出 `battle_power`：

```text
battle_power = cp + attack_iv * 100
```

比較時只看 `battle_power`。分數相同時，`==` 回傳 `True`；分數較高時，`>` 回傳 `True`；分數較低時，`<` 回傳 `True`。

### 電子商務版

這一版是除錯題。`ProductDeal` 已經保存 `name`、`original_price`、`sale_price`、`discount_value`，但比較方法目前用錯規則。

正確規則：

- 折扣金額越高，代表優惠價值越高
- 折扣金額相同時，特價越低，代表顧客實際付得更少，也比較划算
- `>` 代表左邊方案比右邊方案更划算
- `==` 代表兩個方案的折扣金額相同，而且特價也相同

## 這題常見錯誤

- `__eq__()` 沒有處理對方不是 `Card`
- 寶可夢版忘記先算 `battle_power`
- 電子商務版只看特價，忘記先看折扣金額

## 這題在測什麼

- 比較運算子多載
- 不同情境可以把 `==`、`<`、`>` 包裝成不同規則
- constructor 是否保存測試會檢查的屬性

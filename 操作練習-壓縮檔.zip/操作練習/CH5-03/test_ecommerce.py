import subprocess
import sys
from pathlib import Path

from main_ecommerce import Coat

TestCase = tuple[str, int, str | None, int | None]

run_cases: list[TestCase] = [
    ("Wool Coat", 5, None, 2),
    ("Rain Coat", 3, None, 0),
]

submit_cases: list[TestCase] = run_cases + [
    ("Trench Coat", 2, "not enough stock", None),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(name: str, stock: int, expected_error: str | None, expected_remaining: int | None) -> bool:
    print("---------------------------------")
    coat = Coat(name, stock)
    try:
        actual = coat.prepare_display_set()
        expected = f"{name} display set of 3 is ready"
        print(f"預期訊息：{expected}")
        print(f"實際訊息：{actual}")
        print(f"預期剩餘庫存：{expected_remaining}")
        print(f"實際剩餘庫存：{coat.get_stock()}")
        if expected_error:
            return False
        return actual == expected and coat.get_stock() == expected_remaining
    except Exception as error:
        print(f"預期例外：{expected_error}")
        print(f"實際例外：{error}")
        return str(error) == expected_error


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

# CH5-03 練習

## 題目

這一課練習多層繼承。

- 《勇者鬥惡龍》版：完成 `Archer` 和 `Crossbowman`
- 《寶可夢 GO》版：完成 `BallThrowEncounter` 和 `QuickCatchEncounter`
- 《電子商務》版：完成 `Clothing` 和 `Coat`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先看中層類別記住的是什麼資源
2. 先完成資源扣除方法
3. 再完成最下層子類別建構子
4. 最後完成一次消耗 3 個資源的進階方法
5. 執行測試確認例外訊息與回傳字串

## 常見錯誤

- 資源不足時沒有丟出正確訊息
- 最下層建構子忘記呼叫 `super()`
- 進階方法沒有先消耗 3 個資源
- 回傳字串和題目要求不一致

## 這題在測什麼

- 多層繼承
- 重用父類別方法
- 例外條件檢查

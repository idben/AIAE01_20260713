import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Archer, Crossbowman

TestCase = tuple[str, int, str, int, str | None, int | None]

run_cases: list[TestCase] = [
    ("勇者", 2, "庫庫爾", 5, None, 2),
    ("傑西卡", 4, "安潔羅", 3, None, 0),
]

submit_cases: list[TestCase] = run_cases + [
    ("特瑞", 1, "楊格斯", 2, "not enough arrows", None),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(archer_name: str, archer_arrows: int, crossbowman_name: str, bolts: int, expected_error: str | None, expected_remaining: int | None) -> bool:
    print("---------------------------------")
    target = Archer(archer_name, archer_arrows)
    unit = Crossbowman(crossbowman_name, bolts)
    try:
        actual = unit.triple_shot(target)
        expected = f"{archer_name} was shot by 3 crossbow bolts"
        print(f"預期訊息：{expected}")
        print(f"實際訊息：{actual}")
        print(f"預期剩餘箭數：{expected_remaining}")
        print(f"實際剩餘箭數：{unit.get_num_arrows()}")
        if expected_error:
            return False
        return actual == expected and unit.get_num_arrows() == expected_remaining
    except Exception as error:
        print(f"預期例外：{expected_error}")
        print(f"實際例外：{error}")
        return str(error) == expected_error


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

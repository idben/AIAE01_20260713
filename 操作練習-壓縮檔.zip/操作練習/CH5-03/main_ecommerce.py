class Product:
    def __init__(self, name: str) -> None:
        self.__name = name

    def get_name(self) -> str:
        return self.__name


## 以上內容不要修改


class Clothing():
    def __init__(self, name: str, stock: int) -> None:
        pass

    def get_stock(self) -> int:
        pass

    def use_stock(self, num: int) -> None:
        pass


class Coat():
    def __init__(self, name: str, stock: int) -> None:
        pass

    def prepare_display_set(self) -> str:
        pass

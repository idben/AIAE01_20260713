import importlib
import subprocess
import sys
import traceback
from pathlib import Path

TestCase = tuple[str, int, str, int, int, int, str]

test_cases: list[TestCase] = [
    ("勇者", 120, "史萊姆", 30, 18, 12, "勇者 施放咒文，史萊姆 剩下 12 HP"),
    ("僧侶", 90, "龍", 160, 45, 115, "僧侶 施放咒文，龍 剩下 115 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def load_targets():
    try:
        characters = importlib.import_module("characters_dragon_quest")
        battle = importlib.import_module("battle_dragon_quest")
        return characters.PartyMember, battle.cast_spell
    except Exception:
        print("---------------------------------")
        print("匯入失敗，請先看錯誤訊息最後幾行：")
        print(traceback.format_exc(limit=8))
        print("請檢查 characters_dragon_quest.py 和 battle_dragon_quest.py 是否互相 import。")
        return None, None


def test_case(
    PartyMember,
    cast_spell,
    caster_name: str,
    caster_hp: int,
    target_name: str,
    target_hp: int,
    damage: int,
    expected_hp: int,
    expected_label: str,
) -> bool:
    print("---------------------------------")
    caster = PartyMember(caster_name, caster_hp)
    target = PartyMember(target_name, target_hp)
    actual_label = cast_spell(caster, target, damage)
    print(f"輸入：{caster_name}, {target_name}, {damage}")
    print(f"預期：{expected_label}, 目標 HP {expected_hp}")
    print(f"實際：{actual_label}, 目標 HP {target.hp}")
    if actual_label == expected_label and target.hp == expected_hp:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    PartyMember, cast_spell = load_targets()
    if PartyMember is None or cast_spell is None:
        print("============= 測試失敗 ==============")
        print("0 通過，1 失敗")
        return
    results = [test_case(PartyMember, cast_spell, *case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

def format_discount_label(product_name: str, sale_price: int) -> str:
    return f"{product_name} 活動價 {sale_price} 元"

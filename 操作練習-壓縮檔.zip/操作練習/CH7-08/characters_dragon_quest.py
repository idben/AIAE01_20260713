from battle_dragon_quest import cast_spell


class PartyMember:
    def __init__(self, name: str, hp: int) -> None:
        self.name = name
        self.hp = hp

    # 請讓隊伍成員自己提供更新 HP 的方法

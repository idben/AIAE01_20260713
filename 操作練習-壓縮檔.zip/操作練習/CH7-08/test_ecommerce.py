import importlib
import subprocess
import sys
import traceback
from pathlib import Path

TestCase = tuple[str, int, int, str]

test_cases: list[TestCase] = [
    ("機械鍵盤", 1800, 200, "機械鍵盤 活動價 1600 元"),
    ("無線滑鼠", 650, 50, "無線滑鼠 活動價 600 元"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def load_targets():
    try:
        product_catalog = importlib.import_module("product_catalog")
        discount_rules = importlib.import_module("discount_rules")
        return product_catalog.Product, discount_rules.apply_discount
    except Exception:
        print("---------------------------------")
        print("匯入失敗，請先看錯誤訊息最後幾行：")
        print(traceback.format_exc(limit=8))
        print("請檢查 product_catalog.py 和 discount_rules.py 是否互相 import；price_formatter.py 只是文字工具，不需要回頭匯入商品資料。")
        return None, None


def test_case(
    Product,
    apply_discount,
    name: str,
    price: int,
    discount_amount: int,
    expected: str,
) -> bool:
    print("---------------------------------")
    product = Product(name, price)
    actual = apply_discount(product, discount_amount)
    print(f"輸入：{name}, 原價 {price}, 折扣 {discount_amount}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    Product, apply_discount = load_targets()
    if Product is None or apply_discount is None:
        print("============= 測試失敗 ==============")
        print("0 通過，1 失敗")
        return
    results = [test_case(Product, apply_discount, *case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

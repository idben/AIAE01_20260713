from pokemon_go import RaidPokemon


def use_fast_move(attacker: RaidPokemon, target: RaidPokemon, damage: int) -> str:
    # 請呼叫目標物件的方法，並使用 raid_messages 裡已寫好的函式回傳文字
    pass

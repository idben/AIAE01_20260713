from product_catalog import Product


def apply_discount(product: Product, discount_amount: int) -> str:
    # 請使用商品資料、折扣金額與 price_formatter 裡已寫好的函式回傳文字
    pass

def format_fast_move_message(attacker_name: str, target_name: str, target_hp: int) -> str:
    return f"{attacker_name} 使用一般招式，{target_name} 剩下 {target_hp} HP"

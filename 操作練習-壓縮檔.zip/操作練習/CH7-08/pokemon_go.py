from raid_rules import use_fast_move


class RaidPokemon:
    def __init__(self, name: str, hp: int) -> None:
        self.name = name
        self.hp = hp

    # 請讓團體戰寶可夢自己提供更新 HP 的方法

from discount_rules import apply_discount


class Product:
    def __init__(self, name: str, price: int) -> None:
        self.name = name
        self.price = price

# CH7-08 練習

## 題目

修正循環匯入。

- 《勇者鬥惡龍》：隊伍成員資料與戰鬥規則
- 《寶可夢 GO》：團體戰寶可夢資料與團體戰規則
- 電子商務：商品資料與折扣規則

## 檔案

- `characters_dragon_quest.py`
- `battle_dragon_quest.py`
- `test_dragon_quest.py`
- `pokemon_go.py`
- `raid_rules.py`
- `raid_messages.py`
- `test_pokemon_go.py`
- `product_catalog.py`
- `discount_rules.py`
- `price_formatter.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先執行測試，觀察錯誤訊息最後幾行。
2. 找出哪兩個檔案在檔案最上方互相匯入。
3. 讓資料類別模組保持單純，不要匯入規則模組。
4. 讓規則模組單向匯入資料類別。
5. 再執行測試，確認原本的 import 錯誤消失，行為也正確。

## 題目提示

### 《勇者鬥惡龍》

- `PartyMember` 要記住 `name` 與 `hp`。
- 隊伍成員自己應該能處理 HP 更新。
- `cast_spell(caster, target, damage)` 應該放在戰鬥規則模組，並修改傳進來的 `target`。

### 《寶可夢 GO》

- `RaidPokemon` 要記住 `name` 與 `hp`。
- 團體戰寶可夢資料不需要知道所有團體戰規則。
- `raid_messages.py` 已經提供整理團體戰文字的函式。
- `use_fast_move(attacker, target, damage)` 應該修改傳進來的 `target`，再使用已寫好的文字函式回傳結果。

### 電子商務

- `Product` 要記住 `name` 與 `price`。
- 商品資料不需要知道折扣規則。
- `price_formatter.py` 已經提供整理活動價格文字的函式。
- `apply_discount(product, discount_amount)` 應該使用傳進來的商品資料與已寫好的文字函式，回傳活動價格文字。

## 這題常見錯誤

- 只把 import 移到另一個檔案，仍然維持互相匯入。
- 把兩個檔案合併回同一個檔案，沒有練到模組責任分工。
- 資料類別直接呼叫規則函式，讓資料模組又依賴規則模組。
- 解掉 import 錯誤後，忘記確認原本物件是否真的被更新。

## 這題在測什麼

- 讀懂匯入錯誤訊息
- 循環匯入修正
- 資料模組與規則模組的依賴方向
- 拆檔後仍能被測試穩定匯入

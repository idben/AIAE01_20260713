import importlib
import subprocess
import sys
import traceback
from pathlib import Path

TestCase = tuple[str, int, str, int, int, int, str]

test_cases: list[TestCase] = [
    ("皮卡丘", 88, "卡比獸", 180, 12, 168, "皮卡丘 使用一般招式，卡比獸 剩下 168 HP"),
    ("路卡利歐", 100, "班基拉斯", 150, 20, 130, "路卡利歐 使用一般招式，班基拉斯 剩下 130 HP"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def load_targets():
    try:
        pokemon = importlib.import_module("pokemon_go")
        raid_rules = importlib.import_module("raid_rules")
        return pokemon.RaidPokemon, raid_rules.use_fast_move
    except Exception:
        print("---------------------------------")
        print("匯入失敗，請先看錯誤訊息最後幾行：")
        print(traceback.format_exc(limit=8))
        print("請檢查 pokemon_go.py 和 raid_rules.py 是否互相 import；raid_messages.py 只是文字工具，不需要回頭匯入資料模組。")
        return None, None


def test_case(
    RaidPokemon,
    use_fast_move,
    attacker_name: str,
    attacker_hp: int,
    target_name: str,
    target_hp: int,
    damage: int,
    expected_hp: int,
    expected_label: str,
) -> bool:
    print("---------------------------------")
    attacker = RaidPokemon(attacker_name, attacker_hp)
    target = RaidPokemon(target_name, target_hp)
    actual_label = use_fast_move(attacker, target, damage)
    print(f"輸入：{attacker_name}, {target_name}, {damage}")
    print(f"預期：{expected_label}, 目標 HP {expected_hp}")
    print(f"實際：{actual_label}, 目標 HP {target.hp}")
    if actual_label == expected_label and target.hp == expected_hp:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    RaidPokemon, use_fast_move = load_targets()
    if RaidPokemon is None or use_fast_move is None:
        print("============= 測試失敗 ==============")
        print("0 通過，1 失敗")
        return
    results = [test_case(RaidPokemon, use_fast_move, *case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

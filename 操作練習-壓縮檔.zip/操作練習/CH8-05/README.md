# CH8-05 練習

## 題目

練習使用 `pathlib.Path` 組合資料檔路徑。

- 《勇者鬥惡龍》版：組合戰鬥紀錄檔路徑
- 《寶可夢 GO》版：組合捕捉紀錄檔路徑
- 電子商務版：組合指定訂單底下的發票檔路徑

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：組合一層紀錄資料夾與檔名。
- 《寶可夢 GO》：組合指定訓練家的捕捉紀錄路徑，多一層訓練家資料夾。
- 電子商務：路徑多一層訂單編號資料夾，且仍然不能建立檔案。

## 操作步驟

1. 先觀察函式收到的是基準資料夾、可能的中間分類資料，以及檔名。
2. 路徑函式只負責組合路徑，不要建立檔案。
3. 回傳 `Path` 物件，不要回傳字串。

## 題目提示

《勇者鬥惡龍》版：

- `get_battle_log_path(base_folder, file_name)` 代表戰鬥紀錄檔的位置。
- 戰鬥紀錄要放在 `battle_logs` 資料夾底下。

《寶可夢 GO》版：

- `get_catch_log_path(base_folder, trainer_id, file_name)` 代表指定訓練家的捕捉紀錄檔位置。
- 捕捉紀錄要放在 `trainers / trainer_id / catch_logs` 資料夾底下。

電子商務版：

- `get_invoice_path(base_folder, order_id, file_name)` 代表某筆訂單的發票檔位置。
- 發票要放在 `orders` 資料夾底下，再依照 `order_id` 分到各訂單資料夾。
- 這個函式只回傳路徑，不建立訂單資料夾，也不寫入發票檔。

## 檢查順序

1. 回傳值是否是 `Path`。
2. 是否包含正確的資料夾名稱。
3. 函式是否沒有建立任何檔案。
4. 寶可夢版是否把 `trainer_id` 放進路徑中間，而不是檔名裡。
5. 電子商務版是否把 `order_id` 放進路徑中間，而不是檔名裡。

## 常見錯誤

- 回傳字串而不是 `Path`。
- 路徑函式順便寫檔。
- 資料夾名稱拼錯。
- 寶可夢版少放訓練家資料夾，導致不同訓練家的紀錄混在一起。
- 電子商務版少放訂單編號資料夾，導致不同訂單發票混在一起。

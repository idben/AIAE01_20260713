from pathlib import Path


def get_catch_log_path(base_folder: Path, trainer_id: str, file_name: str) -> Path:
    # 請回傳指定訓練家的捕捉紀錄檔路徑，不要建立或寫入檔案
    pass

import subprocess
import sys
import tempfile

from pathlib import Path

from main_ecommerce import get_invoice_path

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_invoice_path() -> bool:
    print("---------------------------------")
    with tempfile.TemporaryDirectory() as temp_dir:
        base_folder = Path(temp_dir)
        actual = get_invoice_path(base_folder, "訂單-1001", "發票.json")
        expected = base_folder / "orders" / "訂單-1001" / "發票.json"
        file_created = actual.exists()
    print("輸入：base_folder, 訂單-1001, 發票.json")
    print(f"預期：{expected}，且檔案尚未被建立")
    print(f"實際：{actual}，檔案是否存在 {file_created}")
    if actual == expected and not file_created:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_invoice_path()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from pathlib import Path


def get_battle_log_path(base_folder: Path, file_name: str) -> Path:
    # 請回傳戰鬥紀錄檔路徑，不要建立或寫入檔案
    pass

from pathlib import Path


def get_invoice_path(base_folder: Path, order_id: str, file_name: str) -> Path:
    # 請回傳訂單發票檔路徑，不要建立或寫入檔案
    pass

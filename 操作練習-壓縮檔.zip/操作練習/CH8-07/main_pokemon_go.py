from collections import Counter, defaultdict


def count_pokestop_rewards(
    rewards: list[dict[str, int | str]],
) -> dict[str, Counter[str] | defaultdict[str, list[str]]]:
    # 請統計每種補給站獎勵總數，並依數量分組記錄道具名稱
    pass

from collections import Counter


def count_monster_drops(drops: list[str]) -> Counter[str]:
    # 請統計每種怪物掉落道具出現幾次
    pass

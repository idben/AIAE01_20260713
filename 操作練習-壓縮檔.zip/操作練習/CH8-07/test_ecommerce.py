import subprocess
import sys

from collections import Counter, deque
from pathlib import Path

from main_ecommerce import count_order_skus

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_count_order_skus() -> bool:
    print("---------------------------------")
    orders: list[dict[str, object]] = [
        {
            "order_id": "訂單-1001",
            "items": [
                {"sku": "書籍-1", "quantity": 2},
                {"sku": "背包-2", "quantity": 1},
            ],
        },
        {
            "order_id": "訂單-1002",
            "items": [
                {"sku": "書籍-1", "quantity": 3},
                {"sku": "筆記本-3", "quantity": 4},
            ],
        },
    ]
    original_orders = [
        {
            "order_id": order["order_id"],
            "items": [item.copy() for item in order["items"]],
        }
        for order in orders
    ]
    actual = count_order_skus(orders)
    actual_counts = actual.get("counts") if isinstance(actual, dict) else None
    actual_queue = actual.get("queue") if isinstance(actual, dict) else None
    expected_counts = Counter({"書籍-1": 5, "背包-2": 1, "筆記本-3": 4})
    expected_queue = deque(["訂單-1001", "訂單-1002"])
    print(f"輸入：{orders}")
    print("預期：counts 可查 SKU 總數，queue 保留訂單處理順序，且原清單不變")
    print(
        f"實際：counts {actual_counts}，queue {actual_queue}，"
        f"清單 {orders}"
    )
    if (
        isinstance(actual_counts, Counter)
        and isinstance(actual_queue, deque)
        and actual_counts == expected_counts
        and actual_queue == expected_queue
        and orders == original_orders
    ):
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_count_order_skus()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

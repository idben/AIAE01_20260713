# CH8-07 練習

## 題目

練習使用 `collections` 裡的 `Counter`、`defaultdict` 和 `deque` 整理資料。

- 《勇者鬥惡龍》版：統計怪物掉落道具
- 《寶可夢 GO》版：統計補給站獎勵道具，並依總數分組
- 電子商務版：統計多筆訂單中每個 SKU 的總數量，並建立訂單處理佇列

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：統計單純字串清單。
- 《寶可夢 GO》：統計補給站紀錄，每筆資料有道具名稱與數量，要累計總數，並用 `defaultdict` 依總數分組。
- 電子商務：資料是多筆訂單，每筆訂單底下還有商品明細；要依 SKU 累計數量，並用 `deque` 保留訂單處理順序。

## 操作步驟

1. 先觀察函式收到的是多筆紀錄。
2. 勇者版每個字串代表一次拿到的道具。
3. 寶可夢版每筆資料會有道具名稱與數量，還要依總數分組。
4. 電子商務版要先進入每筆訂單的 `items` 清單，再統計商品數量。
5. 電子商務版還要建立訂單處理佇列，保留訂單順序。

## 題目提示

《勇者鬥惡龍》版：

- `count_monster_drops(drops)` 收到怪物掉落紀錄。
- 回傳值要能查出每種道具掉落幾次。

《寶可夢 GO》版：

- `count_pokestop_rewards(rewards)` 收到補給站獎勵紀錄。
- 每筆資料會有 `item` 與 `quantity`。
- 回傳值要包含 `counts` 和 `groups`。
- `counts` 要能查出每種道具總共取得幾個。
- `groups` 要用 `defaultdict(list)`，把總數為 1 的道具放到 `單個`，總數大於 1 的道具放到 `多個`。

電子商務版：

- `count_order_skus(orders)` 收到多筆訂單。
- 每筆訂單裡有 `items` 清單。
- 每個商品明細會有 `sku` 與 `quantity`。
- 同一個 SKU 可能出現在不同訂單中，要累計數量，不是只算出現筆數。
- 回傳值要包含 `counts` 和 `queue`。
- `counts` 要能查出每個 SKU 的總數量。
- `queue` 要用 `deque` 保存訂單處理順序，內容是每筆訂單的 `order_id`。

## 檢查順序

1. 是否統計每個項目出現次數。
2. 原始清單是否沒有被修改。
3. 回傳值是否能用 key 查數量。
4. 寶可夢版是否累加 `quantity`，而不是只把每筆當作 1。
5. 寶可夢版是否用 `defaultdict` 依總數分組。
6. 電子商務版是否有進入每筆訂單的 `items`。
7. 電子商務版是否累加 `quantity`，而不是只把每筆當作 1。
8. 電子商務版是否用 `deque` 保存訂單處理順序。

## 常見錯誤

- 只回傳不重複項目，沒有數量。
- 修改原始清單。
- 回傳固定字串，導致不能查詢。
- 寶可夢版只算紀錄筆數，沒有加上每筆 `quantity`。
- 寶可夢版只有統計總數，沒有回傳分組資料。
- 電子商務版只看訂單本身，沒有進入 `items` 清單。
- 電子商務版只統計 SKU 出現次數，忘記加上每筆商品的數量。
- 電子商務版只回傳統計結果，沒有回傳訂單佇列。

import subprocess
import sys

from collections import Counter, defaultdict
from pathlib import Path

from main_pokemon_go import count_pokestop_rewards

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_count_pokestop_rewards() -> bool:
    print("---------------------------------")
    rewards: list[dict[str, int | str]] = [
        {"item": "精靈球", "quantity": 3},
        {"item": "傷藥", "quantity": 1},
        {"item": "精靈球", "quantity": 2},
        {"item": "蔓莓果", "quantity": 4},
    ]
    original_rewards = [reward.copy() for reward in rewards]
    actual = count_pokestop_rewards(rewards)
    actual_counts = actual.get("counts") if isinstance(actual, dict) else None
    actual_groups = actual.get("groups") if isinstance(actual, dict) else None
    expected_counts = Counter({"精靈球": 5, "傷藥": 1, "蔓莓果": 4})
    expected_groups = {
        "多個": ["精靈球", "蔓莓果"],
        "單個": ["傷藥"],
    }
    print(f"輸入：{rewards}")
    print("預期：counts 可查總數，groups 依總數分組，且原清單不變")
    print(
        f"實際：counts {actual_counts}，groups {actual_groups}，"
        f"清單 {rewards}"
    )
    if (
        isinstance(actual_counts, Counter)
        and isinstance(actual_groups, defaultdict)
        and actual_counts == expected_counts
        and dict(actual_groups) == expected_groups
        and rewards == original_rewards
    ):
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_count_pokestop_rewards()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

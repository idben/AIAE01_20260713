from collections import Counter, deque


def count_order_skus(
    orders: list[dict[str, object]],
) -> dict[str, Counter[str] | deque[str]]:
    # 請統計每個 SKU 的總數量，並用 deque 保存訂單處理順序
    pass

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import count_monster_drops

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_count_monster_drops() -> bool:
    print("---------------------------------")
    drops = ["藥草", "金幣", "藥草", "鐵劍", "金幣", "藥草"]
    original_drops = drops.copy()
    actual = count_monster_drops(drops)
    print(f"輸入：{drops}")
    print("預期：藥草 3，金幣 2，鐵劍 1，且原清單不變")
    print(f"實際：藥草 {actual['藥草']}，金幣 {actual['金幣']}，鐵劍 {actual['鐵劍']}，清單 {drops}")
    if actual["藥草"] == 3 and actual["金幣"] == 2 and actual["鐵劍"] == 1 and drops == original_drops:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_count_monster_drops()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

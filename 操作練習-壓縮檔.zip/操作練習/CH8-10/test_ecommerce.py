import contextlib
import importlib
import io
import json
import subprocess
import sys
import tempfile

from datetime import datetime
from pathlib import Path

from main_ecommerce import (
    build_order_record,
    get_order_record_path,
    save_order_record,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_build_order_record() -> bool:
    print("---------------------------------")
    record_time = datetime(2026, 6, 9, 10, 30)
    expected = {
        "event": "訂單結帳",
        "order_id": "訂單-1001",
        "customer_id": "顧客-9",
        "total": "1280",
        "recorded_at": "2026-06-09 10:30",
    }
    actual = build_order_record("訂單-1001", "顧客-9", 1280, record_time)
    print("輸入：訂單-1001, 顧客-9, 1280, 2026-06-09 10:30")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_get_order_record_path() -> bool:
    print("---------------------------------")
    base_folder = Path("records")
    actual = get_order_record_path(base_folder, "訂單-1001")
    expected = base_folder / "orders" / "訂單-1001" / "紀錄.json"
    print("輸入：records, 訂單-1001")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_order_record() -> bool:
    print("---------------------------------")
    record = {
        "event": "訂單結帳",
        "order_id": "訂單-1001",
        "customer_id": "顧客-9",
        "total": "1280",
        "recorded_at": "2026-06-09 12:00",
    }
    with tempfile.TemporaryDirectory() as temp_dir:
        record_path = Path(temp_dir) / "orders" / "訂單-1001" / "紀錄.json"
        save_order_record(record_path, record)
        actual = json.loads(record_path.read_text(encoding="utf-8"))
    print("輸入：訂單-1001 訂單紀錄")
    print(f"預期：{record}")
    print(f"實際：{actual}")
    if actual == record:
        print("通過")
        return True
    print("失敗")
    return False


def test_main_import() -> bool:
    print("---------------------------------")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        module = importlib.import_module("main_ecommerce")
    actual_output = output.getvalue()
    actual_demo = module.run_demo()
    expected_demo = {
        "event": "訂單結帳",
        "order_id": "訂單-1001",
        "customer_id": "顧客-9",
        "total": "1280",
        "recorded_at": "2026-06-09 10:30",
    }
    print("輸入：匯入 main_ecommerce 並呼叫 run_demo()")
    print(f"預期：匯入無輸出，run_demo() 回傳 {expected_demo}")
    print(f"實際：匯入輸出 {actual_output!r}，run_demo() 回傳 {actual_demo}")
    if actual_output == "" and actual_demo == expected_demo:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_build_order_record(),
        test_get_order_record_path(),
        test_save_order_record(),
        test_main_import(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

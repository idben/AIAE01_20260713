# CH8-10 練習

## 題目

完成一個標準函式庫綜合練習，使用 `datetime`、`pathlib` 與 `json` 建立並保存事件紀錄。

- 《勇者鬥惡龍》版：保存怪物遭遇與掉落紀錄
- 《寶可夢 GO》版：保存捕捉與補給站獎勵紀錄
- 電子商務版：保存訂單結帳紀錄，並保留可測試的主流程

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：建立戰鬥紀錄、組合路徑、寫入 JSON。
- 《寶可夢 GO》：建立含訓練家編號的捕捉紀錄、依訓練家組合路徑、寫入 JSON。
- 電子商務：除了紀錄、路徑與寫檔，還要保留 `run_demo()`、`main()` 與 main block，整合 CH7 的主流程測試習慣。

## 操作步驟

1. 先完成建立紀錄的函式，讓它只回傳字典。
2. 確認時間使用 `%Y-%m-%d %H:%M` 轉成字串。
3. 完成路徑函式，讓它只回傳 `Path`。
4. 完成寫檔函式，必要時先建立父資料夾。
5. 用測試檔確認 JSON 內容可以讀回來。

## 題目提示

《勇者鬥惡龍》版：

- `build_battle_record(monster_name, dropped_item, record_time)` 不寫檔，只回傳字典。
- 紀錄要包含 `event`、`monster`、`dropped_item`、`recorded_at`。
- `event` 的值固定是 `怪物遭遇`。
- `get_battle_record_path(base_folder, file_name)` 只組合戰鬥紀錄檔路徑，資料夾名稱要使用 `battle_records`。
- `save_battle_record(record_path, record)` 改的是目標檔案，不是 `record` 字典；寫入前要建立父資料夾。

《寶可夢 GO》版：

- `build_catch_record(trainer_id, pokemon_name, reward_item, record_time)` 不寫檔，只回傳字典。
- 紀錄要包含 `event`、`trainer_id`、`pokemon`、`reward_item`、`recorded_at`。
- `event` 的值固定是 `野外出現`。
- `pokemon_name` 要放進 `pokemon`，`reward_item` 要放進 `reward_item`。
- `get_catch_record_path(base_folder, trainer_id, file_name)` 只組合捕捉紀錄檔路徑，資料夾名稱要使用 `trainers / trainer_id / catch_records`。
- `save_catch_record(record_path, record)` 改的是目標檔案，不是 `record` 字典；寫入前要建立父資料夾。

電子商務版：

- `build_order_record(order_id, customer_id, total, record_time)` 不寫檔，只回傳字典。
- 紀錄要包含 `event`、`order_id`、`customer_id`、`total`、`recorded_at`。
- `event` 的值固定是 `訂單結帳`。
- `total` 要轉成字串，讓整份紀錄的值都保持字串。
- `get_order_record_path(base_folder, order_id)` 只組合訂單紀錄檔路徑，路徑要使用 `orders / order_id / 紀錄.json`。
- `save_order_record(record_path, record)` 改的是目標檔案，不是 `record` 字典；寫入前要建立父資料夾。
- `run_demo()` 要回傳 `build_order_record("訂單-1001", "顧客-9", 1280, datetime(2026, 6, 9, 10, 30))` 的結果。
- 匯入 `main_ecommerce.py` 時不能自動輸出，只有直接執行檔案時才呼叫 `main()`。

## 檢查順序

1. key 名稱是否和測試檔一致。
2. 時間是否已經轉成字串。
3. 路徑函式是否沒有寫檔。
4. 寫檔前是否建立父資料夾。
5. JSON 是否使用 `ensure_ascii=False`，讓中文在原始檔案中保持可讀。
6. 電子商務版匯入主檔案時是否沒有自動輸出。

## 常見錯誤

- 把 `datetime` 物件直接放進 JSON，導致寫檔失敗。
- 路徑函式順便建立檔案，讓職責混在一起。
- 忘記建立父資料夾，寫檔時找不到資料夾。
- key 寫成 `item`，但測試檔期待 `dropped_item` 或 `reward_item`。
- 函式只 `print()` 沒有 `return`。
- 電子商務版忘記 main block，導致測試匯入主檔案時自動印出內容。

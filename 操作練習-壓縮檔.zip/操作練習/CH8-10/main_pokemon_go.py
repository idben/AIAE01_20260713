import json
from datetime import datetime
from pathlib import Path


def build_catch_record(
    trainer_id: str,
    pokemon_name: str,
    reward_item: str,
    record_time: datetime,
) -> dict[str, str]:
    # 請回傳含 trainer_id 的捕捉紀錄字典，不要在這裡寫檔
    pass


def get_catch_record_path(base_folder: Path, trainer_id: str, file_name: str) -> Path:
    # 請只組合指定訓練家的紀錄路徑，不要在這裡建立或寫入檔案
    pass


def save_catch_record(record_path: Path, record: dict[str, str]) -> None:
    # 請建立父資料夾，並把 record 寫成 JSON
    pass


def run_demo() -> dict[str, str]:
    record_time = datetime(2026, 6, 9, 10, 30)
    return build_catch_record("trainer-7", "皮卡丘", "精靈球", record_time)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

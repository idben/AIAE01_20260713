import json
import subprocess
import sys
import tempfile

from datetime import datetime
from pathlib import Path

from main_dragon_quest import (
    build_battle_record,
    get_battle_record_path,
    save_battle_record,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_build_battle_record() -> bool:
    print("---------------------------------")
    record_time = datetime(2026, 6, 9, 10, 30)
    expected = {
        "event": "怪物遭遇",
        "monster": "史萊姆",
        "dropped_item": "藥草",
        "recorded_at": "2026-06-09 10:30",
    }
    actual = build_battle_record("史萊姆", "藥草", record_time)
    print("輸入：史萊姆, 藥草, 2026-06-09 10:30")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_get_battle_record_path() -> bool:
    print("---------------------------------")
    base_folder = Path("records")
    actual = get_battle_record_path(base_folder, "戰鬥.json")
    expected = base_folder / "battle_records" / "戰鬥.json"
    print("輸入：records, 戰鬥.json")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_battle_record() -> bool:
    print("---------------------------------")
    record = {
        "event": "怪物遭遇",
        "monster": "龍",
        "dropped_item": "鐵劍",
        "recorded_at": "2026-06-09 12:00",
    }
    with tempfile.TemporaryDirectory() as temp_dir:
        record_path = Path(temp_dir) / "battle_records" / "龍.json"
        save_battle_record(record_path, record)
        raw_text = record_path.read_text(encoding="utf-8")
        actual = json.loads(raw_text)
    print("輸入：龍的戰鬥紀錄")
    print(f"預期：{record}，且原始 JSON 保留中文")
    print(f"實際：{actual}，原始文字 {raw_text!r}")
    if actual == record and "龍" in raw_text and "鐵劍" in raw_text:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_build_battle_record(),
        test_get_battle_record_path(),
        test_save_battle_record(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

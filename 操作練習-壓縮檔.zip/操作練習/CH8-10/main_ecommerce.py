import json
from datetime import datetime
from pathlib import Path


def build_order_record(
    order_id: str,
    customer_id: str,
    total: int,
    record_time: datetime,
) -> dict[str, str]:
    # 請建立訂單紀錄字典，不要在這裡寫檔
    pass


def get_order_record_path(base_folder: Path, order_id: str) -> Path:
    # 請只組合訂單紀錄路徑，不要在這裡建立或寫入檔案
    pass


def save_order_record(record_path: Path, record: dict[str, str]) -> None:
    # 請建立父資料夾，並把 record 寫成 JSON
    pass


def run_demo() -> dict[str, str]:
    record_time = datetime(2026, 6, 9, 10, 30)
    return build_order_record("訂單-1001", "顧客-9", 1280, record_time)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

import json
import subprocess
import sys
import tempfile

from datetime import datetime
from pathlib import Path

from main_pokemon_go import (
    build_catch_record,
    get_catch_record_path,
    save_catch_record,
)


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_build_catch_record() -> bool:
    print("---------------------------------")
    record_time = datetime(2026, 6, 9, 10, 30)
    expected = {
        "event": "野外出現",
        "trainer_id": "trainer-7",
        "pokemon": "皮卡丘",
        "reward_item": "精靈球",
        "recorded_at": "2026-06-09 10:30",
    }
    actual = build_catch_record("trainer-7", "皮卡丘", "精靈球", record_time)
    print("輸入：trainer-7, 皮卡丘, 精靈球, 2026-06-09 10:30")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_get_catch_record_path() -> bool:
    print("---------------------------------")
    base_folder = Path("records")
    actual = get_catch_record_path(base_folder, "trainer-7", "捕捉.json")
    expected = base_folder / "trainers" / "trainer-7" / "catch_records" / "捕捉.json"
    print("輸入：records, trainer-7, 捕捉.json")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_save_catch_record() -> bool:
    print("---------------------------------")
    record = {
        "event": "野外出現",
        "trainer_id": "trainer-8",
        "pokemon": "伊布",
        "reward_item": "蔓莓果",
        "recorded_at": "2026-06-09 12:00",
    }
    with tempfile.TemporaryDirectory() as temp_dir:
        record_path = Path(temp_dir) / "trainers" / "trainer-8" / "catch_records" / "伊布.json"
        save_catch_record(record_path, record)
        actual = json.loads(record_path.read_text(encoding="utf-8"))
    print("輸入：伊布 的捕捉紀錄")
    print(f"預期：{record}")
    print(f"實際：{actual}")
    if actual == record:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_build_catch_record(),
        test_get_catch_record_path(),
        test_save_catch_record(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

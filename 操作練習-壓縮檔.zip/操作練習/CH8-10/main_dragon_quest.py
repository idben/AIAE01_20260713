import json
from datetime import datetime
from pathlib import Path


def build_battle_record(
    monster_name: str,
    dropped_item: str,
    record_time: datetime,
) -> dict[str, str]:
    # 請回傳怪物遭遇紀錄字典，不要在這裡寫檔
    pass


def get_battle_record_path(base_folder: Path, file_name: str) -> Path:
    # 請只組合路徑，不要在這裡建立或寫入檔案
    pass


def save_battle_record(record_path: Path, record: dict[str, str]) -> None:
    # 請建立父資料夾，並把 record 寫成 JSON
    pass


def run_demo() -> dict[str, str]:
    record_time = datetime(2026, 6, 9, 10, 30)
    return build_battle_record("史萊姆", "藥草", record_time)


def main() -> None:
    print(run_demo())


if __name__ == "__main__":
    main()

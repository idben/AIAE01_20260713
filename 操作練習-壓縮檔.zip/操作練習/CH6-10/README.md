# CH6-10 練習

## 題目

完成兩種相反方向的回合規則。

- 《勇者鬥惡龍》版：`HighCardRound` 高牌獲勝，`LowCardRound` 低牌獲勝
- 《寶可夢 GO》版：`HighRaidPowerRound` 高戰力獲勝，`LowRaidPowerRound` 低戰力獲勝
- 電子商務版：除錯 `BestDealRound` 和 `BudgetDealRound` 的挑選方向

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 打開對應的 `main_*.py`。
2. 勇者鬥惡龍版與寶可夢 GO 版：在兩個回合類別中保存要比較的兩個物件。
3. 電子商務版：先閱讀已寫好的兩個回合類別，找出判斷方向錯在哪裡。
4. 完成或修正 `resolve_round()`。
5. 存檔後執行對應測試。

## 題目提示

回傳值格式固定：

- `1` 表示第一個物件贏
- `2` 表示第二個物件贏
- `0` 表示平手

測試會檢查 `resolve_round()` 的回傳值，不會只看你印出的文字。

### 《勇者鬥惡龍》版

這版可以直接照規則做：`HighCardRound` 是高牌回合，較大的牌獲勝；`LowCardRound` 是低牌回合，較小的牌獲勝。兩張牌相同時回傳 `0`。

### 《寶可夢 GO》版

`HighRaidPowerRound` 和 `LowRaidPowerRound` 都會拿到兩隻 `RaidPokemon`。`RaidPokemon` 已經會用 `battle_power = cp + attack_iv * 100` 比較大小。高戰力回合選較大的那隻，低戰力回合選較小的那隻。完全相同時回傳 `0`。

### 電子商務版

這一版是除錯題。`main_ecommerce.py` 裡已經有 `BestDealRound` 和 `BudgetDealRound`，但兩個 `resolve_round()` 的判斷方向不符合規則。

- `BestDealRound` 要選比較划算的方案，可以使用 `ProductDeal` 已經支援的 `>`、`<` 比較
- `BudgetDealRound` 要選特價較低的方案，要直接比較 `sale_price`
- 兩個方案完全相同時回傳 `0`

## 這題常見錯誤

- 修改 `Round` 上方已提供的程式
- 高牌與低牌的比較方向寫反

## 這題在測什麼

- 子類別覆寫共同介面
- 多型方法 `resolve_round()`

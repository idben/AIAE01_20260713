import subprocess
import sys
from pathlib import Path

from main_ecommerce import BestDealRound, BudgetDealRound, ProductDeal

TestCase = tuple[ProductDeal, ProductDeal, int, int]

test_cases: list[TestCase] = [
    (ProductDeal("耳機", 3000, 2100), ProductDeal("鍵盤", 2800, 2300), 1, 1),
    (ProductDeal("水壺", 1200, 900), ProductDeal("背包", 1500, 1200), 1, 1),
    (ProductDeal("電視", 10000, 8500), ProductDeal("充電線", 600, 400), 1, 2),
    (ProductDeal("滑鼠", 1000, 700), ProductDeal("滑鼠", 1000, 700), 0, 0),
    (ProductDeal("外套", 3600, 3200), ProductDeal("鞋子", 2500, 1800), 2, 2),
]


def label(deal1: ProductDeal, deal2: ProductDeal, result: int) -> ProductDeal | str:
    if result == 1:
        return deal1
    if result == 2:
        return deal2
    return "平手"


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    deal1: ProductDeal, deal2: ProductDeal, expected_best: int, expected_budget: int
) -> bool:
    print("---------------------------------")
    print(f"輸入：{deal1} vs {deal2}")
    best_result = BestDealRound(deal1, deal2).resolve_round()
    budget_result = BudgetDealRound(deal1, deal2).resolve_round()
    print(f"預期更划算方案：{label(deal1, deal2, expected_best)}")
    print(f"實際更划算方案：{label(deal1, deal2, best_result)}")
    print(f"預期低特價方案：{label(deal1, deal2, expected_budget)}")
    print(f"實際低特價方案：{label(deal1, deal2, budget_result)}")
    if best_result == expected_best and budget_result == expected_budget:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Card, HighCardRound, LowCardRound

TestCase = tuple[Card, Card, int, int]

test_cases: list[TestCase] = [
    (Card("Ace", "Spades"), Card("2", "Clubs"), 1, 2),
    (Card("Queen", "Hearts"), Card("Queen", "Diamonds"), 1, 2),
    (Card("10", "Clubs"), Card("10", "Spades"), 2, 1),
    (Card("2", "Diamonds"), Card("2", "Diamonds"), 0, 0),
]


def label(card1: Card, card2: Card, result: int) -> Card | str:
    if result == 1:
        return card1
    if result == 2:
        return card2
    return "平手"


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(card1: Card, card2: Card, expected_high: int, expected_low: int) -> bool:
    print("---------------------------------")
    print(f"輸入：{card1} vs {card2}")
    high_result = HighCardRound(card1, card2).resolve_round()
    low_result = LowCardRound(card1, card2).resolve_round()
    print(f"預期高牌勝者：{label(card1, card2, expected_high)}")
    print(f"實際高牌勝者：{label(card1, card2, high_result)}")
    print(f"預期低牌勝者：{label(card1, card2, expected_low)}")
    print(f"實際低牌勝者：{label(card1, card2, low_result)}")
    if high_result == expected_high and low_result == expected_low:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()


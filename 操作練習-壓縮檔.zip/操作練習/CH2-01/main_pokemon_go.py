class PokemonSpawn:
    pass


class PokeStop:
    pass

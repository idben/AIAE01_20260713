import subprocess
import sys
from pathlib import Path

from main_pokemon_go import PokeStop, PokemonSpawn

ExpectedAttributes = dict[str, object]
TestCase = tuple[type[object], ExpectedAttributes]

run_cases: list[TestCase] = [
    (PokemonSpawn, {"cp": 321, "remaining_seconds": 180}),
]

submit_cases: list[TestCase] = run_cases + [
    (PokeStop, {"distance_meters": 50, "is_lured": False}),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(class_type: type[object], expected_attributes: ExpectedAttributes) -> bool:
    print("---------------------------------")
    print(f"測試類別：{class_type.__name__}")
    try:
        instance = class_type()
        passed = True
        for attr_name, expected_value in expected_attributes.items():
            if not hasattr(instance, attr_name):
                print(f"錯誤：找不到屬性 {attr_name}")
                passed = False
                continue
            actual_value = getattr(instance, attr_name)
            print(f"預期 {attr_name}：{expected_value}")
            print(f"實際 {attr_name}：{actual_value}")
            if actual_value != expected_value:
                passed = False
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

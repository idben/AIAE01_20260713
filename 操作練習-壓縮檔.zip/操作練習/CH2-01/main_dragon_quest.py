class Monster:
    pass


class Spell:
    pass

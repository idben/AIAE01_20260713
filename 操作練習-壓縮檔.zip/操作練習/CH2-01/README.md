# CH2-01 練習

## 題目

這一課在改寫教材中有兩個版本，所以這個資料夾也拆成兩份練習。

但學習順序請先看《勇者鬥惡龍》版，不要一開始自己猜《寶可夢 GO》版要建立哪些屬性。

先完成這個明確目標：

- 建立 `Monster`
  - 怪物有血量，你可以用 `hp` 當作變數名稱，預設值設成 `15`
  - 怪物會掉落金幣，你可以用 `gold_drop` 當作變數名稱，預設值設成 `7`
- 建立 `Spell`
  - 咒文有魔力消耗，你可以用 `mp_cost` 當作變數名稱，預設值設成 `4`
  - 咒文有威力，你可以用 `power` 當作變數名稱，預設值設成 `12`

完成後，再去做《寶可夢 GO》版。

## 檔案

- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版
- `main_pokemon_go.py`：學生作答，《寶可夢 GO》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO》版

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開 `test_dragon_quest.py` 或 `test_pokemon_go.py`，再按播放鍵執行。

## 學生操作步驟

1. 先打開 `main_dragon_quest.py`
2. 建立 `Monster` 與 `Spell`
3. 先幫 `Monster` 補上血量與掉落金幣，再幫 `Spell` 補上魔力消耗與威力

4. 存檔後，先執行：

```bash
python3 test_dragon_quest.py
```

5. 《勇者鬥惡龍》版通過後，再打開 `main_pokemon_go.py`
6. 再補《寶可夢 GO》版的目標屬性：
   - `PokemonSpawn` 需要記住 `cp = 321` 和 `remaining_seconds = 180`
   - `PokeStop` 需要記住 `distance_meters = 50` 和 `is_lured = False`

7. 存檔後，在這個資料夾執行對應測試：

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

8. 如果最後看到 `============= 全部通過 ==============`
   代表該版本已通過目前測試

## 題目提示

### 《勇者鬥惡龍》版

- `Monster` 要記住血量與掉落金幣
- 你可以用 `hp = 15` 與 `gold_drop = 7`
- `Spell` 要記住魔力消耗與威力
- 你可以用 `mp_cost = 4` 與 `power = 12`

### 《寶可夢 GO》版

- `PokemonSpawn` 要記住戰力與剩餘出現秒數
- 你可以用 `cp = 321` 與 `remaining_seconds = 180`
- `PokeStop` 要記住距離與是否有灑花效果
- 你可以用 `distance_meters = 50` 與 `is_lured = False`

## 這題常見錯誤

- 忘了建立其中一個類別
- 屬性名稱拼錯
- 屬性值和題目要求不同

## 這題在測什麼

- 類別是否存在
- 屬性是否存在
- 預設值是否正確

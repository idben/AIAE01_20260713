from functools import wraps


def log_buddy_action(original_function):
    # 請使用 @wraps(original_function)，並回傳 wrapper
    raise NotImplementedError("請完成 log_buddy_action")


@log_buddy_action
def report_buddy_candy(pokemon_name: str, candy_count: int) -> str:
    """回傳夥伴寶可夢找到糖果的訊息。"""
    return f"{pokemon_name} 找到 {candy_count} 顆糖果"


if __name__ == "__main__":
    print(report_buddy_candy.__name__)
    print(report_buddy_candy.__doc__)
    print(report_buddy_candy("伊布", 3))

import subprocess
import sys

from pathlib import Path

from main_pokemon_go import report_buddy_candy

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_wraps_keeps_function_info() -> bool:
    print("---------------------------------")
    actual = (report_buddy_candy.__name__, report_buddy_candy.__doc__)
    expected = ("report_buddy_candy", "回傳夥伴寶可夢找到糖果的訊息。")
    print("輸入：讀取 report_buddy_candy 的函式資訊")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_report_buddy_candy_result() -> bool:
    print("---------------------------------")
    actual = report_buddy_candy("伊布", 3)
    expected = "伊布 找到 3 顆糖果"
    print("輸入：伊布, 3")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_wraps_keeps_function_info(), test_report_buddy_candy_result()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

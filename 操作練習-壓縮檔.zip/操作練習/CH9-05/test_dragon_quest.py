import subprocess
import sys

from pathlib import Path

from main_dragon_quest import identify_spell_scroll

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_wraps_keeps_function_info() -> bool:
    print("---------------------------------")
    actual = (identify_spell_scroll.__name__, identify_spell_scroll.__doc__)
    expected = ("identify_spell_scroll", "回傳角色辨識咒文卷軸的訊息。")
    print("輸入：讀取 identify_spell_scroll 的函式資訊")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_identify_spell_scroll_result() -> bool:
    print("---------------------------------")
    actual = identify_spell_scroll("勇者", "貝基拉瑪卷軸")
    expected = "勇者 辨識出 貝基拉瑪卷軸 的咒文效果"
    print("輸入：勇者, 貝基拉瑪卷軸")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_wraps_keeps_function_info(), test_identify_spell_scroll_result()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

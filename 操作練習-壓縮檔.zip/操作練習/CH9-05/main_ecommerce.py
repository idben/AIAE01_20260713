from functools import wraps


def log_payment_action(original_function):
    # 請使用 @wraps(original_function)，並回傳 wrapper
    raise NotImplementedError("請完成 log_payment_action")


@log_payment_action
def confirm_payment(order: dict[str, object]) -> str:
    """回傳訂單付款完成訊息。"""
    return f"訂單 {order['order_id']} 已付款 {order['amount']} 元"


if __name__ == "__main__":
    print(confirm_payment.__name__)
    print(confirm_payment.__doc__)
    print(confirm_payment({"order_id": "A1001", "amount": 2400}))

# CH9-05 練習

## 你要完成的事

使用 `functools.wraps` 保留原函式名稱與文件字串。

建議完成順序：

- 《勇者鬥惡龍》：保留咒文卷軸辨識函式資訊，和課文回復咒文範例錯開。
- 《寶可夢 GO》：保留夥伴糖果報告函式資訊，從補給站改成夥伴系統。
- 電子商務：保留付款確認函式資訊，並檢查 `wraps` 建立的原函式連結。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

1. 先完成裝飾器，並在 `wrapper` 上方使用 `@wraps(original_function)`。
2. 再觀察被裝飾後的函式名稱。
3. 接著觀察文件字串。
4. 最後呼叫函式，確認核心回傳值沒有被改掉。

`__name__` 是函式名稱；`__doc__` 是函式裡第一段三引號文字。它們是函式物件上的資訊，不是函式被呼叫後的回傳值。

使用 `wraps` 後，包裝後的函式會有 `__wrapped__`，它會指回被包住前的原函式。讀 `__wrapped__.__name__` 是在確認這條連結是否仍然指向原函式名稱。

## 題目提示

### 《勇者鬥惡龍》版

先觀察 `identify_spell_scroll` 的名稱、文件字串與回傳值。`wraps` 只保留函式資訊，不負責改卷軸辨識結果。

### 《寶可夢 GO》版

先觀察 `report_buddy_candy` 的名稱、文件字串與回傳值。夥伴糖果訊息是原函式的核心結果。

### 電子商務版

先觀察 `confirm_payment` 的名稱、文件字串、`__wrapped__` 與回傳值。這一版會從訂單字典讀資料，除錯時不只要看得出函式名稱，也要確認 `wraps` 保留了原函式連結。

`confirm_payment.__wrapped__` 不是付款結果，而是原函式連結。

## 檢查順序

1. 是否有從 `functools` 匯入 `wraps`。
2. `@wraps(original_function)` 是否寫在 `wrapper` 上方。
3. `__name__` 是否保留原函式名稱。
4. `__doc__` 是否保留原函式說明。
5. 電子商務版的 `__wrapped__.__name__` 是否也能指回原函式名稱。
6. 回傳值是否仍然保留。

## 常見卡住點

- 忘記從 `functools` 匯入 `wraps`。
- 把 `@wraps` 寫在外層裝飾器上，而不是 `wrapper` 上。

## 做完你會練到

- `functools.wraps`。
- 裝飾器與函式資訊保留。
- `__wrapped__` 與原函式連結。

import subprocess
import sys

from pathlib import Path

from main_ecommerce import confirm_payment

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_wraps_keeps_function_info() -> bool:
    print("---------------------------------")
    actual = (
        confirm_payment.__name__,
        confirm_payment.__doc__,
        confirm_payment.__wrapped__.__name__,
    )
    expected = ("confirm_payment", "回傳訂單付款完成訊息。", "confirm_payment")
    print("輸入：讀取 confirm_payment 的函式資訊")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_confirm_payment_result() -> bool:
    print("---------------------------------")
    order = {"order_id": "A1001", "amount": 2400}
    actual = confirm_payment(order)
    expected = "訂單 A1001 已付款 2400 元"
    print("輸入：order_id=A1001, amount=2400 的訂單字典")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_wraps_keeps_function_info(), test_confirm_payment_result()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

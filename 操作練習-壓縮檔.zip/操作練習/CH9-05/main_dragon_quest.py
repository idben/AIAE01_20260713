from functools import wraps


def log_scroll_action(original_function):
    # 請使用 @wraps(original_function)，並回傳 wrapper
    raise NotImplementedError("請完成 log_scroll_action")


@log_scroll_action
def identify_spell_scroll(hero_name: str, scroll_name: str) -> str:
    """回傳角色辨識咒文卷軸的訊息。"""
    return f"{hero_name} 辨識出 {scroll_name} 的咒文效果"


if __name__ == "__main__":
    print(identify_spell_scroll.__name__)
    print(identify_spell_scroll.__doc__)
    print(identify_spell_scroll("勇者", "貝基拉瑪卷軸"))

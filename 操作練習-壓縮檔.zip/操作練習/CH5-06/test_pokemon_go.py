import subprocess
import sys
from pathlib import Path

from main_pokemon_go import LureBeacon, MapEntity

TestCase = tuple[list[MapEntity], LureBeacon, int, int, list[str]]

run_cases: list[TestCase] = [
    ([MapEntity("Pikachu", 3, 3), MapEntity("PokeStop A", -1, 4), MapEntity("Gym B", -6, 5)], LureBeacon("Lure A", 2, 2, 3), 2, 3, ["Pikachu", "PokeStop A"]),
]

submit_cases: list[TestCase] = run_cases + [
    ([MapEntity("Eevee", 2, 1), MapEntity("Bulbasaur", 1, 0), MapEntity("Charmander", 2, 0), MapEntity("Snorlax", 10, 10)], LureBeacon("Lure B", 1, 1, 1), 1, 1, ["Eevee", "Bulbasaur", "Charmander"]),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(entities: list[MapEntity], beacon: LureBeacon, x_target: int, y_target: int, expected_names: list[str]) -> bool:
    print("---------------------------------")
    scanned = beacon.scan_nearby(x_target, y_target, entities)
    actual_names = [entity.name for entity in scanned]
    print(f"預期：{expected_names}")
    print(f"實際：{actual_names}")
    return set(actual_names) == set(expected_names)


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

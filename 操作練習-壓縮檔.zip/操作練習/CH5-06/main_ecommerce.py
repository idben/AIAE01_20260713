class WarehouseItem:
    def __init__(self, name: str, pos_x: int, pos_y: int) -> None:
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y

    def in_area(self, x_1: int, y_1: int, x_2: int, y_2: int) -> bool:
        return (
            self.pos_x >= x_1
            and self.pos_x <= x_2
            and self.pos_y >= y_1
            and self.pos_y <= y_2
        )


class PackingZone(WarehouseItem):
    def __init__(self, name: str, pos_x: int, pos_y: int, zone_range: int) -> None:
        super().__init__(name, pos_x, pos_y)
        self.__zone_range = zone_range

    def collect_items(self, x: int, y: int, items: list[WarehouseItem]) -> list[WarehouseItem]:
        collected: list[WarehouseItem] = []
        for item in items:
            if self.in_area(
                x - self.__zone_range,
                y - self.__zone_range,
                x + self.__zone_range,
                y + self.__zone_range,
            ):
                collected.append(item)
        return collected

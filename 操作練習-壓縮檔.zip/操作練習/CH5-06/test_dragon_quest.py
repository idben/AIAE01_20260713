import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Dragon, Unit

TestCase = tuple[list[Unit], Dragon, int, int, list[str]]

run_cases: list[TestCase] = [
    ([Unit("史萊姆", 3, 3), Unit("德魯伊", -1, 4), Unit("食人箱", -6, 5)], Dragon("巴哈拉塔龍", 2, 2, 3), 2, 3, ["史萊姆", "德魯伊"]),
]

submit_cases: list[TestCase] = run_cases + [
    ([Unit("奇美拉", 2, 1), Unit("蝙蝠", 1, 0), Unit("史萊姆騎士", 2, 0), Unit("巨龍", 10, 10)], Dragon("紅龍", 1, 1, 1), 1, 1, ["奇美拉", "蝙蝠", "史萊姆騎士"]),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(units: list[Unit], dragon: Dragon, x_target: int, y_target: int, expected_names: list[str]) -> bool:
    print("---------------------------------")
    hit_units = dragon.breathe_fire(x_target, y_target, units)
    actual_names = [unit.name for unit in hit_units]
    print(f"預期：{expected_names}")
    print(f"實際：{actual_names}")
    return set(actual_names) == set(expected_names)


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

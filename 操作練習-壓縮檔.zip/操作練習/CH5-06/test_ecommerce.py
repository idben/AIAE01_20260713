import subprocess
import sys
from pathlib import Path

from main_ecommerce import PackingZone, WarehouseItem

TestCase = tuple[list[WarehouseItem], PackingZone, int, int, list[str]]

run_cases: list[TestCase] = [
    ([WarehouseItem("外套", 3, 3), WarehouseItem("雨鞋", -1, 4), WarehouseItem("帽子", -6, 5)], PackingZone("A 區", 2, 2, 3), 2, 3, ["外套", "雨鞋"]),
]

submit_cases: list[TestCase] = run_cases + [
    ([WarehouseItem("圍巾", 2, 1), WarehouseItem("手套", 1, 0), WarehouseItem("毛衣", 2, 0), WarehouseItem("外箱", 10, 10)], PackingZone("B 區", 1, 1, 1), 1, 1, ["圍巾", "手套", "毛衣"]),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(items: list[WarehouseItem], zone: PackingZone, x_target: int, y_target: int, expected_names: list[str]) -> bool:
    print("---------------------------------")
    collected = zone.collect_items(x_target, y_target, items)
    actual_names = [item.name for item in collected]
    print(f"預期：{expected_names}")
    print(f"實際：{actual_names}")
    return set(actual_names) == set(expected_names)


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

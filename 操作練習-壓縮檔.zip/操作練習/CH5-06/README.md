# CH5-06 練習

## 題目

這一課練習範圍判斷與繼承。

- 《勇者鬥惡龍》版：完整完成 `Unit.in_area()` 和 `Dragon.breathe_fire()`
- 《寶可夢 GO》版：補完 `LureBeacon.scan_nearby()`，把已經寫好的範圍判斷接成清單過濾
- 《電子商務》版：檢查並修正 `PackingZone.collect_items()` 的範圍邏輯錯誤

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 《勇者鬥惡龍》先從零完成 `in_area()` 和 `breathe_fire()`，把矩形判斷和命中清單都寫出來。
2. 《寶可夢 GO》先讀懂 `MapEntity`（地圖對象）已經提供的 `in_area()`，再補上 `LureBeacon.scan_nearby()`。
3. 《電子商務》先不要急著重寫，先檢查 `PackingZone.collect_items()` 現在到底是拿誰去做範圍判斷。
4. 三個版本都要注意：迴圈裡真正該檢查的是列表中的每個物件，不是子類別自己。
5. 執行測試確認最後回傳的是新的結果列表。

## 常見錯誤

- `in_area()` 的參數順序寫錯
- 誤用 `self.in_area(...)`
- 沒有把命中的物件收集到新列表
- 看到除錯題就整份重寫，反而沒先找出真正的錯誤點

## 這題在測什麼

- 父類別共通邏輯
- 子類別重用父類別方法
- 清單過濾
- 同一個核心觀念在完整實作、補完題、除錯題中的不同用法

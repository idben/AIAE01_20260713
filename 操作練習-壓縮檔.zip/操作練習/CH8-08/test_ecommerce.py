import subprocess
import sys

from pathlib import Path

from main_ecommerce import build_cumulative_shipments

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_cumulative_shipments_basic() -> bool:
    print("---------------------------------")
    daily_counts = [3, 5, 2]
    actual = build_cumulative_shipments(daily_counts)
    expected = [3, 8, 10]
    print(f"輸入：{daily_counts}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_cumulative_shipments_with_zero() -> bool:
    print("---------------------------------")
    daily_counts = [10, 0, 4, 6]
    actual = build_cumulative_shipments(daily_counts)
    expected = [10, 10, 14, 20]
    print(f"輸入：{daily_counts}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_cumulative_shipments_empty() -> bool:
    print("---------------------------------")
    daily_counts = []
    actual = build_cumulative_shipments(daily_counts)
    expected = []
    print(f"輸入：{daily_counts}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_cumulative_shipments_basic(),
        test_cumulative_shipments_with_zero(),
        test_cumulative_shipments_empty(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

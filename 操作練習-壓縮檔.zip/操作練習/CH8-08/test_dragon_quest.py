import subprocess
import sys

from pathlib import Path

from main_dragon_quest import build_spell_target_pairs

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_spell_target_pairs() -> bool:
    print("---------------------------------")
    spells = ["美拉", "荷伊米"]
    targets = ["史萊姆", "龍", "魔王使者"]
    expected = [
        ("美拉", "史萊姆"),
        ("美拉", "龍"),
        ("美拉", "魔王使者"),
        ("荷伊米", "史萊姆"),
        ("荷伊米", "龍"),
        ("荷伊米", "魔王使者"),
    ]
    actual = build_spell_target_pairs(spells, targets)
    print(f"輸入：{spells}, {targets}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_spell_target_pairs()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

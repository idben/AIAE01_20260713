import itertools


def build_raid_partner_pairs(
    pokemon_names: list[str],
) -> list[tuple[str, str]]:
    # 請產生不重複的兩兩團體戰搭檔組合
    pass

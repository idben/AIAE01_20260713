import subprocess
import sys

from pathlib import Path

from main_pokemon_go import build_raid_partner_pairs

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_raid_partner_pairs_three_pokemon() -> bool:
    print("---------------------------------")
    pokemon_names = ["皮卡丘", "卡比獸", "路卡利歐"]
    expected = [
        ("皮卡丘", "卡比獸"),
        ("皮卡丘", "路卡利歐"),
        ("卡比獸", "路卡利歐"),
    ]
    actual = build_raid_partner_pairs(pokemon_names)
    print(f"輸入：{pokemon_names}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_raid_partner_pairs_four_pokemon() -> bool:
    print("---------------------------------")
    pokemon_names = ["妙蛙花", "噴火龍", "水箭龜", "快龍"]
    expected = [
        ("妙蛙花", "噴火龍"),
        ("妙蛙花", "水箭龜"),
        ("妙蛙花", "快龍"),
        ("噴火龍", "水箭龜"),
        ("噴火龍", "快龍"),
        ("水箭龜", "快龍"),
    ]
    actual = build_raid_partner_pairs(pokemon_names)
    print(f"輸入：{pokemon_names}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_raid_partner_pairs_not_enough_pokemon() -> bool:
    print("---------------------------------")
    pokemon_names = ["伊布"]
    expected = []
    actual = build_raid_partner_pairs(pokemon_names)
    print(f"輸入：{pokemon_names}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_raid_partner_pairs_three_pokemon(),
        test_raid_partner_pairs_four_pokemon(),
        test_raid_partner_pairs_not_enough_pokemon(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

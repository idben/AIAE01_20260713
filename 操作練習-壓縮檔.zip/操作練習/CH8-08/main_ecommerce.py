import itertools


def build_cumulative_shipments(daily_counts: list[int]) -> list[int]:
    # 請使用 itertools.accumulate() 產生每日累計出貨量清單
    pass

import itertools


def build_spell_target_pairs(spells: list[str], targets: list[str]) -> list[tuple[str, str]]:
    # 請產生所有咒文與目標的配對清單
    pass

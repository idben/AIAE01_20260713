import json
from pathlib import Path


def build_water_alerts(
    file_path: Path,
    threshold: float,
) -> str:
    # 請讀取 data.json，找出 capacity 低於門檻的資料，整理成水情提醒 JSON 字串
    pass

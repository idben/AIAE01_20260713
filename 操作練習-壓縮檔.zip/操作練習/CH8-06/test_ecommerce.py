import json
import subprocess
import sys

from pathlib import Path

from main_ecommerce import build_water_alerts


def parse_json_text(text: object) -> object:
    if not isinstance(text, str):
        return None

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_build_water_alerts_under_5() -> bool:
    print("---------------------------------")
    data_path = Path(__file__).resolve().parent / "data.json"
    actual_text = build_water_alerts(data_path, 5)
    actual_data = parse_json_text(actual_text)
    expected_data = [
        {"name": "烏溝蓄水塘", "capacity": 2.7, "message": "注意蓄水容量"},
        {"name": "珠螺水壩", "capacity": 0.47, "message": "注意蓄水容量"},
        {"name": "津沙一號水庫", "capacity": 1.26, "message": "注意蓄水容量"},
        {"name": "儲水沃上壩", "capacity": 2.29, "message": "注意蓄水容量"},
        {"name": "秋桂山水庫", "capacity": 3.15, "message": "注意蓄水容量"},
        {"name": "儲水沃水庫", "capacity": 4.17, "message": "注意蓄水容量"},
        {"name": "津沙水庫", "capacity": 4.58, "message": "注意蓄水容量"},
    ]
    print("輸入：data.json, 門檻 5")
    print(f"預期：JSON 可讀回 {expected_data}")
    print(f"實際：{actual_text}")
    if isinstance(actual_text, str) and actual_data == expected_data:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_water_alerts_under_2() -> bool:
    print("---------------------------------")
    data_path = Path(__file__).resolve().parent / "data.json"
    actual_text = build_water_alerts(data_path, 2)
    actual_data = parse_json_text(actual_text)
    expected_data = [
        {"name": "珠螺水壩", "capacity": 0.47, "message": "注意蓄水容量"},
        {"name": "津沙一號水庫", "capacity": 1.26, "message": "注意蓄水容量"},
    ]
    print("輸入：data.json, 門檻 2")
    print(f"預期：JSON 可讀回 {expected_data}")
    print(f"實際：{actual_text}")
    if isinstance(actual_text, str) and actual_data == expected_data:
        print("通過")
        return True
    print("失敗")
    return False


def test_build_water_alerts_under_0() -> bool:
    print("---------------------------------")
    data_path = Path(__file__).resolve().parent / "data.json"
    actual_text = build_water_alerts(data_path, 0)
    actual_data = parse_json_text(actual_text)
    expected_data: list[dict[str, str | float]] = []
    print("輸入：data.json, 門檻 0")
    print(f"預期：JSON 可讀回 {expected_data}")
    print(f"實際：{actual_text}")
    if isinstance(actual_text, str) and actual_data == expected_data:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_build_water_alerts_under_5(),
        test_build_water_alerts_under_2(),
        test_build_water_alerts_under_0(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

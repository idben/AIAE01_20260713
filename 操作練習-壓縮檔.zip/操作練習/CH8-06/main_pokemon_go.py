import json
from datetime import datetime


def encode_catch_record(
    name: str,
    cp: int,
    items_used: list[str],
    caught_at: datetime,
) -> str:
    # 請把捕捉紀錄資料轉成 JSON 字串，並把捕捉時間格式化成文字
    pass

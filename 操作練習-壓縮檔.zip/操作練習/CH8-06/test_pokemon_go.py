import json
import subprocess
import sys

from datetime import datetime
from pathlib import Path

from main_pokemon_go import encode_catch_record

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_encode_catch_record() -> bool:
    print("---------------------------------")
    caught_at = datetime(2026, 6, 9, 10, 30)
    actual_text = encode_catch_record("皮卡丘", 420, ["精靈球", "蔓莓果"], caught_at)
    actual_data = json.loads(actual_text)
    expected_data = {
        "name": "皮卡丘",
        "cp": 420,
        "items_used": ["精靈球", "蔓莓果"],
        "caught_at": "2026-06-09 10:30",
        "item_count": 2,
    }
    print("輸入：皮卡丘, 420, [精靈球, 蔓莓果], 2026-06-09 10:30")
    print(f"預期：JSON 可讀回 {expected_data}")
    print(f"實際：{actual_text}")
    if isinstance(actual_text, str) and actual_data == expected_data:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_encode_catch_record()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

import json
import subprocess
import sys

from pathlib import Path

from main_dragon_quest import encode_party_member

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_encode_party_member() -> bool:
    print("---------------------------------")
    actual_text = encode_party_member("勇者", 120, ["荷伊米", "基拉"])
    actual_data = json.loads(actual_text)
    expected_data = {
        "name": "勇者",
        "hp": 120,
        "spells": ["荷伊米", "基拉"],
    }
    print("輸入：勇者, 120, [荷伊米, 基拉]")
    print(f"預期：JSON 可讀回 {expected_data}")
    print(f"實際：{actual_text}")
    if isinstance(actual_text, str) and actual_data == expected_data and "勇者" in actual_text:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_encode_party_member()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

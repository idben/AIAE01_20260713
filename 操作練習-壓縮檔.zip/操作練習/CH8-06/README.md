# CH8-06 練習

## 題目

練習使用 JSON 模組處理字串與檔案資料。

- 《勇者鬥惡龍》版：轉換隊伍成員資料
- 《寶可夢 GO》版：轉換捕捉紀錄資料
- 水情監測版：讀取外部資料檔，產生容量提醒

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`
- `data.json`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：把單一角色資料轉成 JSON。
- 《寶可夢 GO》：把單次捕捉紀錄轉成 JSON，並加入捕捉時間與使用道具數量。
- 水情監測：從 `data.json` 讀取外部資料，篩選容量低於門檻的資料，整理成新的 JSON。

## 操作步驟

1. 先觀察函式收到哪些資料。
2. 依題目需要整理成字典或清單。
3. 需要讀檔的題目，先把 JSON 檔案轉成 Python 資料。
4. 把結果轉成 JSON 字串。
5. 回傳 JSON 字串，不要只印出。

## 題目提示

《勇者鬥惡龍》版：

- `encode_party_member(name, hp, spells)` 要保存名稱、HP 與咒文清單。
- 中文內容應該能正常保留，不要變成難讀的跳脫字元。

《寶可夢 GO》版：

- `encode_catch_record(name, cp, items_used, caught_at)` 要保存名稱、CP、使用道具清單與捕捉時間。
- 捕捉時間要格式化成 `%Y-%m-%d %H:%M` 字串。
- 還要加入 `item_count`，值是使用道具清單的長度。
- 回傳值是 JSON 文字，測試會再讀回來檢查資料。

水情監測版：

- `build_water_alerts(file_path, threshold)` 要讀取 `data.json`。
- `data.json` 裡每一筆資料都有水庫名稱、容量、時間等欄位。
- 找出 `capacity` 低於 `threshold` 的資料。
- `capacity` 在檔案中是字串，和門檻比較前要先轉成數字。
- 如果 `capacity` 是空字串，請跳過那筆資料。
- 每一筆提醒資料要包含 `name`、`capacity`、`message`。
- `message` 固定使用 `注意蓄水容量`。
- 回傳值是 JSON 文字，不要回傳原本清單。

## 檢查順序

1. key 名稱是否和測試檔一致。
2. 清單是否仍是清單，不要轉成一整串文字。
3. 回傳值是否是字串。
4. 寶可夢版是否把 `caught_at` 轉成字串，並正確計算 `item_count`。
5. 水情監測版是否真的讀取 `data.json`。
6. 水情監測版是否把 `capacity` 轉成數字再比較。
7. 水情監測版是否跳過空字串容量。

## 常見錯誤

- 回傳字典，而不是 JSON 字串。
- 忘記保留中文。
- key 名稱拼錯。
- 寶可夢版直接把 `datetime` 放進 JSON，導致無法序列化。
- 水情監測版直接回傳 Python 清單，而不是 JSON 字串。
- 水情監測版用字串比較容量，導致排序或篩選結果錯誤。
- 水情監測版沒有處理空字串容量，導致轉成數字時出錯。

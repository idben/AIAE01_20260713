import json


def encode_party_member(name: str, hp: int, spells: list[str]) -> str:
    # 請把隊伍成員資料轉成 JSON 字串
    pass

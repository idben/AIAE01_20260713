class PokemonSpawn:
    def __init__(self, name: str, cp: int, remaining_seconds: int) -> None:
        pass

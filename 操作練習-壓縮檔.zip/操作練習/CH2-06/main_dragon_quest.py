class PartyMember:
    def __init__(self, name: str, hp: int, mp: int) -> None:
        pass

# CH2-06 練習

## 題目

這一課練習建構子 (Constructor)。

- 《勇者鬥惡龍》版：完成 `PartyMember.__init__()`
- 《寶可夢 GO》版：完成 `PokemonSpawn.__init__()`

## 檔案

- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版
- `main_pokemon_go.py`：學生作答，《寶可夢 GO》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO》版

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成建構子
4. 存檔後，在這個資料夾執行對應測試
5. 如果最後看到 `============= 全部通過 ==============`
   代表該版本已通過目前測試

## 題目提示

### 《勇者鬥惡龍》版

- 建立角色時，要把名字、生命值和 MP 都存進物件
- 你可以用 `self.name`、`self.hp`、`self.mp` 來記
- `__init__(self, name, hp, mp)` 要把三個值存成實例屬性
- 例如 `PartyMember("勇者", 30, 10)` 建好後，這個物件就應該記住自己的名字是 `勇者`、生命值是 `30`、MP 是 `10`

### 《寶可夢 GO》版

- 建立附近出現資料時，要把名稱、CP 和剩餘出現秒數都存進物件
- 你可以用 `self.name`、`self.cp`、`self.remaining_seconds` 來記
- `__init__(self, name, cp, remaining_seconds)` 要把三個值存成實例屬性
- 例如 `PokemonSpawn("Pikachu", 321, 180)` 建好後，這個物件就應該記住自己的名稱是 `Pikachu`、CP 是 `321`、剩餘秒數是 `180`

## 這題常見錯誤

- 忘了使用 `self.`
- 只接收參數，沒有存成屬性
- 屬性名稱和題目要求不一致

## 這題在測什麼

- 建構子是否存在
- 是否能在建立物件時正確初始化資料

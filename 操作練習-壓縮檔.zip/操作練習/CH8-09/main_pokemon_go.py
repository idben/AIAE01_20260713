import json
from pathlib import Path


def build_strong_catch_summary(catch_path: Path, min_cp: int) -> dict[str, object]:
    # 請讀取捕捉紀錄 JSON 檔，整理 CP 達到門檻的寶可夢名稱與來源檔名
    pass

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import build_character_summary

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_character_summary() -> bool:
    print("---------------------------------")
    profile_path = Path(__file__).resolve().parent / "hero_profile.json"
    actual = build_character_summary(profile_path)
    expected: dict[str, object] = {
        "name": "勇者",
        "item_count": 2,
        "gold": 380,
    }
    print("輸入：hero_profile.json 角色資料")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_character_summary()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

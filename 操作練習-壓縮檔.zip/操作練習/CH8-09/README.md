# CH8-09 練習

## 題目

練習把 `json` 與 `pathlib` 操作包成清楚的讀取與整理函式。

- 《勇者鬥惡龍》版：讀取角色資料並整理摘要
- 《寶可夢 GO》版：讀取捕捉紀錄並篩選高 CP 寶可夢
- 電子商務版：讀取訂單批次檔並整理摘要

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`
- `hero_profile.json`
- `daily_catches.json`
- `weak_catches.json`
- `orders.json`
- `empty_orders.json`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：讀取單一角色 JSON 檔，整理角色摘要。
- 《寶可夢 GO》：讀取捕捉紀錄清單，篩選 CP 達到門檻的寶可夢，並補上來源檔名。
- 電子商務：讀取訂單批次 JSON 檔，整理來源檔名、訂單數量、總金額與訂單編號。

## 操作步驟

1. 先觀察函式收到的是哪一個 JSON 檔案路徑。
2. 使用 `read_text()` 讀出 JSON 文字。
3. 使用 `json.loads()` 轉成 Python 資料。
4. 依照題目需求整理成新的字典。
5. 回傳整理後的資料，不要只印出結果。

## 題目提示

《勇者鬥惡龍》版：

- `build_character_summary(profile_path)` 讀取角色 JSON 檔。
- 測試使用 `hero_profile.json`。
- 回傳字典要包含 `name`、`item_count`、`gold`。
- `item_count` 是角色道具清單的數量。

《寶可夢 GO》版：

- `build_strong_catch_summary(catch_path, min_cp)` 讀取捕捉紀錄 JSON 檔。
- 測試使用 `daily_catches.json` 與 `weak_catches.json`。
- JSON 檔最外層是捕捉紀錄清單。
- 只保留 `cp` 大於或等於 `min_cp` 的寶可夢名稱。
- 回傳字典要包含 `source_file`、`min_cp`、`matched_count`、`pokemon_names`。

電子商務版：

- `build_order_batch_summary(batch_path)` 讀取訂單批次 JSON 檔。
- 測試使用 `orders.json` 與 `empty_orders.json`。
- JSON 檔最外層是訂單清單。
- 回傳字典要包含 `source_file`、`order_count`、`total_amount`、`order_ids`。
- `source_file` 使用檔案名稱，`order_ids` 保留原本訂單順序。

## 檢查順序

1. 是否正確讀取 JSON 檔案。
2. 是否把 JSON 文字轉成 Python 資料。
3. 回傳值是否是字典。
4. 勇者版是否正確計算道具數量。
5. 寶可夢版是否依 `min_cp` 篩選，並加入 `source_file`。
6. 電子商務版是否正確統計訂單數量與總金額。

## 常見錯誤

- 忘記先用 `read_text()` 讀出檔案內容。
- 忘記用 `json.loads()` 把 JSON 文字轉成 Python 資料。
- 只印出資料，沒有回傳摘要字典。
- 回傳原始資料，沒有依題目整理欄位。
- 電子商務版只回傳原始訂單清單，沒有整理成摘要字典。

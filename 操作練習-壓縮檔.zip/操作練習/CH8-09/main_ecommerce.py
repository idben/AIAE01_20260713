import json
from pathlib import Path


def build_order_batch_summary(batch_path: Path) -> dict[str, object]:
    # 請讀取訂單批次 JSON 檔，整理訂單數量、總金額、訂單編號與來源檔名
    pass

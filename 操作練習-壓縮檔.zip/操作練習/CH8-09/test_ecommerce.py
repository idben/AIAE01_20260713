import subprocess
import sys

from pathlib import Path

from main_ecommerce import build_order_batch_summary

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_order_batch_summary() -> bool:
    print("---------------------------------")
    batch_path = Path(__file__).resolve().parent / "orders.json"
    actual = build_order_batch_summary(batch_path)
    expected: dict[str, object] = {
        "source_file": "orders.json",
        "order_count": 3,
        "total_amount": 2080,
        "order_ids": ["訂單-1001", "訂單-1002", "訂單-1003"],
    }
    print("輸入：orders.json 訂單批次資料")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_empty_order_batch_summary() -> bool:
    print("---------------------------------")
    batch_path = Path(__file__).resolve().parent / "empty_orders.json"
    actual = build_order_batch_summary(batch_path)
    expected: dict[str, object] = {
        "source_file": "empty_orders.json",
        "order_count": 0,
        "total_amount": 0,
        "order_ids": [],
    }
    print("輸入：empty_orders.json 空訂單批次")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_order_batch_summary(),
        test_empty_order_batch_summary(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

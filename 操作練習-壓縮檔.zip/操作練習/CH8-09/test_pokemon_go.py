import subprocess
import sys

from pathlib import Path

from main_pokemon_go import build_strong_catch_summary

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_strong_catch_summary() -> bool:
    print("---------------------------------")
    catch_path = Path(__file__).resolve().parent / "daily_catches.json"
    actual = build_strong_catch_summary(catch_path, 400)
    expected: dict[str, object] = {
        "source_file": "daily_catches.json",
        "min_cp": 400,
        "matched_count": 2,
        "pokemon_names": ["皮卡丘", "卡比獸"],
    }
    print("輸入：daily_catches.json 捕捉紀錄")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_strong_catch_summary_no_match() -> bool:
    print("---------------------------------")
    catch_path = Path(__file__).resolve().parent / "weak_catches.json"
    actual = build_strong_catch_summary(catch_path, 400)
    expected: dict[str, object] = {
        "source_file": "weak_catches.json",
        "min_cp": 400,
        "matched_count": 0,
        "pokemon_names": [],
    }
    print("輸入：weak_catches.json 捕捉紀錄")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [
        test_strong_catch_summary(),
        test_strong_catch_summary_no_match(),
    ]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

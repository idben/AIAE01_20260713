import json
from pathlib import Path


def build_character_summary(profile_path: Path) -> dict[str, object]:
    # 請讀取角色 JSON 檔，整理角色名稱、道具數量與金幣
    pass

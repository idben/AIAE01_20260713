class PartyMember:
    def __init__(self, name: str, hp: int) -> None:
        # 請讓隊伍成員記住 name 與 hp
        pass

    def take_damage(self, damage: int) -> None:
        # 請讓自己承受傷害
        pass


def run_battle_demo() -> str:
    # 請建立勇者與史萊姆，讓史萊姆承受 18 點傷害並回傳結果文字
    pass


def main() -> None:
    # 請印出 run_battle_demo() 的結果
    pass


# 請在這裡加入 main block

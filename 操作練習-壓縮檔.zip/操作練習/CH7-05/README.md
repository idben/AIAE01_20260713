# CH7-05 練習

## 題目

完成可直接執行、也可被測試匯入的主程式。

- 《勇者鬥惡龍》：戰鬥示範
- 《寶可夢 GO》：附近出現示範
- 電子商務：多筆訂單營收報表

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `revenue_report.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先完成資料類別，讓物件記住公開資料。
2. 完成會回傳字串的 `run_*_demo()`。
3. 完成 `main()`，直接執行時才印出示範結果。
4. 把 `main()` 呼叫放進 `if __name__ == "__main__":`。

三題的難度安排如下：

- 《勇者鬥惡龍》：先練最基本的「回傳示範文字」與 main block。
- 《寶可夢 GO》：請自己對照測試檔，確認匯入無輸出與示範函式回傳值兩件事都成立。
- 電子商務：請從測試檔觀察多筆訂單金額如何彙總成營收報表，並確認匯入時沒有自動輸出。

## 題目提示

測試會先匯入作答檔，確認匯入時沒有自動輸出。接著才會呼叫 `run_battle_demo()` 或 `run_nearby_demo()` 檢查回傳值。

### 《勇者鬥惡龍》

- 測試檔會呼叫 `run_battle_demo()`。
- 示範流程需要建立勇者與史萊姆，讓史萊姆承受傷害。
- 可測試邏輯要回傳字串，`main()` 才負責印出。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔的預期文字。
2. 再完成資料類別與扣 HP 方法。
3. 接著讓 `run_battle_demo()` 回傳示範文字。
4. 最後補上 main block，避免匯入時自動輸出。

### 《寶可夢 GO》

- 測試檔會呼叫 `run_nearby_demo()`。
- 請從預期文字判斷附近出現資料要顯示哪些欄位。
- 匯入主檔案時不能印出任何內容。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔如何捕捉匯入時的輸出。
2. 再看 `run_nearby_demo()` 的預期回傳值。
3. 接著完成 `NearbySpawn` 的資料保存與顯示文字。
4. 最後讓 `main()` 只在 main block 中被呼叫。

### 電子商務

- 已寫好的模組是 `revenue_report.py`。
- 主檔案要 import 已寫好的營收彙總模組，並在 `run_revenue_demo()` 使用它。
- 請從測試資料觀察示範資料的訂單筆數與營收總額。
- 匯入主檔案時不能印出任何內容。

作答時建議照這個順序觀察與判斷：

1. 先看測試檔如何捕捉匯入時的輸出。
2. 再打開 `revenue_report.py`，確認已提供的函式名稱與參數。
3. 接著回到主檔案，把已寫好的模組 import 進來。
4. 最後讓 `run_revenue_demo()` 提供示範資料並呼叫已寫好的函式，`main()` 只在 main block 中被呼叫。

## 這題常見錯誤

- 在檔案最外層直接 `print()`。
- 忘記 main block，導致測試匯入時自動執行主流程。
- 把可測試邏輯只寫在 `main()` 裡，沒有回傳值。

## 這題在測什麼

- `__name__ == "__main__"`
- 主流程與可測試邏輯分離
- 匯入模組時避免副作用

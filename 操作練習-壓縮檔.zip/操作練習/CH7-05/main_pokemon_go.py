class NearbySpawn:
    def __init__(self, name: str, cp: int) -> None:
        # 請讓附近出現資料記住 name 與 cp
        pass

    def get_label(self) -> str:
        # 請回傳地圖上要顯示的文字
        pass


def run_nearby_demo() -> str:
    # 請建立皮卡丘 CP 420，並回傳顯示文字
    pass


def main() -> None:
    # 請印出 run_nearby_demo() 的結果
    pass


# 請在這裡加入 main block

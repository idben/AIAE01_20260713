def run_revenue_demo() -> str:
    # 請用 1800、650、250 三筆訂單金額，呼叫已寫好的營收彙總函式
    pass


def main() -> None:
    # 請印出 run_revenue_demo() 的結果
    pass


# 請在這裡加入 main block

def summarize_revenue(order_totals: list[int]) -> str:
    order_count = len(order_totals)
    revenue_total = sum(order_totals)
    return f"今日 {order_count} 筆訂單，營收 {revenue_total} 元"

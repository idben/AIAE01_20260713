import contextlib
import importlib
import io
import subprocess
import sys
from pathlib import Path


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_import_has_no_output() -> bool:
    print("---------------------------------")
    print("輸入：匯入 main_pokemon_go")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        importlib.import_module("main_pokemon_go")
    actual = output.getvalue()
    print("預期：匯入時沒有輸出")
    print(f"實際：{actual!r}")
    if actual == "":
        print("通過")
        return True
    print("失敗")
    return False


def test_run_demo() -> bool:
    print("---------------------------------")
    module = importlib.import_module("main_pokemon_go")
    expected = "皮卡丘 CP 420"
    actual = module.run_nearby_demo()
    print("輸入：run_nearby_demo()")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_import_has_no_output(), test_run_demo()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

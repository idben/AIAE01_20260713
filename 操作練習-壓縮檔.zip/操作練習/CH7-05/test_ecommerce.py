import contextlib
import importlib
import io
import subprocess
import sys
from pathlib import Path

import revenue_report


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_import_has_no_output() -> bool:
    print("---------------------------------")
    print("輸入：匯入 main_ecommerce")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        importlib.import_module("main_ecommerce")
    actual = output.getvalue()
    print("預期：匯入時沒有輸出")
    print(f"實際：{actual!r}")
    if actual == "":
        print("通過")
        return True
    print("失敗")
    return False


def test_run_demo() -> bool:
    print("---------------------------------")
    module = importlib.import_module("main_ecommerce")
    expected = "今日 3 筆訂單，營收 2700 元"
    actual = module.run_revenue_demo()
    print("輸入：run_revenue_demo()")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_summarize_revenue() -> bool:
    print("---------------------------------")
    order_totals = [499, 1200, 300]
    expected = "今日 3 筆訂單，營收 1999 元"
    actual = revenue_report.summarize_revenue(order_totals)
    print(f"輸入：{order_totals}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_import_has_no_output(), test_summarize_revenue(), test_run_demo()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

# CH2-03 練習

## 題目

這一課練習「方法可以回傳值」。

- 《勇者鬥惡龍》版：完成 `get_turn_speed()`
- 《寶可夢 GO》版：完成 `get_attack_score()`

## 檔案

- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版
- `main_pokemon_go.py`：學生作答，《寶可夢 GO》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO》版

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成指定方法
4. 存檔後，在這個資料夾執行對應測試
5. 如果最後看到 `============= 全部通過 ==============`
   代表該版本已通過目前測試

## 題目提示

### 《勇者鬥惡龍》版

- 角色的行動速度，可以想成由敏捷扣掉裝備重量
- 你可以用 `agility` 記敏捷，用 `armor_weight` 記裝備重量
- `get_turn_speed()` 要回傳 `agility - armor_weight`
- 回傳後，你可以想像這個數字會被拿去判斷誰先行動

### 《寶可夢 GO》版

- 寶可夢的簡化攻擊分數，可以想成由攻擊值加上招式威力
- 你可以用 `attack` 記攻擊值，用 `move_power` 記招式威力
- `get_attack_score()` 要回傳 `attack + move_power`
- 回傳後，你可以想像這個數字會被拿去判斷值不值得上場或強化

## 這題常見錯誤

- 忘了 `return`
- 公式寫反
- 把方法寫成修改狀態，而不是回傳計算結果

## 這題在測什麼

- 方法是否存在
- 是否能根據屬性計算結果
- 是否理解「回傳值」和「修改狀態」的差別

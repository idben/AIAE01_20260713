class PartyMember:
    agility: int = 12
    armor_weight: int = 3

    def get_turn_speed(self) -> int:
        pass

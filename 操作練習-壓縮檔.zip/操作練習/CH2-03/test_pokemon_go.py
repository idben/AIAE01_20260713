import subprocess
import sys
from pathlib import Path

from main_pokemon_go import PokemonBattleInfo

TestCase = tuple[int, int, int]

run_cases: list[TestCase] = [
    (120, 70, 190),
    (80, 40, 120),
]

submit_cases: list[TestCase] = run_cases + [
    (150, 90, 240),
    (10, 5, 15),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(attack: int, move_power: int, expected: int) -> bool:
    print("---------------------------------")
    print(f"攻擊值：{attack}")
    print(f"招式威力：{move_power}")
    print(f"預期分數：{expected}")
    battle_info = PokemonBattleInfo()
    battle_info.attack = attack
    battle_info.move_power = move_power
    result = battle_info.get_attack_score()
    print(f"實際分數：{result}")
    if result == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

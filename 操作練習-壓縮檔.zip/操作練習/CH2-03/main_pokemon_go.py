class PokemonBattleInfo:
    attack: int = 120
    move_power: int = 70

    def get_attack_score(self) -> int:
        pass

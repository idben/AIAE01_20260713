# CH5-05 練習

## 題目

這一課練習第二種子類別攻擊。

- 《勇者鬥惡龍》版：完成 `Wizard(Hero)`（法師繼承英雄）與 `cast()`
- 《寶可夢 GO》版：完成 `ChargedAttacker(BattlePokemon)`（集氣招式型寶可夢繼承戰鬥中的寶可夢）與 `use_charged_move()`
- 《電子商務》版：完成 `GiftCardOrder(Order)`（禮物卡訂單繼承訂單）與 `redeem_gift_card()`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 先看父類別已經記住哪些共通資料，再確認子類別還要補什麼資源。
2. 《勇者鬥惡龍》重點是魔力門檻和傷害都落在 `25`。
3. 《寶可夢 GO》重點是能量規則和集氣招式的消耗順序。
4. 《電子商務》重點是禮物卡餘額是否足夠，以及成功後要更新哪兩個值。
5. 執行測試確認例外訊息與最終狀態。

## 常見錯誤

- 忘記 `super().__init__()`
- 沒有先檢查 `< 25`
- 遊戲版扣了資源卻忘記改目標生命值
- 電子商務版只扣餘額，卻忘了同步減少訂單金額

## 這題在測什麼

- 兄弟子類別的不同攻擊模式
- 狀態更新順序
- 例外訊息檢查

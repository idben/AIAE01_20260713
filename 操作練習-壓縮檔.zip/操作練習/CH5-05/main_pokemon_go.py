class BattlePokemon:
    def __init__(self, name: str, health: int) -> None:
        self.__name = name
        self.__health = health

    def get_name(self) -> str:
        return self.__name

    def get_health(self) -> int:
        return self.__health

    def take_damage(self, damage: int) -> None:
        self.__health -= damage


## 以上內容不要修改


class ChargedAttacker(BattlePokemon):
    def __init__(self, name: str, health: int, energy: int) -> None:
        pass

    def use_charged_move(self, target: BattlePokemon) -> None:
        pass

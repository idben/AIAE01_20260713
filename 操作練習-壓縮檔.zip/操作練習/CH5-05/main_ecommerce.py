class Order:
    def __init__(self, order_id: str, total_amount: int) -> None:
        self.__order_id = order_id
        self.__total_amount = total_amount

    def get_order_id(self) -> str:
        return self.__order_id

    def get_total_amount(self) -> int:
        return self.__total_amount

    def reduce_total(self, amount: int) -> None:
        self.__total_amount -= amount


## 以上內容不要修改


class GiftCardOrder(Order):
    def __init__(self, order_id: str, total_amount: int, balance: int) -> None:
        pass

    def redeem_gift_card(self) -> None:
        pass

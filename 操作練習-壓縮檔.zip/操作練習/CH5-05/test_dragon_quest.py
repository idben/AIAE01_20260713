import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Hero, Wizard

TestCase = tuple[tuple[str, int, int], tuple[str, int], int | None, str | None, bool]

run_cases: list[TestCase] = [
    (("潔西卡", 30, 50), ("勇者", 80), 55, None, False),
    (("貝洛妮卡", 24, 25), ("希爾比亞", 60), None, "not enough mana", True),
]

submit_cases: list[TestCase] = run_cases + [
    (("瑪蒂娜", 40, 49), ("卡繆", 70), None, "not enough mana", True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(wizard_args: tuple[str, int, int], target_args: tuple[str, int], expected_health: int | None, expected_error: str | None, twice: bool) -> bool:
    print("---------------------------------")
    wizard = Wizard(*wizard_args)
    target = Hero(*target_args)
    try:
        wizard.cast(target)
        if twice:
            wizard.cast(target)
        actual = target.get_health()
        print(f"預期生命值：{expected_health}")
        print(f"實際生命值：{actual}")
        if expected_error:
            return False
        return actual == expected_health
    except Exception as error:
        print(f"預期例外：{expected_error}")
        print(f"實際例外：{error}")
        return str(error) == expected_error


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

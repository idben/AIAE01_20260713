class RaidPokemon:
    def __init__(self, name: str, stamina: int, charge_skill: int) -> None:
        pass

import subprocess
import sys
from pathlib import Path

from main_pokemon_go import RaidPokemon

TestCase = tuple[str, int, int, int, int]

run_cases: list[TestCase] = [
    ("Pikachu", 10, 10, 1000, 100),
    ("Snorlax", 20, 5, 2000, 50),
]

submit_cases: list[TestCase] = run_cases + [
    ("Lucario", 3, 3, 300, 30),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    pokemon_name: str,
    pokemon_stamina: int,
    pokemon_charge_skill: int,
    expected_hp: int,
    expected_energy: int,
) -> bool:
    print("---------------------------------")
    print("建立團體戰寶可夢：")
    pokemon = RaidPokemon(pokemon_name, pokemon_stamina, pokemon_charge_skill)
    print(f"  名稱：{pokemon.name}")
    print(f"  耐久：{pokemon_stamina}")
    print(f"  蓄力熟練：{pokemon_charge_skill}")
    print("初始化後：")
    print(f"  預期能量：{expected_energy}")
    print(f"  實際能量：{pokemon.energy}")
    print(f"  預期 hp：{expected_hp}")
    print(f"  實際 hp：{pokemon.hp}")
    if pokemon.energy != expected_energy:
        print("失敗")
        return False
    if pokemon.hp != expected_hp:
        print("失敗")
        return False
    is_private = True
    if hasattr(pokemon, "stamina"):
        is_private = False
        print("stamina 不應該是公開屬性")
    if hasattr(pokemon, "charge_skill"):
        is_private = False
        print("charge_skill 不應該是公開屬性")
    try:
        getattr(pokemon, "_RaidPokemon__stamina")
        getattr(pokemon, "_RaidPokemon__charge_skill")
    except AttributeError:
        print("私有屬性 __stamina 與 __charge_skill 必須存在")
        return False
    if is_private:
        print("通過")
    else:
        print("失敗")
    return is_private


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

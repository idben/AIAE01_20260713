class SpellCaster:
    def __init__(self, name: str, stamina: int, wisdom: int) -> None:
        pass

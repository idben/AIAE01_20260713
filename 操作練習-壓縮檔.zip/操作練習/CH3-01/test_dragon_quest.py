import subprocess
import sys
from pathlib import Path

from main_dragon_quest import SpellCaster

TestCase = tuple[str, int, int, int, int]

run_cases: list[TestCase] = [
    ("勇者", 10, 10, 1000, 100),
    ("魔法使", 20, 5, 2000, 50),
]

submit_cases: list[TestCase] = run_cases + [
    ("僧侶", 3, 3, 300, 30),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    caster_name: str,
    caster_stamina: int,
    caster_wisdom: int,
    expected_hp: int,
    expected_mp: int,
) -> bool:
    print("---------------------------------")
    print("建立施法者：")
    caster = SpellCaster(caster_name, caster_stamina, caster_wisdom)
    print(f"  名稱：{caster.name}")
    print(f"  耐力：{caster_stamina}")
    print(f"  智慧：{caster_wisdom}")
    print("初始化後：")
    print(f"  預期 mp：{expected_mp}")
    print(f"  實際 mp：{caster.mp}")
    print(f"  預期 hp：{expected_hp}")
    print(f"  實際 hp：{caster.hp}")
    if caster.mp != expected_mp:
        print("失敗")
        return False
    if caster.hp != expected_hp:
        print("失敗")
        return False
    is_private = True
    if hasattr(caster, "stamina"):
        is_private = False
        print("stamina 不應該是公開屬性")
    if hasattr(caster, "wisdom"):
        is_private = False
        print("wisdom 不應該是公開屬性")
    try:
        getattr(caster, "_SpellCaster__stamina")
        getattr(caster, "_SpellCaster__wisdom")
    except AttributeError:
        print("私有屬性 __stamina 與 __wisdom 必須存在")
        return False
    if is_private:
        print("通過")
    else:
        print("失敗")
    return is_private


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

import subprocess
import sys
from pathlib import Path

from main_pokemon_go import CoinWallet

TestCase = tuple[str, float, float, float, float, str | None, str | None]

run_cases: list[TestCase] = [
    ("GO-001", 100.0, 50.0, 75.0, 75.0, None, None),
    ("GO-002", 500.0, 100.0, 200.0, 400.0, None, None),
    (
        "GO-003",
        200.0,
        0.0,
        10.0,
        190.0,
        "cannot deposit zero or negative funds",
        None,
    ),
]

submit_cases: list[TestCase] = run_cases + [
    ("GO-004", 100.0, 50.0, 200.0, 150.0, None, "insufficient funds"),
    ("GO-005", 500.0, 500.0, 500.0, 500.0, None, None),
    (
        "GO-006",
        300.0,
        -10.0,
        20.0,
        280.0,
        "cannot deposit zero or negative funds",
        None,
    ),
    ("GO-007", -20.0, 10.0, 10.0, -10.0, None, "insufficient funds"),
    (
        "GO-008",
        100.0,
        10.0,
        -10.0,
        110.0,
        None,
        "cannot withdraw zero or negative funds",
    ),
    (
        "GO-009",
        900.0,
        100.0,
        0.0,
        1000.0,
        None,
        "cannot withdraw zero or negative funds",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    trainer_id: str,
    initial_coins: float,
    earn_amount: float,
    spend_amount: float,
    expected_coins: float,
    earn_err: str | None,
    spend_err: str | None,
) -> bool:
    print("---------------------------------")
    try:
        print("輸入：")
        print(f" * trainer_id: {trainer_id}")
        print(f" * initial_coins: {initial_coins:.2f}")
        print(f" * earn_amount: {earn_amount:.2f}")
        print(f" * spend_amount: {spend_amount:.2f}")
        wallet = CoinWallet(trainer_id, initial_coins)
        try:
            wallet.earn_coins(earn_amount)
            if earn_err:
                print(f'預期錯誤："{earn_err}"')
                print("實際結果：沒有拋出錯誤")
                print("失敗")
                return False
        except ValueError as e:
            print(f'預期錯誤："{earn_err}"')
            print(f'實際錯誤："{e}"')
            if str(e) != earn_err:
                print("失敗")
                return False
        try:
            wallet.spend_coins(spend_amount)
            if spend_err:
                print(f'預期錯誤："{spend_err}"')
                print("實際結果：沒有拋出錯誤")
                print("失敗")
                return False
        except ValueError as e:
            print(f'預期錯誤："{spend_err}"')
            print(f'實際錯誤："{e}"')
            if str(e) != spend_err:
                print("失敗")
                return False
        print(f"預期金幣：{expected_coins:.2f}")
        print(f"實際金幣：{wallet.get_coins():.2f}")
        if wallet.get_coins() != expected_coins:
            print("失敗")
            return False
        print("通過")
        return True
    except Exception as e:
        print(f"失敗：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

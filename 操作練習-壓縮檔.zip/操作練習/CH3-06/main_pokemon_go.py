class CoinWallet:
    def __init__(self, trainer_id: str, initial_coins: float) -> None:
        pass

    def get_trainer_id(self) -> str:
        pass

    def get_coins(self) -> float:
        pass

    def earn_coins(self, amount: float) -> None:
        pass

    def spend_coins(self, amount: float) -> None:
        pass

# CH3-06 練習

## 題目

這一課練習把內部資源值包在類別裡，並透過公開方法安全修改。

- 《勇者鬥惡龍》版：完成 `GoldVault`
- 《寶可夢 GO》版：完成 `CoinWallet`

## 檔案

- `練習改寫/CH3-06/main_dragon_quest.py`
- `練習改寫/CH3-06/test_dragon_quest.py`
- `練習改寫/CH3-06/main_pokemon_go.py`
- `練習改寫/CH3-06/test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。全部通過時會播放過關音效。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成建構子、getter 與增減資源方法
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- 先觀察建構子參數：金庫編號與初始金幣
- getter 只負責回傳資料，不應該修改金幣數量
- `deposit_gold(amount)` 收到的是要存入的金額，先檢查金額是否為正數；不是正數時丟出 `ValueError("cannot deposit zero or negative funds")`
- `withdraw_gold(amount)` 收到的是要領出的金額，先檢查金額是否為正數；不是正數時丟出 `ValueError("cannot withdraw zero or negative funds")`
- 領出前還要檢查目前金幣是否足夠；不夠時丟出 `ValueError("insufficient funds")`
- 檢查失敗時不能偷偷改變金幣數量

### 《寶可夢 GO》版

- 先觀察建構子參數：訓練家錢包編號與初始遊戲幣
- getter 只負責回傳資料，不應該修改遊戲幣數量
- `earn_coins(amount)` 收到的是要增加的遊戲幣，先檢查金額是否為正數；不是正數時丟出 `ValueError("cannot deposit zero or negative funds")`
- `spend_coins(amount)` 收到的是要花掉的遊戲幣，先檢查金額是否為正數；不是正數時丟出 `ValueError("cannot withdraw zero or negative funds")`
- 花費前還要檢查目前遊戲幣是否足夠；不夠時丟出 `ValueError("insufficient funds")`
- 檢查失敗時不能偷偷改變遊戲幣數量

## 這題常見錯誤

- 丟錯例外型別
- 錯誤訊息和題目要求不一致
- 失敗時仍然偷偷改變餘額

## 這題在測什麼

- 是否能用公開方法保護內部狀態
- 是否能正確處理錯誤流程
- 是否理解檢查順序會影響結果

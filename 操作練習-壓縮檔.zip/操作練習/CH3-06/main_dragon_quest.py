class GoldVault:
    def __init__(self, vault_id: str, initial_gold: float) -> None:
        pass

    def get_vault_id(self) -> str:
        pass

    def get_gold(self) -> float:
        pass

    def deposit_gold(self, amount: float) -> None:
        pass

    def withdraw_gold(self, amount: float) -> None:
        pass

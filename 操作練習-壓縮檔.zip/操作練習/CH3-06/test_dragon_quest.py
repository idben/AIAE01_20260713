import subprocess
import sys
from pathlib import Path

from main_dragon_quest import GoldVault

TestCase = tuple[str, float, float, float, float, str | None, str | None]

run_cases: list[TestCase] = [
    ("DQ-001", 100.0, 50.0, 75.0, 75.0, None, None),
    ("DQ-002", 500.0, 100.0, 200.0, 400.0, None, None),
    (
        "DQ-003",
        200.0,
        0.0,
        10.0,
        190.0,
        "cannot deposit zero or negative funds",
        None,
    ),
]

submit_cases: list[TestCase] = run_cases + [
    ("DQ-004", 100.0, 50.0, 200.0, 150.0, None, "insufficient funds"),
    ("DQ-005", 500.0, 500.0, 500.0, 500.0, None, None),
    (
        "DQ-006",
        300.0,
        -10.0,
        20.0,
        280.0,
        "cannot deposit zero or negative funds",
        None,
    ),
    ("DQ-007", -20.0, 10.0, 10.0, -10.0, None, "insufficient funds"),
    (
        "DQ-008",
        100.0,
        10.0,
        -10.0,
        110.0,
        None,
        "cannot withdraw zero or negative funds",
    ),
    (
        "DQ-009",
        900.0,
        100.0,
        0.0,
        1000.0,
        None,
        "cannot withdraw zero or negative funds",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    vault_id: str,
    initial_gold: float,
    deposit_amount: float,
    withdraw_amount: float,
    expected_gold: float,
    deposit_err: str | None,
    withdraw_err: str | None,
) -> bool:
    print("---------------------------------")
    try:
        print("輸入：")
        print(f" * vault_id: {vault_id}")
        print(f" * initial_gold: {initial_gold:.2f}")
        print(f" * deposit_amount: {deposit_amount:.2f}")
        print(f" * withdraw_amount: {withdraw_amount:.2f}")
        vault = GoldVault(vault_id, initial_gold)
        try:
            vault.deposit_gold(deposit_amount)
            if deposit_err:
                print(f'預期錯誤："{deposit_err}"')
                print("實際結果：沒有拋出錯誤")
                print("失敗")
                return False
        except ValueError as e:
            print(f'預期錯誤："{deposit_err}"')
            print(f'實際錯誤："{e}"')
            if str(e) != deposit_err:
                print("失敗")
                return False
        try:
            vault.withdraw_gold(withdraw_amount)
            if withdraw_err:
                print(f'預期錯誤："{withdraw_err}"')
                print("實際結果：沒有拋出錯誤")
                print("失敗")
                return False
        except ValueError as e:
            print(f'預期錯誤："{withdraw_err}"')
            print(f'實際錯誤："{e}"')
            if str(e) != withdraw_err:
                print("失敗")
                return False
        print(f"預期金幣：{expected_gold:.2f}")
        print(f"實際金幣：{vault.get_gold():.2f}")
        if vault.get_gold() != expected_gold:
            print("失敗")
            return False
        print("通過")
        return True
    except Exception as e:
        print(f"失敗：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

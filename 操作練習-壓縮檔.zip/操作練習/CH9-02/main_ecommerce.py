def audit_invoice_action(original_function):
    # 請回傳 wrapper，wrapper 要把原函式回傳的發票摘要整理成稽核字典
    raise NotImplementedError("請完成 audit_invoice_action")


def build_invoice_summary() -> dict[str, object]:
    return {
        "order_id": "A1001",
        "status": "已開立",
        "total": 2400,
    }


def run_demo() -> dict[str, object]:
    audited_invoice = audit_invoice_action(build_invoice_summary)
    return audited_invoice()


if __name__ == "__main__":
    print(run_demo())

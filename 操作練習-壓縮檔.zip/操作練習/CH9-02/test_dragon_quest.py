import subprocess
import sys

from pathlib import Path

from main_dragon_quest import log_treasure_action, open_treasure_chest

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_log_treasure_action() -> bool:
    print("---------------------------------")
    logged = log_treasure_action(open_treasure_chest)
    actual = logged()
    expected = "勇者打開寶箱，取得 鐵劍"
    print("輸入：包裝 open_treasure_chest")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_log_treasure_action_keeps_another_result() -> bool:
    print("---------------------------------")
    logged = log_treasure_action(lambda: "勇者檢查木桶，找到 藥草")
    actual = logged()
    expected = "勇者檢查木桶，找到 藥草"
    print("輸入：包裝另一個回傳字串的寶箱行動")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_log_treasure_action(), test_log_treasure_action_keeps_another_result()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

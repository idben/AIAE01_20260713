import subprocess
import sys

from pathlib import Path

from main_pokemon_go import collect_raid_rewards, summarize_reward_action

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_summarize_reward_action() -> bool:
    print("---------------------------------")
    summarized = summarize_reward_action(collect_raid_rewards)
    actual = summarized()
    expected = {
        "rewards": ["金色蔓莓果", "神奇糖果", "星星沙子"],
        "reward_count": 3,
    }
    print("輸入：摘要 collect_raid_rewards")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_summarize_reward_action_counts_another_list() -> bool:
    print("---------------------------------")
    summarized = summarize_reward_action(lambda: ["高級球", "活力碎片"])
    actual = summarized()
    expected = {
        "rewards": ["高級球", "活力碎片"],
        "reward_count": 2,
    }
    print("輸入：摘要另一個回傳清單的獎勵函式")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_summarize_reward_action(), test_summarize_reward_action_counts_another_list()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

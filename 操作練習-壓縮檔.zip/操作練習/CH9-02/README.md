# CH9-02 練習

## 你要完成的事

完成函式包裝，練習在 `wrapper()` 裡處理原函式結果。

建議完成順序：

- 《勇者鬥惡龍》：先包裝回傳字串的寶箱行動，原樣回傳結果。
- 《寶可夢 GO》：再包裝回傳清單的團體戰獎勵，把清單整理成摘要字典。
- 電子商務：最後包裝回傳字典的發票摘要，建立外層稽核資料。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

1. 先觀察原函式本來回傳什麼。
2. 再完成裝飾器外層函式與內層 `wrapper()`。
3. 依照題目決定：原樣回傳、整理摘要，或建立外層資料。
4. 最後用測試確認包裝後的函式回傳正確資料。

## 題目提示

### 《勇者鬥惡龍》版

先觀察 `open_treasure_chest()`。這個寶箱行動沒有參數，只負責回傳取得道具的文字。`log_treasure_action()` 要包住它，讓字串結果可以穿過包裝層。

### 《寶可夢 GO》版

先觀察 `collect_raid_rewards()`。它回傳的是多個團體戰獎勵組成的清單，不是一段文字。`summarize_reward_action()` 要保留這份清單，並另外算出 `reward_count`。

摘要規則：

- `rewards` 放原本的獎勵清單，內容與順序都不要改。
- `reward_count` 放清單中的獎勵數量。

### 電子商務版

先觀察 `build_invoice_summary()`。它回傳的是發票摘要字典，裡面有訂單編號、狀態與金額。`audit_invoice_action()` 要把原本字典放進 `invoice`，再組出 `audit_message`。

稽核規則：

- `invoice` 放原本的發票摘要字典。
- `audit_message` 要使用摘要裡的訂單編號、狀態與金額。
- 訊息順序是「發票」→ 訂單編號 → 狀態 →「金額」→ 金額數字 →「元」。
- 狀態要照原本資料使用，例如「已開立」或「待開立」，不要自己改字。

## 檢查順序

1. 裝飾器是否回傳 `wrapper`。
2. `wrapper()` 是否有呼叫原函式。
3. 勇者版是否原樣回傳字串。
4. 寶可夢版是否回傳包含 `rewards` 和 `reward_count` 的字典。
5. 電子商務版是否回傳包含 `invoice` 和 `audit_message` 的字典。

## 常見卡住點

- 忘記 `return wrapper`。
- 忘記在 `wrapper()` 裡 `return result`。
- 寶可夢版只回傳清單，沒有建立摘要字典。
- 電子商務版只回傳發票摘要，沒有建立稽核字典。

## 做完你會練到

- 函式包裝。
- 在 `wrapper()` 裡保留、整理或包裝原函式結果。

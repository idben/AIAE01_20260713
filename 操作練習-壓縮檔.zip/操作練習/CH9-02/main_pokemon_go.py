def summarize_reward_action(original_function):
    # 請回傳 wrapper，wrapper 要把原函式回傳的獎勵清單整理成摘要字典
    raise NotImplementedError("請完成 summarize_reward_action")


def collect_raid_rewards() -> list[str]:
    return ["金色蔓莓果", "神奇糖果", "星星沙子"]


def run_demo() -> dict[str, object]:
    summarized_rewards = summarize_reward_action(collect_raid_rewards)
    return summarized_rewards()


if __name__ == "__main__":
    print(run_demo())

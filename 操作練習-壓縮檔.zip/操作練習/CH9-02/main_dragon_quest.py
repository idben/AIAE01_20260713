def log_treasure_action(original_function):
    # 請回傳 wrapper，wrapper 要保留原函式回傳值
    raise NotImplementedError("請完成 log_treasure_action")


def open_treasure_chest() -> str:
    return "勇者打開寶箱，取得 鐵劍"


def run_demo() -> str:
    logged_open = log_treasure_action(open_treasure_chest)
    return logged_open()


if __name__ == "__main__":
    print(run_demo())

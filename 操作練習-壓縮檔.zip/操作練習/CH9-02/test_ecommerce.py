import subprocess
import sys

from pathlib import Path

from main_ecommerce import audit_invoice_action, build_invoice_summary

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_audit_invoice_action() -> bool:
    print("---------------------------------")
    audited = audit_invoice_action(build_invoice_summary)
    actual = audited()
    invoice = {"order_id": "A1001", "status": "已開立", "total": 2400}
    expected = {
        "invoice": invoice,
        "audit_message": "發票 A1001 已開立，金額 2400 元",
    }
    print("輸入：稽核 build_invoice_summary")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_audit_invoice_action_uses_another_invoice() -> bool:
    print("---------------------------------")
    invoice = {"order_id": "A1002", "status": "待開立", "total": 800}
    audited = audit_invoice_action(lambda: invoice)
    actual = audited()
    expected = {
        "invoice": invoice,
        "audit_message": "發票 A1002 待開立，金額 800 元",
    }
    print("輸入：稽核另一個回傳字典的發票函式")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_audit_invoice_action(), test_audit_invoice_action_uses_another_invoice()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

from pathlib import Path


def get_order_export_path(base_folder: Path, shop_code: str, file_name: str) -> Path:
    # 請只組合路徑，不要建立資料夾或寫入檔案
    raise NotImplementedError("請完成 get_order_export_path")


def main() -> None:
    print(get_order_export_path(Path("data"), "台北門市", "orders.csv"))


if __name__ == "__main__":
    main()

from pathlib import Path


def get_catch_record_path(base_folder: Path, trainer_id: str, file_name: str) -> Path:
    # 請只組合路徑，不要建立資料夾或寫入檔案
    raise NotImplementedError("請完成 get_catch_record_path")


def main() -> None:
    print(get_catch_record_path(Path("data"), "trainer-7", "catch.txt"))


if __name__ == "__main__":
    main()

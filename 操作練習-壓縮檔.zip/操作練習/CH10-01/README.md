# CH10-01 練習

## 題目

練習用 `pathlib.Path` 組合資料檔案路徑。

- 《勇者鬥惡龍》版：組合隊伍紀錄檔路徑。
- 《寶可夢 GO》版：組合指定訓練家的捕捉紀錄檔路徑。
- 電子商務版：組合指定商店的訂單匯出路徑。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

《勇者鬥惡龍》版：完成 `get_party_record_path(base_folder, file_name)`，回傳 `base_folder` 底下 `party_records` 資料夾中的檔案路徑。

《寶可夢 GO》版：完成 `get_catch_record_path(base_folder, trainer_id, file_name)`，回傳 `base_folder` 底下 `trainers`、指定訓練家編號、`catch_records`、檔名組成的路徑。

電子商務版：完成 `get_order_export_path(base_folder, shop_code, file_name)`，回傳 `base_folder` 底下 `ecommerce_exports`、指定商店代碼、檔名組成的路徑。

操作順序：

- 《勇者鬥惡龍》：只組合一層固定資料夾。
- 《寶可夢 GO》：多一個 `trainer_id`，要組合到訓練家專屬資料夾。
- 電子商務：多一個 `shop_code`，要組合到商店專屬資料夾。

## 題目提示

名稱對照：

- `get_party_record_path`：取得隊伍紀錄檔路徑
- `get_catch_record_path`：取得捕捉紀錄檔路徑
- `base_folder`：基準資料夾
- `trainer_id`：訓練家編號
- `shop_code`：商店代碼
- `file_name`：檔名

這裡只組合路徑，不建立資料夾，也不寫入檔案。回傳值必須是 `Path`。

測試會使用不同的基準資料夾、訓練家編號、商店代碼與檔名。不要把範例中的某一個檔名、訓練家編號或商店代碼寫死在函式裡。

## 常見錯誤

- 回傳字串而不是 `Path`。
- 順便建立檔案或資料夾。
- 資料夾名稱和測試檔期待不一致。
- 只針對一組範例輸入寫死路徑，換成另一組輸入就失敗。

## 你會練到什麼

- `pathlib.Path`
- 路徑組合
- 函式責任分離

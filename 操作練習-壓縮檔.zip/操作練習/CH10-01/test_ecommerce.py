from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import get_order_export_path


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_get_order_export_path() -> bool:
    cases = [
        ("exports", "台北門市", "orders.csv"),
        ("daily_reports", "高雄分店", "weekend_orders.csv"),
    ]
    all_passed = True
    for base_name, shop_code, file_name in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            base_folder = Path(folder) / base_name
            actual = get_order_export_path(base_folder, shop_code, file_name)
            expected = base_folder / "ecommerce_exports" / shop_code / file_name
            file_exists = actual.exists()
            parent_exists = expected.parent.exists()
            is_path = isinstance(actual, Path)
        print(f"輸入：base_folder={base_name}，shop_code={shop_code}，file_name={file_name}")
        print(f"預期路徑：{expected}")
        print(f"實際路徑：{actual}")
        print("預期：回傳 Path，且不建立資料夾或檔案")
        print(f"實際是否為 Path：{is_path}")
        print(f"實際檔案是否存在：{file_exists}")
        print(f"實際父資料夾是否存在：{parent_exists}")
        if actual == expected and is_path and file_exists is False and parent_exists is False:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_get_order_export_path()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

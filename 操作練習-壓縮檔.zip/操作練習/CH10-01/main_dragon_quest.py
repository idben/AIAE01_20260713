from pathlib import Path


def get_party_record_path(base_folder: Path, file_name: str) -> Path:
    # 請只組合路徑，不要建立資料夾或寫入檔案
    raise NotImplementedError("請完成 get_party_record_path")


def main() -> None:
    print(get_party_record_path(Path("data"), "party.txt"))


if __name__ == "__main__":
    main()

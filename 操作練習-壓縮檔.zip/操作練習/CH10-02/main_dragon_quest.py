from pathlib import Path


def read_party_names(record_path: Path) -> list[str]:
    # 請依課文規則讀取並整理隊伍名單
    raise NotImplementedError("請完成 read_party_names")


def main() -> None:
    print(read_party_names(Path("party_names.txt")))


if __name__ == "__main__":
    main()

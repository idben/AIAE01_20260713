from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import read_order_ids


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_read_order_ids() -> bool:
    cases = [
        (" ORD-1001 \n\nORD-1002\n ORD-1003 \n", ["ORD-1001", "ORD-1002", "ORD-1003"], "含空行與前後空白的訂單編號檔"),
        ("\nEC-2001\n EC-2002 \n\nEC-2003\n", ["EC-2001", "EC-2002", "EC-2003"], "不同前綴的訂單編號檔"),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "order_ids.txt"
            path.write_text(content, encoding="utf-8")
            actual = read_order_ids(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_read_order_ids()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

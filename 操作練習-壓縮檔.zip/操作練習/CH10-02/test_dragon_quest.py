from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_dragon_quest import read_party_names


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_read_party_names() -> bool:
    cases = [
        ("勇者\n\n 僧侶 \n魔法使\n", ["勇者", "僧侶", "魔法使"], "含空行與前後空白的隊伍名單"),
        ("\n 戰士 \n\n 武鬥家\n 賢者 \n", ["戰士", "武鬥家", "賢者"], "開頭有空行的隊伍名單"),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "party_names.txt"
            path.write_text(content, encoding="utf-8")
            actual = read_party_names(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_read_party_names()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

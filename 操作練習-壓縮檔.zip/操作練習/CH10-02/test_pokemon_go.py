from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_pokemon_go import read_spawn_names


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_read_spawn_names() -> bool:
    cases = [
        ("皮卡丘\n\n 伊布 \n皮卡丘\n卡比獸\n 伊布 \n", ["皮卡丘", "伊布", "卡比獸"], "含空行、前後空白與重複名稱"),
        ("\n妙蛙種子\n 小火龍 \n妙蛙種子\n傑尼龜\n", ["妙蛙種子", "小火龍", "傑尼龜"], "重複名稱出現在清單中段"),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "spawn_names.txt"
            path.write_text(content, encoding="utf-8")
            actual = read_spawn_names(path)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_read_spawn_names()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

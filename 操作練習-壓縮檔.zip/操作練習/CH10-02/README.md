# CH10-02 練習

## 題目

練習讀取文字檔，清掉空白與空行。

- 《勇者鬥惡龍》版：讀取隊伍成員名稱。
- 《寶可夢 GO》版：讀取附近出現名稱，並保留第一次出現的名稱。
- 電子商務版：讀取訂單編號。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

名稱對照：

- `read_party_names`：讀取隊伍成員名稱
- `read_spawn_names`：讀取附近出現名稱
- `read_order_ids`：讀取訂單編號
- `record_path`：紀錄檔路徑

讀取檔案時使用 `encoding="utf-8"`。每一行先用 `strip()` 清掉前後空白與換行，空字串不要放進結果清單。《寶可夢 GO》版遇到重複名稱時，只保留第一次出現的名稱。

操作順序：

- 《勇者鬥惡龍》：清理中文隊伍名稱。
- 《寶可夢 GO》：清理附近出現名稱，並去除重複。
- 電子商務：清理訂單編號，完成後，再把訂單編號接到前綴過濾與欄位統計。

## 常見錯誤

- 忘記清掉換行字元。
- 把空行也加入清單。
- 沒有回傳清單，只印出結果。

## 你會練到什麼

- `with open(...)`
- `readlines()` 或逐行讀取
- 字串清理

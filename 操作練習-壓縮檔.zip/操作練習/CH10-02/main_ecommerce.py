from pathlib import Path


def read_order_ids(record_path: Path) -> list[str]:
    # 請依課文規則讀取並整理訂單編號
    raise NotImplementedError("請完成 read_order_ids")


def main() -> None:
    print(read_order_ids(Path("order_ids.txt")))


if __name__ == "__main__":
    main()

from pathlib import Path


def read_spawn_names(record_path: Path) -> list[str]:
    # 請依課文規則讀取並整理附近出現名單
    raise NotImplementedError("請完成 read_spawn_names")


def main() -> None:
    print(read_spawn_names(Path("spawn_names.txt")))


if __name__ == "__main__":
    main()

# CH9-03 練習

## 你要完成的事

使用 `@decorator_name` 語法完成自己的裝飾器。

建議完成順序：

- 《勇者鬥惡龍》：用 `@` 包住單一防禦行動，先確認基本語法。
- 《寶可夢 GO》：把同一個裝飾器套到兩個探索行動，並把結果整理成探索紀錄。
- 電子商務：包住回傳清單的批次查詢，並整理成批次摘要。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 操作步驟

1. 先觀察原函式本來要回傳什麼。
2. 再完成裝飾器，讓 `@decorator_name` 可以包住原函式。
3. 呼叫被 `@` 包住的函式時，確認它會先進入包裝層，再取得原本結果。

## 題目提示

### 《勇者鬥惡龍》版

先觀察 `guard_with_shield()`。它負責產生防禦訊息，`log_guard_action()` 只負責把這個行動包起來。

### 《寶可夢 GO》版

先觀察 `scan_nearby_spawn()` 和 `check_route_bonus()`。兩個探索行動都被同一個 `@record_exploration_action` 包住。原函式回傳文字，包裝後要回傳探索紀錄字典，包含 `category` 和 `message`。

探索紀錄規則：

- `category` 固定放「探索」。
- `message` 放原函式回傳的文字。
- 兩個探索函式都要套用同一個規則。

### 電子商務版

先觀察 `list_orders_waiting_payment()`。它回傳的是等待付款的訂單編號清單，`summarize_batch_action()` 要回傳批次摘要字典，包含 `orders` 和 `order_count`。

批次摘要規則：

- `orders` 放原本的訂單清單，內容與順序都不要改。
- `order_count` 放清單中的訂單數量。

## 檢查順序

1. `@log_guard_action`、`@record_exploration_action` 或 `@summarize_batch_action` 是否放在正確函式上方。
2. 裝飾器是否收到原函式。
3. `wrapper` 是否呼叫原函式並回傳結果。
4. 勇者版是否原樣回傳字串。
5. 寶可夢版是否回傳探索紀錄字典。
6. 電子商務版是否回傳批次摘要字典。

## 常見卡住點

- 裝飾器沒有回傳 `wrapper`。
- `wrapper` 沒有呼叫原函式。
- 寶可夢版只回傳原本字串，沒有整理成探索紀錄。
- 電子商務版只回傳原本清單，沒有整理成批次摘要。

## 做完你會練到

- `@` 語法。
- 手動包裝與裝飾器語法的關係。

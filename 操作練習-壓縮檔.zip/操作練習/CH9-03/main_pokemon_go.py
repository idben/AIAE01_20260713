def record_exploration_action(original_function):
    # 請建立 wrapper 並回傳，wrapper 要把原函式回傳的文字整理成探索紀錄字典
    raise NotImplementedError("請完成 record_exploration_action")


@record_exploration_action
def scan_nearby_spawn() -> str:
    return "附近出現 小火龍，距離 200 公尺"


@record_exploration_action
def check_route_bonus() -> str:
    return "目前路線獎勵：夥伴糖果加倍"


if __name__ == "__main__":
    print(scan_nearby_spawn())
    print(check_route_bonus())

def log_guard_action(original_function):
    # 請建立 wrapper 並回傳，wrapper 要回傳原函式結果
    raise NotImplementedError("請完成 log_guard_action")


@log_guard_action
def guard_with_shield() -> str:
    return "戰士舉起盾牌，承受下一次攻擊"


if __name__ == "__main__":
    print(guard_with_shield())

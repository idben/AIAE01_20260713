import subprocess
import sys

from pathlib import Path

from main_pokemon_go import check_route_bonus, scan_nearby_spawn

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_exploration_actions() -> bool:
    print("---------------------------------")
    actual = scan_nearby_spawn()
    expected = {"category": "探索", "message": "附近出現 小火龍，距離 200 公尺"}
    print("輸入：呼叫被裝飾的 scan_nearby_spawn")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_second_exploration_action() -> bool:
    print("---------------------------------")
    actual = check_route_bonus()
    expected = {"category": "探索", "message": "目前路線獎勵：夥伴糖果加倍"}
    print("輸入：呼叫同一個裝飾器包住的 check_route_bonus")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_exploration_actions(), test_second_exploration_action()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

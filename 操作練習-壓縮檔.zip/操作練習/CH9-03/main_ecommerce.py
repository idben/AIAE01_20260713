def summarize_batch_action(original_function):
    # 請建立 wrapper 並回傳，wrapper 要把原函式回傳的清單整理成批次摘要字典
    raise NotImplementedError("請完成 summarize_batch_action")


@summarize_batch_action
def list_orders_waiting_payment() -> list[str]:
    return ["A1001", "A1002", "A1005"]


if __name__ == "__main__":
    print(list_orders_waiting_payment())

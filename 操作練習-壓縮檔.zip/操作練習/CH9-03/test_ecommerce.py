import subprocess
import sys

from pathlib import Path

from main_ecommerce import list_orders_waiting_payment, summarize_batch_action

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_list_orders_waiting_payment() -> bool:
    print("---------------------------------")
    actual = list_orders_waiting_payment()
    expected = {"orders": ["A1001", "A1002", "A1005"], "order_count": 3}
    print("輸入：呼叫被裝飾的 list_orders_waiting_payment")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_summarize_batch_action_can_wrap_another_list_function() -> bool:
    print("---------------------------------")

    @summarize_batch_action
    def list_orders_ready_to_ship() -> list[str]:
        return ["A1003", "A1004"]

    actual = list_orders_ready_to_ship()
    expected = {"orders": ["A1003", "A1004"], "order_count": 2}
    print("輸入：用 summarize_batch_action 裝飾另一個回傳清單的函式")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_list_orders_waiting_payment(), test_summarize_batch_action_can_wrap_another_list_function()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

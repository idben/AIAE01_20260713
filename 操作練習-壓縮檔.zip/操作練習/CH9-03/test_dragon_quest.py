import subprocess
import sys

from pathlib import Path

from main_dragon_quest import guard_with_shield, log_guard_action

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_guard_with_shield() -> bool:
    print("---------------------------------")
    actual = guard_with_shield()
    expected = "戰士舉起盾牌，承受下一次攻擊"
    print("輸入：呼叫被裝飾的 guard_with_shield")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def test_log_guard_action_can_wrap_another_function() -> bool:
    print("---------------------------------")

    @log_guard_action
    def brace_for_magic() -> str:
        return "魔法師集中精神，準備承受咒文"

    actual = brace_for_magic()
    expected = "魔法師集中精神，準備承受咒文"
    print("輸入：用 log_guard_action 裝飾另一個防禦函式")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_guard_with_shield(), test_log_guard_action_can_wrap_another_function()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

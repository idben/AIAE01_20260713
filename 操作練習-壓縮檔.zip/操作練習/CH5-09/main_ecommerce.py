class DeliveryVehicle:
    def __init__(self, cruise_speed: int, order_efficiency: int) -> None:
        pass

    def get_trip_cost(self, distance: int, fee_rate: int) -> float:
        pass

    def get_cargo_volume(self) -> float | None:
        pass


class HeavyTruck(DeliveryVehicle):
    def __init__(self, cruise_speed: int, order_efficiency: int, pallet_weight: int, floor_area: int) -> None:
        pass

    def get_trip_cost(self, distance: int, fee_rate: int) -> float:
        pass

    def get_cargo_volume(self) -> float:
        pass


class BoxVan(DeliveryVehicle):
    def __init__(self, cruise_speed: int, order_efficiency: int, shelf_capacity: int) -> None:
        pass

    def get_cargo_volume(self) -> int:
        pass

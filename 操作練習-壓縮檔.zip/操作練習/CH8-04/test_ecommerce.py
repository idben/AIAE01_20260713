import subprocess
import sys

from pathlib import Path

from main_ecommerce import estimate_shipping_boxes


TestCase = tuple[int, int, int, int]

test_cases: list[TestCase] = [
    (10, 4, 0, 3),
    (10, 4, 2, 4),
    (3, 5, 1, 2),
]

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_shipping_boxes(
    item_count: int,
    items_per_box: int,
    fragile_count: int,
    expected: int,
) -> bool:
    print("---------------------------------")
    actual = estimate_shipping_boxes(item_count, items_per_box, fragile_count)
    print(f"輸入：商品 {item_count} 件，每箱 {items_per_box} 件，易碎 {fragile_count} 件")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_shipping_boxes(*case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

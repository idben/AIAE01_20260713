import math


def estimate_shipping_boxes(
    item_count: int,
    items_per_box: int,
    fragile_count: int,
) -> int:
    # 請估算出貨箱數，易碎商品每件要獨立一箱
    pass

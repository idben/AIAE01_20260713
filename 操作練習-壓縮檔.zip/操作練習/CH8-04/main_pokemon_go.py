import math


def calculate_spawn_distance(
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    max_visible_distance: int,
) -> int | None:
    # 請計算玩家與出現點的直線距離；超出可見距離時回傳 None
    pass

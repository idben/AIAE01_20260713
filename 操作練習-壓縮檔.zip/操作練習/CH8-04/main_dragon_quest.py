import math


def calculate_map_distance(x1: int, y1: int, x2: int, y2: int) -> int:
    # 請計算兩個地圖座標的直線距離，並回傳進位後的整數
    pass

import subprocess
import sys

from pathlib import Path

from main_dragon_quest import calculate_map_distance


TestCase = tuple[int, int, int, int, int]

test_cases: list[TestCase] = [
    (0, 0, 3, 4, 5),
    (1, 1, 4, 5, 5),
    (0, 0, 2, 2, 3),
]

def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_distance(x1: int, y1: int, x2: int, y2: int, expected: int) -> bool:
    print("---------------------------------")
    actual = calculate_map_distance(x1, y1, x2, y2)
    print(f"輸入：({x1}, {y1}), ({x2}, {y2})")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    results = [test_distance(*case) for case in test_cases]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

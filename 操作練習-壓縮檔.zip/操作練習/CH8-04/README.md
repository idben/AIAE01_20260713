# CH8-04 練習

## 題目

練習使用 `math` 計算座標距離，並把距離進位成整數。

- 《勇者鬥惡龍》版：計算城鎮到怪物位置的距離
- 《寶可夢 GO》版：計算玩家到附近出現點的距離
- 電子商務版：估算出貨需要幾個箱子

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 難度安排

- 《勇者鬥惡龍》：用座標計算距離後進位。
- 《寶可夢 GO》：估算附近出現點距離，並在超出可見距離時回傳 `None`。
- 電子商務：改成包裝規則，普通商品要依每箱容量進位，易碎商品要獨立裝箱。

## 操作步驟

1. 先觀察函式收到兩個座標。
2. 分別算出 x 方向與 y 方向的差距。
3. 用平方根計算直線距離。
4. 因為距離不能低估，最後回傳進位後的整數。
5. 寶可夢版還要判斷進位後距離是否超過可見距離。

## 題目提示

《勇者鬥惡龍》版：

- `calculate_map_distance(x1, y1, x2, y2)` 收到地圖上的兩點。
- 回傳值代表移動或遭遇判斷用的格數。

《寶可夢 GO》版：

- `calculate_spawn_distance(x1, y1, x2, y2, max_visible_distance)` 收到玩家位置、出現點位置與可見距離上限。
- 回傳值代表附近清單可以使用的估算距離。
- 如果進位後距離大於 `max_visible_distance`，回傳 `None`。

電子商務版：

- `estimate_shipping_boxes(item_count, items_per_box, fragile_count)` 收到總商品數、每箱可放數量與易碎商品數。
- 易碎商品每件要獨立一箱。
- 非易碎商品才依照每箱容量進位估算。

## 檢查順序

1. x 和 y 的差距是否都有用到。
2. 是否用平方根處理斜線距離。
3. 是否進位，避免低估距離。
4. 寶可夢版是否在超出可見距離時回傳 `None`。
5. 電子商務版是否先扣除易碎商品，再估算一般商品箱數。

## 常見錯誤

- 只計算 x 距離或 y 距離。
- 忘記平方後再相加。
- 回傳小數，沒有進位。
- 電子商務版把易碎商品也塞進一般商品箱數，少算了箱子。

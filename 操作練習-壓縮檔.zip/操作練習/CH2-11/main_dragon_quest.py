class PartyMember:
    hp: int = 20

    def __init__(self, name: str, hp: int) -> None:
        return

    def get_status(self) -> tuple[str, int]:
        return self.name, self.hp

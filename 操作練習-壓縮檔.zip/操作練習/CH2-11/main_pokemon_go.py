class Encounter:
    poke_balls: int = 5

    def __init__(self, pokemon_name: str, poke_balls: int) -> None:
        return

    def get_status(self) -> tuple[str, int]:
        return self.pokemon_name, self.poke_balls

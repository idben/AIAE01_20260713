# CH10-08 練習

## 題目

練習用產生器逐行處理文字檔。

- 《勇者鬥惡龍》版：逐筆產生有效怪物名稱。
- 《寶可夢 GO》版：逐筆產生第一次出現的有效附近出現名稱。
- 電子商務版：逐筆產生符合指定前綴的訂單編號。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `monster_names.txt`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `spawn_names.txt`
- `main_ecommerce.py`
- `test_ecommerce.py`
- `order_ids.txt`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

先打開文字檔觀察空白行、重複資料、備註行或前綴，再寫對應的產生器函式。`main_dragon_quest.py`、`main_pokemon_go.py` 和 `main_ecommerce.py` 會使用這些文字檔，測試檔則會另外準備更多資料檢查你的函式。

名稱對照：

- `iter_valid_monster_names`：逐筆產生有效怪物名稱
- `iter_valid_spawn_names`：逐筆產生有效附近出現名稱
- `iter_valid_order_ids`：逐筆產生有效訂單編號
- `record_path`：紀錄檔路徑
- `monster_name` / `spawn_name`：每次讀到並清理好的單筆名稱
- `prefix`：有效訂單編號必須符合的前綴

這一節的重點是 `yield`。不要先把所有資料放進清單再 `return`，而是每找到一筆有效資料，就直接 `yield` 那一筆。空白行不要產生出來。《勇者鬥惡龍》版遇到 `#` 開頭的備註行時，也不要產生出來。《寶可夢 GO》版遇到重複名稱時，只產生第一次出現的名稱。

電子商務版除了略過空白行，還要檢查訂單編號是否以 `prefix` 開頭。

操作順序：

- 《勇者鬥惡龍》：逐筆產生有效怪物名稱，略過空白行與備註行。
- 《寶可夢 GO》：逐筆產生有效附近出現名稱，並略過重複名稱。
- 電子商務：逐筆產生有效訂單編號，還要套用前綴規則。

## 常見錯誤

- 回傳完整清單，而不是逐筆 `yield`。
- 在迴圈中太早 `return`，導致後面的行都沒有處理。
- 忘記清掉前後空白。
- 把空行也產生出來。
- 把 `#` 開頭的備註行當成怪物名稱。

## 你會練到什麼

- `for line in file`
- 產生器 (Generator)
- 逐行資料處理

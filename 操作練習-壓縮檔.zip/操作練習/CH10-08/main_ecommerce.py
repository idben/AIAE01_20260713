from pathlib import Path
from typing import Iterator


def iter_valid_order_ids(record_path: Path, prefix: str) -> Iterator[str]:
    # 請依課文規則逐筆產生訂單編號
    raise NotImplementedError("請完成 iter_valid_order_ids")


def main() -> None:
    for order_id in iter_valid_order_ids(Path("order_ids.txt"), "ORD-"):
        print(order_id)


if __name__ == "__main__":
    main()

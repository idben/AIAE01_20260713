from pathlib import Path
from typing import Iterator


def iter_valid_monster_names(record_path: Path) -> Iterator[str]:
    # 請依課文規則逐筆產生怪物名稱
    raise NotImplementedError("請完成 iter_valid_monster_names")


def main() -> None:
    for monster_name in iter_valid_monster_names(Path("monster_names.txt")):
        print(monster_name)


if __name__ == "__main__":
    main()

from pathlib import Path
from tempfile import TemporaryDirectory
from types import GeneratorType
import subprocess
import sys

from main_ecommerce import iter_valid_order_ids


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_iter_valid_order_ids() -> bool:
    cases = [
        ("ORD-1001\n\n BAD-1 \n ORD-1002 \nINV-9\n", "ORD-", ["ORD-1001", "ORD-1002"], "含空行與其他前綴的訂單編號檔"),
        ("EC-2001\n ORD-9 \n EC-2002 \n\nBAD-2\n", "EC-", ["EC-2001", "EC-2002"], "使用不同前綴的訂單編號檔"),
    ]
    all_passed = True
    for content, prefix, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "order_ids.txt"
            path.write_text(content, encoding="utf-8")
            iterator = iter_valid_order_ids(path, prefix)
            is_generator = isinstance(iterator, GeneratorType)
            actual = list(iterator)
        print(f"輸入：{description}，prefix={prefix}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        print(f"是否為產生器：{is_generator}")
        if actual == expected and is_generator:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_iter_valid_order_ids()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

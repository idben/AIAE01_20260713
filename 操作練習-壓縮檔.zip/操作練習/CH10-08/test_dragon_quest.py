from pathlib import Path
from tempfile import TemporaryDirectory
from types import GeneratorType
import subprocess
import sys

from main_dragon_quest import iter_valid_monster_names


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_iter_valid_monster_names() -> bool:
    cases = [
        ("史萊姆\n\n # 稀有怪區 \n 龍 \n金屬史萊姆\n", ["史萊姆", "龍", "金屬史萊姆"], "含空行、註解行與前後空白的怪物名稱檔"),
        ("\n 哥布林 \n# 夜間出現\n奇美拉\n\n 惡魔騎士 \n", ["哥布林", "奇美拉", "惡魔騎士"], "含註解行的怪物名稱檔"),
    ]
    all_passed = True
    for content, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "monster_names.txt"
            path.write_text(content, encoding="utf-8")
            iterator = iter_valid_monster_names(path)
            is_generator = isinstance(iterator, GeneratorType)
            actual = list(iterator)
        print(f"輸入：{description}")
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        print(f"是否為產生器：{is_generator}")
        if actual == expected and is_generator:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_iter_valid_monster_names()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

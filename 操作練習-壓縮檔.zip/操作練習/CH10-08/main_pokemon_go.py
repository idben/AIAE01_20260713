from pathlib import Path
from typing import Iterator


def iter_valid_spawn_names(record_path: Path) -> Iterator[str]:
    # 請依課文規則逐筆產生附近出現名稱
    raise NotImplementedError("請完成 iter_valid_spawn_names")


def main() -> None:
    for spawn_name in iter_valid_spawn_names(Path("spawn_names.txt")):
        print(spawn_name)


if __name__ == "__main__":
    main()

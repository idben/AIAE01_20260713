class RaidPokemon:
    def __init__(self, name: str, stamina: int, charge_skill: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__charge_skill = charge_skill
        self.energy = self.__charge_skill * 10
        self.hp = self.__stamina * 100

    def take_charged_hit(self, charged_damage: int) -> None:
        pass

    def use_energy_booster(self, booster_energy: int) -> None:
        pass

import subprocess
import sys
from pathlib import Path

from main_dragon_quest import SpellCaster

TestCase = dict[str, int | str]

run_cases: list[TestCase] = [
    {
        "caster_name": "勇者",
        "caster_stamina": 10,
        "caster_wisdom": 10,
        "fireball_damage": 30,
        "potion_mp": 20,
        "expected_hp_after": 980,
        "expected_mp_after": 130,
    },
    {
        "caster_name": "魔法使",
        "caster_stamina": 20,
        "caster_wisdom": 5,
        "fireball_damage": 75,
        "potion_mp": 25,
        "expected_hp_after": 1945,
        "expected_mp_after": 80,
    },
]

submit_cases: list[TestCase] = run_cases + [
    {
        "caster_name": "賢者",
        "caster_stamina": 100,
        "caster_wisdom": 500,
        "fireball_damage": 150,
        "potion_mp": 250,
        "expected_hp_after": 9950,
        "expected_mp_after": 5750,
    },
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(case: TestCase) -> bool:
    print("---------------------------------")
    caster = SpellCaster(
        str(case["caster_name"]),
        int(case["caster_stamina"]),
        int(case["caster_wisdom"]),
    )
    print(
        f"SpellCaster({case['caster_name']}, {case['caster_stamina']}, {case['caster_wisdom']})"
    )
    print(f"  起始 hp：{caster.hp}")
    print(f"  起始 mp：{caster.mp}")
    print("")
    print(
        f"  吃到 {case['fireball_damage']} 點火球傷害，耐力為 {case['caster_stamina']}..."
    )
    print(
        f"  喝下 {case['potion_mp']} 點 mp 藥水，智慧為 {case['caster_wisdom']}..."
    )
    caster.get_fireballed(int(case["fireball_damage"]))
    caster.drink_mp_potion(int(case["potion_mp"]))
    print("")
    print(f"  預期 hp：{case['expected_hp_after']}")
    print(f"  實際 hp：{caster.hp}")
    print(f"  預期 mp：{case['expected_mp_after']}")
    print(f"  實際 mp：{caster.mp}")
    passed = caster.hp == case["expected_hp_after"] and caster.mp == case["expected_mp_after"]
    if passed:
        print("通過")
    else:
        print("失敗")
    return passed


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

import subprocess
import sys
from pathlib import Path

from main_pokemon_go import RaidPokemon

TestCase = dict[str, int | str]

run_cases: list[TestCase] = [
    {
        "pokemon_name": "Pikachu",
        "pokemon_stamina": 10,
        "pokemon_charge_skill": 10,
        "charged_damage": 30,
        "booster_energy": 20,
        "expected_hp_after": 980,
        "expected_energy_after": 130,
    },
    {
        "pokemon_name": "Snorlax",
        "pokemon_stamina": 20,
        "pokemon_charge_skill": 5,
        "charged_damage": 75,
        "booster_energy": 25,
        "expected_hp_after": 1945,
        "expected_energy_after": 80,
    },
]

submit_cases: list[TestCase] = run_cases + [
    {
        "pokemon_name": "Blissey",
        "pokemon_stamina": 100,
        "pokemon_charge_skill": 500,
        "charged_damage": 150,
        "booster_energy": 250,
        "expected_hp_after": 9950,
        "expected_energy_after": 5750,
    },
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(case: TestCase) -> bool:
    print("---------------------------------")
    pokemon = RaidPokemon(
        str(case["pokemon_name"]),
        int(case["pokemon_stamina"]),
        int(case["pokemon_charge_skill"]),
    )
    print(
        f"RaidPokemon({case['pokemon_name']}, {case['pokemon_stamina']}, {case['pokemon_charge_skill']})"
    )
    print(f"  起始 hp：{pokemon.hp}")
    print(f"  起始能量：{pokemon.energy}")
    print("")
    print(
        f"  吃到 {case['charged_damage']} 點蓄力招式傷害，耐久為 {case['pokemon_stamina']}..."
    )
    print(
        f"  使用 {case['booster_energy']} 點能量補充，熟練為 {case['pokemon_charge_skill']}..."
    )
    pokemon.take_charged_hit(int(case["charged_damage"]))
    pokemon.use_energy_booster(int(case["booster_energy"]))
    print("")
    print(f"  預期 hp：{case['expected_hp_after']}")
    print(f"  實際 hp：{pokemon.hp}")
    print(f"  預期能量：{case['expected_energy_after']}")
    print(f"  實際能量：{pokemon.energy}")
    passed = (
        pokemon.hp == case["expected_hp_after"]
        and pokemon.energy == case["expected_energy_after"]
    )
    if passed:
        print("通過")
    else:
        print("失敗")
    return passed


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

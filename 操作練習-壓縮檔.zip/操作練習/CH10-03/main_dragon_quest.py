from pathlib import Path


def write_battle_log(log_path: Path, messages: list[str]) -> None:
    # 請依課文規則寫入戰鬥紀錄
    raise NotImplementedError("請完成 write_battle_log")


def main() -> None:
    write_battle_log(Path("records") / "battle_log.txt", ["勇者攻擊史萊姆"])


if __name__ == "__main__":
    main()

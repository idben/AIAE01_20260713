from pathlib import Path


def append_catch_log(log_path: Path, message: str) -> None:
    # 請依課文規則寫入捕捉紀錄
    raise NotImplementedError("請完成 append_catch_log")


def main() -> None:
    append_catch_log(Path("records") / "catch_log.txt", "捕捉 皮卡丘 成功")


if __name__ == "__main__":
    main()

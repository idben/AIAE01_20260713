from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_pokemon_go import append_catch_log


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_append_catch_log() -> bool:
    cases = [
        (["捕捉 皮卡丘 成功", "捕捉 伊布 失敗"], "捕捉 皮卡丘 成功\n捕捉 伊布 失敗\n", "兩次捕捉訊息"),
        (["遇見 卡比獸", "捕捉 卡比獸 成功", "獲得糖果"], "遇見 卡比獸\n捕捉 卡比獸 成功\n獲得糖果\n", "三次捕捉事件"),
    ]
    all_passed = True
    for messages, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "records" / "catch_log.txt"
            for message in messages:
                append_catch_log(path, message)
            actual = path.read_text(encoding="utf-8")
        print(f"輸入：{description}")
        print(f"預期：{expected!r}")
        print(f"實際：{actual!r}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_append_catch_log()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

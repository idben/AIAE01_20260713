# CH10-03 練習

## 題目

練習寫入與附加文字檔。

- 《勇者鬥惡龍》版：重新寫出戰鬥紀錄。
- 《寶可夢 GO》版：附加捕捉紀錄。
- 電子商務版：附加訂單狀態紀錄。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 題目提示

名稱對照：

- `write_battle_log`：寫出戰鬥紀錄
- `append_catch_log`：附加捕捉紀錄
- `log_path`：紀錄檔路徑
- `messages`：多則戰鬥訊息
- `message`：單則捕捉訊息
- `order_id`：訂單編號
- `status`：訂單狀態
- `total`：訂單金額

寫檔前要建立父資料夾。`write_battle_log()` 使用覆蓋寫入；`append_catch_log()` 使用附加寫入。

電子商務版的 `append_order_log(log_path, order_id, status, total)` 也使用附加寫入，但一筆紀錄要組合三個欄位，格式固定為 `訂單編號,狀態,金額`。

操作順序：

- 《勇者鬥惡龍》：一次覆蓋寫入多行。
- 《寶可夢 GO》：多次呼叫附加單行。
- 電子商務：附加單行時要先組合多欄位紀錄。

## 常見錯誤

- 忘記在每一行後面加換行。
- 沒有建立父資料夾。
- 把附加模式寫成覆蓋模式。

## 你會練到什麼

- 寫入模式 `"w"`
- 附加模式 `"a"`
- 父資料夾建立

from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_dragon_quest import write_battle_log


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_write_battle_log() -> bool:
    cases = [
        (["勇者攻擊史萊姆", "史萊姆掉落藥草"], "勇者攻擊史萊姆\n史萊姆掉落藥草\n", "兩則戰鬥訊息"),
        (["戰士防禦", "魔法使施放基拉", "龍受到傷害"], "戰士防禦\n魔法使施放基拉\n龍受到傷害\n", "三則戰鬥訊息"),
    ]
    all_passed = True
    for messages, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "records" / "battle_log.txt"
            path.parent.mkdir(parents=True)
            path.write_text("舊紀錄\n", encoding="utf-8")
            write_battle_log(path, messages)
            actual = path.read_text(encoding="utf-8")
        print(f"輸入：{description}")
        print(f"預期：{expected!r}")
        print(f"實際：{actual!r}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_write_battle_log()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

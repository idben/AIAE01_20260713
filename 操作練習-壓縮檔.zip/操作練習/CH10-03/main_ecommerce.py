from pathlib import Path


def append_order_log(log_path: Path, order_id: str, status: str, total: int) -> None:
    # 請依課文規則寫入訂單紀錄
    raise NotImplementedError("請完成 append_order_log")


def main() -> None:
    append_order_log(Path("records") / "order_log.txt", "ORD-1001", "已付款", 1200)


if __name__ == "__main__":
    main()

from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

from main_ecommerce import append_order_log


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin" and sound_path.exists():
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            print("\\a", end="")
    except Exception:
        print("\\a", end="")


def test_append_order_log() -> bool:
    cases = [
        ([("ORD-1001", "已付款", 1200), ("ORD-1002", "待處理", 850)], "ORD-1001,已付款,1200\nORD-1002,待處理,850\n", "兩筆訂單狀態紀錄"),
        ([("EC-2001", "已出貨", 1500), ("EC-2002", "取消", 300), ("EC-2003", "已付款", 990)], "EC-2001,已出貨,1500\nEC-2002,取消,300\nEC-2003,已付款,990\n", "三筆不同狀態訂單"),
    ]
    all_passed = True
    for records, expected, description in cases:
        print("---------------------------------")
        with TemporaryDirectory() as folder:
            path = Path(folder) / "records" / "order_log.txt"
            for order_id, status, total in records:
                append_order_log(path, order_id, status, total)
            actual = path.read_text(encoding="utf-8")
        print(f"輸入：{description}")
        print(f"預期：{expected!r}")
        print(f"實際：{actual!r}")
        if actual == expected:
            print("通過")
        else:
            print("失敗")
            all_passed = False
    return all_passed


def main() -> None:
    results = [test_append_order_log()]
    passed = results.count(True)
    failed = results.count(False)
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

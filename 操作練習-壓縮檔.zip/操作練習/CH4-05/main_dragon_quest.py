import random

EncounterCard = tuple[str, str]


class AdventureDeck:
    REGIONS: list[str] = ["城鎮", "草原", "洞窟", "城堡"]
    RANKS: list[str] = [
        "史萊姆",
        "德拉奇",
        "幽靈",
        "魔法師",
        "蠍子",
        "狼",
        "魔像",
        "飛龍",
        "騎士",
        "龍",
        "頭目",
        "大惡魔",
        "龍王",
    ]

    # 以上內容不要修改

    def __init__(self) -> None:
        pass

    def create_deck(self) -> None:
        pass

    def shuffle_deck(self) -> None:
        pass

    def deal_card(self) -> EncounterCard | None:
        pass

    # 以下內容不要修改

    def __str__(self) -> str:
        return f"牌組剩下 {len(self.__cards)} 張事件卡"

import random

SpawnCard = tuple[str, str]


class FieldEventDeck:
    BIOMES: list[str] = ["公園", "城市", "河岸", "山區"]
    TIERS: list[str] = [
        "常見",
        "不常見",
        "稀有",
        "非常稀有",
        "巢穴",
        "誘餌",
        "暗影",
        "蛋",
        "田野調查",
        "火箭隊",
        "團體戰",
        "傳說",
        "幻之",
    ]

    # 以上內容不要修改

    def __init__(self) -> None:
        pass

    def create_deck(self) -> None:
        pass

    def shuffle_deck(self) -> None:
        pass

    def deal_card(self) -> SpawnCard | None:
        pass

    # 以下內容不要修改

    def __str__(self) -> str:
        return f"事件牌組剩下 {len(self.__cards)} 張卡"

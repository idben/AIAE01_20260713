def main() -> None:
    pass


# 以下內容不要修改


class PartyMember:
    def __init__(self, name: str, hp: int, mp: int) -> None:
        self.name = name
        self.hp = hp
        self.mp = mp
        self.support_power = hp + mp


def compare_party_members(first: PartyMember, second: PartyMember) -> None:
    print(f"{first.name}: {first.support_power} support")
    print(f"{second.name}: {second.support_power} support")
    if first.support_power > second.support_power:
        print(f"{first.name} wins!")
    elif first.support_power < second.support_power:
        print(f"{second.name} wins!")
    else:
        print("It's a tie!")
    print("---------------------------------")


main()

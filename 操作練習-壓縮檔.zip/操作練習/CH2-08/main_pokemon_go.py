def main() -> None:
    pass


# 以下內容不要修改


class PokemonSpawn:
    def __init__(self, name: str, cp: int, remaining_seconds: int) -> None:
        self.name = name
        self.cp = cp
        self.remaining_seconds = remaining_seconds
        self.spawn_priority = cp + remaining_seconds


def compare_spawns(first: PokemonSpawn, second: PokemonSpawn) -> None:
    print(f"{first.name}: {first.spawn_priority} priority")
    print(f"{second.name}: {second.spawn_priority} priority")
    if first.spawn_priority > second.spawn_priority:
        print(f"{first.name} first!")
    elif first.spawn_priority < second.spawn_priority:
        print(f"{second.name} first!")
    else:
        print("Same priority!")
    print("---------------------------------")


main()

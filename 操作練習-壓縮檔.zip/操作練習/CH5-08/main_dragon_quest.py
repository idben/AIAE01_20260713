class FormationRectangle:
    def __init__(self, length: int, width: int) -> None:
        pass

    def get_area(self) -> int:
        pass

    def get_perimeter(self) -> int:
        pass


class FormationSquare(FormationRectangle):
    def __init__(self, length: int) -> None:
        pass

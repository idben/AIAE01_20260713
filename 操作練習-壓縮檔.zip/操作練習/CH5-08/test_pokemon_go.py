import subprocess
import sys
from pathlib import Path

from main_pokemon_go import ScanZoneRectangle, ScanZoneSquare

ShapeArgs = tuple[int, ...]
TestCase = tuple[ShapeArgs, int, int]

run_cases: list[TestCase] = [
    ((2, 4), 8, 12),
    ((5,), 25, 20),
]

submit_cases: list[TestCase] = run_cases + [
    ((3, 4), 12, 14),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(inputs: ShapeArgs, expected_area: int, expected_perimeter: int) -> bool:
    print("---------------------------------")
    if len(inputs) == 2:
        shape = ScanZoneRectangle(*inputs)
    else:
        shape = ScanZoneSquare(inputs[0])
    actual_area = shape.get_area()
    actual_perimeter = shape.get_perimeter()
    print(f"預期面積：{expected_area}")
    print(f"實際面積：{actual_area}")
    print(f"預期周長：{expected_perimeter}")
    print(f"實際周長：{actual_perimeter}")
    return actual_area == expected_area and actual_perimeter == expected_perimeter


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

# CH5-08 練習

## 題目

這一課練習長方形與正方形的繼承。

- 《勇者鬥惡龍》版：完整完成 `FormationRectangle`（長方形陣型區塊）和 `FormationSquare`（正方形陣型區塊）
- 《寶可夢 GO》版：父類別 `ScanZoneRectangle`（長方形掃描區）已完成，補完 `ScanZoneSquare`（正方形掃描區）
- 電子商務版：檢查並修正 `DisplayRectangle`（長方形展示區）和 `DisplaySquare`（正方形展示區）中的錯誤

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 《勇者鬥惡龍》先從零完成父類別的長、寬、面積、周長，再補上正方形建構子。
2. 《寶可夢 GO》先看父類別公式已經怎麼寫，再補上子類別如何重用它。
3. 電子商務版先不要重寫全部，先檢查公式和 `super().__init__()` 哪裡不合理。
4. 三個版本都要守住同一個規格：正方形最後一定要讓長和寬相同。
5. 執行測試確認面積和周長都正確。

## 常見錯誤

- 面積或周長公式寫錯
- 子類別沒有呼叫父類別建構子
- 正方形沒有把長寬設成同一個值
- 看到除錯題就重寫整份，沒有先定位真正錯誤

## 這題在測什麼

- 繼承共用公式
- 子類別限制條件
- 實例變數初始化
- 同一組繼承規則在完整實作、補完題、除錯題中的不同用法

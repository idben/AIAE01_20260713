import subprocess
import sys
from pathlib import Path

from main_dragon_quest import BatteringRam, Catapult, Siege

TestCase = tuple[Siege, int, int, int, int | None]

run_cases: list[TestCase] = [
    (Siege(100, 10), 100, 4, 40, None),
    (BatteringRam(100, 10, 2000, 5), 100, 5, 70, 10),
]

submit_cases: list[TestCase] = run_cases + [
    (Catapult(90, 4, 3), 100, 10, 250, 3),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(["afplay", str(sound_path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def test(vehicle: Siege, distance: int, food_price: int, expected_cost: int, expected_cargo_volume: int | None) -> bool:
    print("---------------------------------")
    actual_cost = int(vehicle.get_trip_cost(distance, food_price))
    actual_volume = vehicle.get_cargo_volume()
    if actual_volume is not None:
        actual_volume = int(actual_volume)
    print(f"預期成本：{expected_cost}")
    print(f"實際成本：{actual_cost}")
    print(f"預期容量：{expected_cargo_volume}")
    print(f"實際容量：{actual_volume}")
    return actual_cost == expected_cost and actual_volume == expected_cargo_volume


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            print("通過")
            passed += 1
        else:
            print("失敗")
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

# CH5-10 練習

## 題目

這一課練習父類別共通公式與子類別差異。

- 《勇者鬥惡龍》版：完成 `Siege`、`BatteringRam`、`Catapult`
- 《寶可夢 GO》版：完成 `FieldTransport`、`ItemCarrier`、`EggShuttle`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先看父類別要記住什麼共通資料
2. 先完成父類別的共通成本公式
3. 再完成第一個子類別，讓它在父類別公式上加自己的額外成本
4. 最後完成第二個子類別，讓它直接沿用父類別公式
5. 執行測試確認成本與容量

## 常見錯誤

- 父類別公式寫錯
- 該用 `super().get_trip_cost()` 時沒有用
- 第二個子類別把 `cargo_volume` 存錯欄位名稱

## 這題在測什麼

- 父類別共通公式
- 子類別覆寫與直接繼承
- 回傳值計算

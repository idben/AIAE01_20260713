class Siege:
    def __init__(self, max_speed: int, efficiency: int) -> None:
        pass

    def get_trip_cost(self, distance: int, food_price: int) -> float:
        pass

    def get_cargo_volume(self) -> float | None:
        pass


class BatteringRam(Siege):
    def __init__(self, max_speed: int, efficiency: int, load_weight: int, bed_area: int) -> None:
        pass

    def get_trip_cost(self, distance: int, food_price: int) -> float:
        pass

    def get_cargo_volume(self) -> float:
        pass


class Catapult(Siege):
    def __init__(self, max_speed: int, efficiency: int, cargo_volume: int) -> None:
        pass

    def get_cargo_volume(self) -> int:
        pass

class DisplayRectangle:
    def __init__(self, length: int, width: int) -> None:
        self.length = length
        self.width = width

    def get_area(self) -> int:
        return self.length + self.width

    def get_perimeter(self) -> int:
        return self.length * self.width


class DisplaySquare(DisplayRectangle):
    def __init__(self, length: int) -> None:
        super().__init__(length, 0)

class RaidPokemon:
    def __init__(self, name: str, stamina: int, charge_skill: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__charge_skill = charge_skill
        self.energy = self.__charge_skill * 10
        self.hp = self.__stamina * 100

    # 以上不能編輯

    def use_charged_move(
        self, target: "RaidPokemon", energy_cost: int, move_damage: int
    ) -> None:
        pass

    def is_battle_ready(self) -> bool:
        pass

    # 以下不能編輯

    def take_charged_hit(self, move_damage: int) -> None:
        move_damage -= self.__stamina
        self.hp -= move_damage

    def use_energy_booster(self, booster_energy: int) -> None:
        booster_energy += self.__charge_skill
        self.energy += booster_energy

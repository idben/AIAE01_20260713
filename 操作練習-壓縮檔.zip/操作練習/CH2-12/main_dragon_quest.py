class Item:
    def __init__(self, name: str, price: int) -> None:
        pass


class Shop:
    def __init__(self, name: str) -> None:
        pass

    def add_item(self, item: Item) -> None:
        pass

    def remove_item(self, item: Item) -> None:
        pass

    def search_items(self, search_string: str) -> list[Item]:
        pass

# CH2-12 練習

## 題目

這一課把整章觀念綜合起來：設計一個表示單筆資料的類別，和一個管理資料集合的類別。

- 《勇者鬥惡龍》版：完成 `Item` 與 `Shop`
- 《寶可夢 GO》版：完成 `CaughtPokemon` 與 `CollectionBox`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成資料類別與管理類別
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- `Item` 是單一商品資料，應該記住名稱和價格
- `Shop` 是商品集合，應該記住商店名稱，並準備一個列表保存商品
- `Item` 要有 `name` 和 `price`
- `Shop` 要能新增、移除與搜尋商品
- 搜尋時要不分大小寫

### 《寶可夢 GO》版

- `CaughtPokemon` 是單一已捕捉寶可夢資料，應該記住名稱和 CP
- `CollectionBox` 是收藏集合，應該記住持有者名稱，並準備一個列表保存已捕捉寶可夢
- `CaughtPokemon` 要有 `name` 和 `cp`
- `CollectionBox` 要能新增、移除與搜尋已捕捉寶可夢
- 搜尋時要不分大小寫

## 這題常見錯誤

- 移除時只比對一個欄位
- 邊迴圈邊直接刪除列表元素
- 搜尋沒有做大小寫轉換

## 這題在測什麼

- 類別初始化是否正確
- 是否能管理資料清單
- 是否能安全移除與搜尋資料

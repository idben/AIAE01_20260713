import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Item, Shop

TestCase = tuple[str, list[str], list[int], Item, str, list[str]]

run_cases: list[TestCase] = [
    (
        "拉達托姆商店",
        ["藥草"],
        [8],
        Item("藥草", 8),
        "藥",
        [],
    ),
    (
        "梅爾基德商店",
        ["藥草", "聖水", "銅劍"],
        [8, 20, 180],
        Item("銅劍", 180),
        "水",
        ["聖水"],
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        "達姆達拉商店",
        ["藥草", "魔法鑰匙", "鐵甲", "翼"],
        [8, 85, 1000, 70],
        Item("藥草", 8),
        "甲",
        ["鐵甲"],
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    shop_name: str,
    item_names: list[str],
    item_prices: list[int],
    item_to_remove: Item,
    search_query: str,
    expected_search_results: list[str],
) -> bool:
    print("---------------------------------")
    try:
        shop = Shop(shop_name)
        for name, price in zip(item_names, item_prices):
            shop.add_item(Item(name, price))
            print(f"加入商品 {name}，價格 {price}")
        shop.remove_item(item_to_remove)
        results = shop.search_items(search_query)
        result_names = [item.name for item in results]
        print(f"預期：{expected_search_results}")
        print(f"實際：{result_names}")
        if result_names == expected_search_results:
            print("通過")
            return True
        print("失敗")
        return False
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

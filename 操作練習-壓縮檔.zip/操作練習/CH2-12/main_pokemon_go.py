class CaughtPokemon:
    def __init__(self, name: str, cp: int) -> None:
        pass


class CollectionBox:
    def __init__(self, owner_name: str) -> None:
        pass

    def add_pokemon(self, pokemon: CaughtPokemon) -> None:
        pass

    def remove_pokemon(self, pokemon: CaughtPokemon) -> None:
        pass

    def search_pokemon(self, search_string: str) -> list[CaughtPokemon]:
        pass

import subprocess
import sys
from pathlib import Path

from main_pokemon_go import Trainer, WildPokemon

TestCase = tuple[Trainer, WildPokemon, int, tuple[int, int] | None, str | None]

run_cases: list[TestCase] = [
    (
        Trainer("小智", 3),
        WildPokemon("Pikachu", 2),
        1,
        (2, 1),
        None,
    ),
    (
        Trainer("小霞", 0),
        WildPokemon("Psyduck", 2),
        1,
        None,
        "小霞 has no balls",
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        Trainer("小剛", 2),
        WildPokemon("Onix", 1),
        1,
        None,
        "Onix is caught",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    trainer: Trainer,
    target: WildPokemon,
    throws: int,
    expected_result: tuple[int, int] | None,
    expected_err: str | None,
) -> bool:
    print("---------------------------------")
    try:
        trainer.print_status()
        target.print_status()
        for _ in range(throws):
            trainer.throw_ball(target)
        if expected_err:
            print(f"失敗：預期要拋出 {expected_err}，但沒有發生例外")
            return False
        _, actual_balls = trainer.get_status()
        _, actual_points = target.get_status()
        assert expected_result is not None
        expected_balls, expected_points = expected_result
        print(f"預期剩餘球數：{expected_balls}")
        print(f"實際剩餘球數：{actual_balls}")
        print(f"預期剩餘命中次數：{expected_points}")
        print(f"實際剩餘命中次數：{actual_points}")
        passed = actual_balls == expected_balls and actual_points == expected_points
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        error_msg = str(e)
        print(f"預期例外：{expected_err}")
        print(f"實際例外：{error_msg}")
        if expected_err and error_msg == expected_err:
            print("通過")
            return True
        print("失敗")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()

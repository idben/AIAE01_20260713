class Caster:
    def __init__(self, name: str, health: int, mp: int) -> None:
        pass

    def take_hit(self) -> None:
        pass

    def cast_spell(self, target: "Caster") -> None:
        pass

    # 以下內容不要修改

    def get_status(self) -> tuple[str, int, int]:
        return self.name, self.health, self.mp

    def print_status(self) -> None:
        print(f"{self.name} 有 {self.health} 點生命值與 {self.mp} 點 MP")

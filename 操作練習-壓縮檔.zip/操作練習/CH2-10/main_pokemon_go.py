class Trainer:
    def __init__(self, name: str, poke_balls: int) -> None:
        pass

    def throw_ball(self, target: "WildPokemon") -> None:
        pass

    # 以下內容不要修改

    def get_status(self) -> tuple[str, int]:
        return self.name, self.poke_balls

    def print_status(self) -> None:
        print(f"{self.name} 還有 {self.poke_balls} 顆球")


class WildPokemon:
    def __init__(self, name: str, catch_points: int) -> None:
        pass

    def take_throw(self) -> None:
        pass

    # 以下內容不要修改

    def get_status(self) -> tuple[str, int]:
        return self.name, self.catch_points

    def print_status(self) -> None:
        print(f"{self.name} 還需要 {self.catch_points} 次命中")

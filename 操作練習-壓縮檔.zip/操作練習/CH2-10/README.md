# CH2-10 物件互動練習

## 題目

這一課把建構子、方法、狀態更新與例外處理合在一起。

- 《勇者鬥惡龍》版：完成 `Caster` 類別，讓施法者能互相施放咒文
- 《寶可夢 GO》版：完成 `Trainer` 與 `WildPokemon` 類別，讓訓練家能丟球捕捉

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成題目要求的方法
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- `Caster` 需要先記住自己的 `name`、`health` 和 `mp`
- `take_hit()` 要扣 `1` 點生命值
- 生命值降到 `0` 或以下時，拋出 `{NAME} is dead`
- `cast_spell()` 要先檢查自己是否已死亡，再檢查 MP
- MP 不足時，拋出 `{NAME} can't cast`
- 成功施法時，MP 要減 `1`，並讓目標 `take_hit()`

### 《寶可夢 GO》版

- `Trainer` 需要先記住自己的 `name` 和 `poke_balls`
- `WildPokemon` 需要先記住自己的 `name` 和 `catch_points`
- `Trainer.throw_ball()` 要先檢查球數
- 沒球時，拋出 `{NAME} has no balls`
- 成功丟球時，球數減 `1`，並呼叫目標的 `take_throw()`
- `WildPokemon.take_throw()` 要把 `catch_points` 減 `1`
- `catch_points` 降到 `0` 或以下時，拋出 `{NAME} is caught`

## 這題常見錯誤

- 方法只印出訊息，沒有真的更新狀態
- 忘了呼叫另一個物件的方法
- 例外訊息和測試要求不完全一致

## 這題在測什麼

- 方法之間的互動
- 狀態更新是否完整
- 例外處理是否正確

import subprocess
import sys
from pathlib import Path

from main import Card, CardGame, HighCardRound, LowCardRound

PlayCase = tuple[str, Card, Card, str]

play_cases: list[PlayCase] = [
    ("high", Card("Ace", "Spades"), Card("King", "Hearts"), "玩家一獲勝：Ace of Spades"),
    ("low", Card("Ace", "Spades"), Card("King", "Hearts"), "玩家二獲勝：King of Hearts"),
    ("high", Card("10", "Clubs"), Card("10", "Spades"), "玩家二獲勝：10 of Spades"),
    ("low", Card("2", "Diamonds"), Card("2", "Diamonds"), "平手：2 of Diamonds 和 2 of Diamonds"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test_create_round() -> bool:
    game = CardGame("玩家一", "玩家二")
    card1 = Card("Queen", "Hearts")
    card2 = Card("Jack", "Clubs")
    high_round = game.create_round("high", card1, card2)
    low_round = game.create_round("low", card1, card2)
    print("---------------------------------")
    print("檢查 create_round()")
    if not isinstance(high_round, HighCardRound):
        print("high 模式沒有建立 HighCardRound")
        return False
    if not isinstance(low_round, LowCardRound):
        print("low 模式沒有建立 LowCardRound")
        return False
    try:
        game.create_round("middle", card1, card2)
    except Exception as error:
        if str(error) == "未知的比牌模式":
            print("通過")
            return True
        print(f"錯誤訊息不正確：{error}")
        return False
    print("未知模式沒有丟出例外")
    return False


def test_play_round(mode: str, card1: Card, card2: Card, expected: str) -> bool:
    game = CardGame("玩家一", "玩家二")
    round_obj = game.create_round(mode, card1, card2)
    actual = game.play_round(round_obj)
    print("---------------------------------")
    print(f"模式：{mode}")
    print(f"輸入：{card1} vs {card2}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    if test_create_round():
        passed += 1
    else:
        failed += 1
    for case in play_cases:
        if test_play_round(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

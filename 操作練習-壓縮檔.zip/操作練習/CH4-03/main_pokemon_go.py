class EggIncubator:
    def boost_walk(self, km: float) -> None:
        pass

    def __raise_if_no_boost(self) -> None:
        pass

    def __use_boost_charge(self) -> None:
        pass

    # 以下內容不要修改

    def walk(self, km: float) -> None:
        self.__walked_km += km

    def get_remaining_distance(self) -> float:
        remaining = self.__egg_km - self.__walked_km
        if remaining < 0:
            return 0.0
        return remaining

    def is_ready_to_hatch(self) -> bool:
        return self.get_remaining_distance() == 0

    def __init__(self, egg_km: float, boost_charges: int) -> None:
        self.__egg_km = egg_km
        self.__walked_km = 0.0
        self.__boost_charges = boost_charges

import subprocess
import sys
from pathlib import Path

from main_dragon_quest import PartyMember

Args = tuple[int, int, int, int]
Expected = tuple[int, int, str | None]
TestCase = tuple[Args, list[str], Expected]

run_cases: list[TestCase] = [
    ((0, 0, 4, 2), ["sprint_right"], (8, 0, None)),
    ((3, 3, 2, 2), ["sprint_up", "sprint_left"], (-1, 7, None)),
]

submit_cases: list[TestCase] = run_cases + [
    ((1, 1, 5, 1), ["sprint_down", "sprint_right"], (1, -9, "not enough stamina to sprint")),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(args: Args, methods: list[str], expected: Expected) -> bool:
    print("---------------------------------")
    member = PartyMember(*args)
    print(f"起始：x={args[0]} y={args[1]} speed={args[2]} stamina={args[3]}")
    try:
        for method in methods:
            print(f"呼叫：{method}")
            getattr(member, method)()
        actual = (*member.get_position(), None)
    except Exception as error:
        actual = (*member.get_position(), str(error))
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
